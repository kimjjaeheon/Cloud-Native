#!/usr/bin/ksh
export TMAXDIR=/tmax/tmax/cbs
uncfl -i $TMAXDIR/config/tmconfig -o $TRAN_AGT_HOME/scripts/tmconfig.out
cat  $TRAN_AGT_HOME/scripts/tmconfig.out | grep "SVCTIME" | awk '{
		split($4, c, ",");
		svc = $1;
		tmo = c[1];
		printf "%s\t %s\n",svc,tmo;
}'
