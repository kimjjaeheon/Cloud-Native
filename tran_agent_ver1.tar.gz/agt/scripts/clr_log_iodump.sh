#!/bin/sh

while true 
do
	ls /logs/penta/tranmgr/logs/proc/tmax | awk '{print "> /logs/penta/tranmgr/logs/proc/tmax/" $1}' | sh -v
	wait
	#print "> /sw/penta/tranmgr/agt/logs/proc/tmax/io_dump_50528530.log" | sh -v
	#ls /logs/penta/tranmgr/logs/proc/tong | awk '{print "> /logs/penta/tranmgr/logs/proc/tong/" $1}' | sh -v
	#wait
	sleep 7200
done
