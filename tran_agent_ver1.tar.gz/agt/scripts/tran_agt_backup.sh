#!/bin/bash

DATE=`date +%Y%m%d`

TRAN_HOME='/sw/tranm'
TRAN_AGT_HOME='/sw/tranm/agt'
#OBJECT FILE &  & LINK FILE(makefile) DELETE
cd $TRAN_AGT_HOME/lib/src;make clean
#rm -rf makefile ./backup/*;ln -s makefile.aix makefile;make clean;
cd $TRAN_AGT_HOME/lib/redis;make clean
#rm -rf makefile ./backup/*;ln -s makefile.aix makefile;make clean;
cd $TRAN_AGT_HOME/src/log_api/libtran;make -f makefile.static.linux clean
#make -f makefile.static.aix clean;
cd $TRAN_AGT_HOME/src/log_collector;make clean
#rm -rf makefile ./backup/*;ln -s makefile.aix makefile;make clean;
cd $TRAN_AGT_HOME/src/log_parser;make clean
#rm -rf makefile ./backup/*;ln -s makefile.aix makefile;make clean;
cd $TRAN_AGT_HOME/src/hash_mgr;make clean
#rm -rf makefile ./backup/*;ln -s makefile.aix makefile;make clean;
cd $TRAN_AGT_HOME/src/agtchkd;make clean
#rm -rf makefile ./backup/*;ln -s makefile.aix makefile;make clean;
cd $TRAN_AGT_HOME/src/agtmgmt;make clean
#rm -rf makefile ./backup/*;ln -s makefile.aix makefile;make clean;
cd $TRAN_AGT_HOME/src/log_sender;make clean
#rm -rf makefile ./backup/*;ln -s makefile.aix makefile;make clean;
cd $TRAN_AGT_HOME/src/tr_sync;make clean
#rm -rf makefile ./backup/*;ln -s makefile.aix makefile;make clean;
cd $TRAN_AGT_HOME/src/tranget;make clean
#rm -rf makefile ./backup/*;ln -s makefile.aix makefile;make clean;
cd $TRAN_AGT_HOME/src/transet;make clean
#rm -rf makefile ./backup/*;ln -s makefile.aix makefile;make clean;
cd $TRAN_AGT_HOME/src/log_tracer;make clean
#rm -rf makefile ./backup/*;ln -s makefile.aix makefile;make clean;
cd $TRAN_AGT_HOME
#FILE BACKUP

if [[ -z $1 ]]; then
echo "ALL"
sleep 1
tar -cvf ./daily_backup/agt_all_$DATE.tar ./src/agtchkd ./src/agtmgmt ./src/hash_mgr ./src/log_collector ./src/log_parser ./src/log_sender ./src/log_tracer ./src/mk_svclist ./src/sqlcxt_hook ./src/tibco_hook ./src/tibco_hook32 ./src/tmax_hook ./src/tr_sync ./src/tranget ./src/transet ./src/log_api ./src/sms_mon ./lib.org ./include.org ./config ./scripts ./bin/*.sh
gzip ./daily_backup/agt_all_$DATE.tar
elif [ $1 = 'src' ]; then
echo "JUST SOURCE"
sleep 1
tar -cvf ./daily_backup/agt_src_$DATE.tar ./src/agtchkd ./src/agtmgmt ./src/hash_mgr ./src/log_collector ./src/log_parser ./src/log_sender ./src/log_tracer ./src/mk_svclist ./src/sqlcxt_hook ./src/tibco_hook ./src/tibco_hook32 ./src/tmax_hook ./src/tr_sync ./src/tranget ./src/transet ./src/sms_mon ./src/log_api ./lib ./include
gzip ./daily_backup/agt_src_$DATE.tar
elif [ $1 = 'cfg' ]; then
echo "WITH SOURCE, CONFIG"
sleep 1
tar -cvf ./daily_backup/agt_src_cfg_$DATE.tar ./src/agtchkd ./src/agtmgmt ./src/hash_mgr ./src/log_collector ./src/log_parser ./src/log_sender ./src/log_tracer ./src/mk_svclist ./src/sqlcxt_hook ./src/tibco_hook ./src/tibco_hook32 ./src/tmax_hook ./src/tr_sync ./src/tranget ./src/transet ./src/sms_mon ./src/log_api ./lib ./include ./config
gzip ./daily_backup/agt_src_cfg_$DATE.tar
elif [ $1 = 'script' ]; then
echo "WITH SOURCE, SCRIPTS"
sleep 1
tar -cvf ./daily_backup/agt_src_script_$DATE.tar ./src/agtchkd ./src/agtmgmt ./src/hash_mgr ./src/log_collector ./src/log_parser ./src/log_sender ./src/log_tracer ./src/mk_svclist ./src/sqlcxt_hook ./src/tibco_hook ./src/tibco_hook32 ./src/tmax_hook ./src/tr_sync ./src/tranget ./src/transet ./src/sms_mon ./src/log_api ./lib ./include ./scripts
gzip ./daily_backup/agt_src_script_$DATE.tar
fi
# MAKE BACKUP DIRECTORY
#cd $TRAN_AGT_HOME/lib/src
#mkdir ./backup
#cd $TRAN_AGT_HOME/lib/redis
#mkdir ./backup
#cd $TRAN_AGT_HOME/src/log_collector
#mkdir ./backup
#cd $TRAN_AGT_HOME/src/log_parser
#mkdir ./backup
#cd $TRAN_AGT_HOME/src/hash_mgr
#mkdir ./backup
#cd $TRAN_AGT_HOME/src/agtchkd
#mkdir ./backup
#cd $TRAN_AGT_HOME/src/agtmgmt
#mkdir ./backup
#cd $TRAN_AGT_HOME/src/log_sender
#mkdir ./backup
#cd $TRAN_AGT_HOME/src/tr_sync
#mkdir ./backup
#cd $TRAN_AGT_HOME/src/tranget
#mkdir ./backup
#cd $TRAN_AGT_HOME/src/transet
#mkdir ./backup
#cd $TRAN_AGT_HOME/src/log_tracer
#mkdir ./backup
