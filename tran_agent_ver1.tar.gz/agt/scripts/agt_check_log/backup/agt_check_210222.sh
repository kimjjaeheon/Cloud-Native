#!/bin/bash

date=$(date +%Y%m%d)
user=`echo $USER`
os=`uname`
log_dir="$TRAN_AGT_HOME/scripts/agt_check_log"

function process_check()
{
	cd $TRAN_AGT_HOME/bin
	./tran_agent.sh show
}

function network_check()
{
	cd $TRAN_AGT_HOME/bin

	IP=( `cat $TRAN_AGT_HOME/config/agt.cfg | grep "IP_ADDRESS" | grep -v "#" | awk '{print$3}'` )
	PORT=( `cat $TRAN_AGT_HOME/config/agt.cfg | egrep "LOG_PORT_*" | grep -v "#" | awk '{print$3}'` )
	tranget_q=( `./tranget -q` )
	SVR_IP=${IP[2]}
	total_count=0

	for P in ${PORT[@]}
	do
		#LINUX
		if [ $os = "Linux" ]; then
			connect="${SVR_IP}:$P"
			netstat -an | egrep "$connect"
			establish_count=`netstat -an | egrep "$connect" | wc -l`
			(( total_count += establish_count ))
		else
		#UNIX
			connect="${SVR_IP}.$P"
			netstat -an | egrep "$connect"
			establish_count=`netstat -an | egrep "$connect" | wc -l`
			(( total_count += establish_count ))
		fi
	done

	if [ ${tranget_q[1]} = "successfully" ]; then
		q_cnt=`echo ${tranget_q[5]} | cut -d ',' -f 1`
	else
		q_cnt="tranget fail"
	fi

	echo
	echo "ESTABLISHED count : $total_count"
	echo "QUEUE       count : $q_cnt"


}

function cpu_mem_check()
{
	ps aux | head -1
	ps aux | grep ^$user 
}

function process_down_check()
{
	cd $TRAN_AGT_HOME/bin

	TIME=( `./tran_agent.sh show | grep ^$user | awk '{print$5}'` )
	standard=${TIME[0]}
	count=0

	for T in ${TIME[@]}
	do
		if [ $standard != $T ]; then
			(( count= $count+1 ))
		fi
	done

	if [ $count = 0 ]; then
		echo "비정상 종료 프로세스 개수 : $count [ OK ] "
	else
		echo "비정상 종료 프로세스 개수 : $count [ WARN ]"
	fi

}

function disk_check()
{
	disk="/sw /log"

	df -k $disk
}

function ipc_check()
{
	shm=`cat $TRAN_AGT_HOME/config/agt.cfg | grep TRAN_LOGF_QUE_INFO_SHMKEY | awk '{printf("%x", $3)}'`

	ipcs -m | head -3
	ipcs -a | grep $shm
}

function wlogs_check()
{
	cd $TRAN_AGT_LOG_HOME/moni
	tail -32 agt_monitor.$date
}

function log_parser_check()
{
	cd $TRAN_AGT_LOG_HOME/proc/log_parser

	err_count=`grep "Error " * | grep -v "Error 0" | wc -l`
	keep_sts_count=`grep "KEEP_STS" * | grep -v "KEEP_STS:0" | wc -l`
	ok="[ OK ]"
	warn="[ OK ]"

	if [ err_count != 0 ]; then
		ok="[ NOK ]"	
	fi
	if [ keep_sts_count != 0 ]; then
		warn="[ WARN ]"	
	fi

	echo "[ log_parser status ]"
	printf ">> IN  [ \"ERROR\" ]    count : %10d $ok" $err_count
	echo
	printf "<< OUT [ \"KEEP_STS\" ] count : %10d $warn" $keep_sts_count
	echo
}

function make_backup_dir()
{
	if [ ! -d $log_dir ];then
		mkdir $log_dir	
	fi
}

function get_server_ip()
{
	config_file="$TRAN_AGT_HOME/config/agt.cfg"
	section_flag=0

	while read line
	do
		find_section=`echo $line | egrep "\[TRAN_SERVER\]"`	

		if [ $section_flag = 1 ]; then
			echo "aaa : $line"
			comment=( `echo $line | grep ^#` )
			echo "comment : ${comment[@]}"

			if [ -z ${comment[0]} ]; then
				echo "bbb : $line"
				SERVER_IP=`echo $line | awk '{print$3}'`
			
				if [ -z $SERVER_IP ];then
					echo "SERVER IP GET FAIL"
					echo "please check \[TRAN_SERVER\] section"
					break;
				fi

				section_flag=0
			else
				continue
			fi
		fi

		if [ ! -z $find_section ]; then
			section_flag=1	
			echo "find_section $line" 
		fi
	done < $config_file

	echo "SERVER_IP : $SERVER_IP"
}

#MAIN
make_backup_dir

{
echo "## AGENT CHECK SHELL ##"
echo
echo "1) PROCESS STATUS CHECK"
process_check
echo
echo "2) NETWORK CHECK"
network_check
echo
echo "3) CPU/MEM CHECK"
cpu_mem_check
echo
echo "4) PROCESS DOWN CHECK"
process_down_check
echo
echo "5) DISK CHECK"
disk_check
echo
echo "6) API CHECK"
ipc_check
echo
echo "7) WLOGS CHECK"
wlogs_check
echo
echo "8) LOG_PARSER CHECK"
log_parser_check
echo

test_r
echo
} > $log_dir/AGT_CHECK_RESULT_$date
