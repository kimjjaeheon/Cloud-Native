#!/bin/ksh
if [ "$#" -eq 2 ]
then
	log_folder=$1
	log_format=$2
	echo "log_folder = $log_folder"
	echo "log_format = $log_format"
	log_file=`basename $log_folder`

	echo "log_file : $log_file"

	while [ true ]
		do
#		find ${log_folder} -size +0k -name "${log_format}" > ${log_file}.txt
		find ${log_folder} -name "${log_format}" > ${log_file}.txt
		while read TRANM_LOG_FILE
		do
			echo `date; basename $TRANM_LOG_FILE`
			> $TRANM_LOG_FILE
		done < ${log_file}.txt
		sleep 7200
	done
else
	echo " usage : clr_log.sh [log_folder] [log_format]"
fi
