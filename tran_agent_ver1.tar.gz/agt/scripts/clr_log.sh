#!/bin/ksh
strstr() {
	[ "${1#*$2*}" = "$1" ] && return 1
	return 0
}

if [ "$#" -eq 2 ]
then
	log_folder=$1
	log_format=$2
	echo "log_folder = $log_folder"
	echo "log_format = $log_format"
	log_file=`basename $log_folder`

	echo "log_file : $log_file"

	while [ true ]
	do
		if strstr "$log_file" "libtran"
		then
			find ${log_folder} -size +0k -name "${log_format}" > ${log_file}.txt
		else
			find ${log_folder} -name "${log_format}" > ${log_file}.txt
		fi
		while read TRANM_LOG_FILE
		do
			pid=`echo $TRANM_LOG_FILE | cut -f 4 -d '_' | cut -f 1 -d '.'`
			cnt=$(ps -ef | grep $pid | grep -v grep | wc -l)
			
			if strstr "$log_file" "libtran" || [ $cnt -gt 0 ]
			then
				echo `date; ` ">" `basename $TRANM_LOG_FILE`
				> $TRANM_LOG_FILE
			else
				echo `date; ` "[ rm -f" `basename $TRANM_LOG_FILE` "]"
				#rm -f $TRANM_LOG_FILE
			fi
		done < ${log_file}.txt
		sleep 14400
#		sleep 21600
	done
else
	echo " usage : clr_log.sh [log_folder] [log_format]"
fi
