su - shinvest -l -c '/sw/shinvest/agt/bin/tran_agent.sh start'
