#!/bin/bash

# set env
$TRAN_AGT_HOME/env/agt.env

DATE=`date +%Y-%m-%d`
TIME=`date +%H:%M:%S`
ALOG=$TRAN_LOG_HOME/dir_check_$DATE.log

LOOP=0

# argument check
#if [ "$1" = "LINUX" ] || [ "$1" = "AIX" ] || [ "$1" = "linux" ] || [ "$1" = "aix" ]
#then
#                echo "current os is $1"
#else
#                echo "usage $0 os_name (linux or aix or LINUX or AIX)"
#fi

touch $ALOG
echo "------------------------------ DIR CHECK START ------------------------------" >> $ALOG
#echo "- $DATE $TIME  = argument is '$1'" >> $ALOG
#echo "-----------------------------------------------------------------------------" >> $ALOG

# dir_list.sh -> directory list
for idx in `$TRAN_AGT_HOME/scripts/dir_list.sh`
do
        # IS NOT DIRECTORY
        if [ ! -d $idx ]; then
                # IS FILE
                if [ -f $idx ]; then
                        echo "$DATE $TIME  Remove -> $idx is file" >> $ALOG
                        rm "$idx"
                fi
                mkdir "$idx"
				# set directory permission
				if [[ $idx = *@(*/proc/tong) ]]; then
						chmod 777 "$idx"
				elif [[ $idx = *@(*/proc/libtran) ]]; then
						chmod 777 "$idx"
				elif [[ $idx = *@(*/proc/tmax) ]]; then
						chmod 777 "$idx"
				elif [[ $idx = *@(*/proc/bindvar) ]]; then
						chmod 777 "$idx"
				elif [[ $idx = *@(*/proc/javaagent) ]]; then
						chmod 777 "$idx"
				elif [[ $idx = *@(*/tmax) ]]; then
						chmod 755 "$idx"
				elif [[ $idx = *@(*/api) ]]; then
						chmod 755 "$idx"
				else
						chmod 755 "$idx"
				fi
                echo "$DATE $TIME  Create +> $idx" >> $ALOG
        else 
                echo "$DATE $TIME  Exist => $idx" >> $ALOG
        fi
        LOOP=`expr $LOOP+1`
done

echo "------------------------------  DIR CHECK END  ------------------------------" >> $ALOG
echo "" >> $ALOG

exit
