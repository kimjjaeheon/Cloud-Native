#!/bin/bash

source $TRAN_AGT_HOME/env/agt.env

cbin
./tran_agent.sh show


