#ifndef __eaicd_hash_tbl_h__
#define __eaicd_hash_tbl_h__

#include <sys/types.h>
#include "tran_def_len.h"

#ifdef _SMALL
	#define EAICD_HASH_IDX_SIZE	(16 * 32)
	#define EAICD_HASH_ARR_SIZE	2000
#else
	#define EAICD_HASH_IDX_SIZE	(256 * 256 * 4)
	#define EAICD_HASH_ARR_SIZE	100000
#endif

#define EAICD_HASH_IDX_MASK	(EAICD_HASH_IDX_SIZE - 1)

/* EAICD HASH STACK LIST */
typedef struct
{
	u_int top;
	u_int idx[EAICD_HASH_ARR_SIZE];
} EAICD_HASH_STK;


/* EAICD HASH 저장 로그 - XXbytes */
typedef struct
{
	char eai_intf_id[EAI_INTF_ID_LEN + 1]; /* 표준인터페이스ID */
	char tr_type; /* 'S':Sync, 'A':Async */
} EAICD_HASH_ARR;


/* EAICD HASH 저장 엘리먼트 */
typedef struct
{
	int		my_idx;
	int		hash_idx;
	int		pre_idx;
	int		next_idx;
	EAICD_HASH_ARR	param;
} EAICD_HASH_ARR_LIST;


typedef struct
{
	u_int alloc_cnt;
	int h_idx[EAICD_HASH_IDX_SIZE];
	EAICD_HASH_ARR_LIST h_arr[EAICD_HASH_ARR_SIZE];
	EAICD_HASH_STK available;	
	EAICD_HASH_STK used;	
} EAICD_HASH_TBL;

#endif /*__eaicd_hash_tbl_h__*/
