#ifndef __ptrc_hash_tbl_h__
#define __ptrc_hash_tbl_h__

#ifdef _SMALL
	#define PTRC_HASH_IDX_SIZE		(128 * 128)
	#define PTRC_HASH_ARR_SIZE		5000
#else
	#define PTRC_HASH_IDX_SIZE		(256 * 256)
	#define PTRC_HASH_ARR_SIZE		10000
#endif

#define PTRC_HASH_IDX_MASK       	(PTRC_HASH_IDX_SIZE - 1)
#define MAX_SERVICE_DEPTH 			10

/* Call Stack 정보 */
typedef struct
{
	struct timeval  s_tm;
	struct timeval  f_tm;
	char			log_type;
	int				call_seq;
	char            called_func[MAX_FUNC_STR_LEN + 1];
	char			my_func[MAX_FUNC_STR_LEN + 1];
	char			file_name[MAX_FILE_STR_LEN + 1];
	u_int			line;
	int				called_func_hash; 	/* Tmax Proframe MACRO(pfmLogMacro.h)에서 생성하여 넘겨줌 */
	int				rc; 				/* Tmax Proframe MACRO(pfmLogMacro.h)에서 생성하여 넘겨줌 */
	int				err_rc_flag; 		/* 최초 에러발생한 함수 Call-Tree 표시 유무 */
	long            keep_func_usec;
	long            keep_dbio_usec;
} CALL_TRC_DEPTH;

/* PTRC_HASH STK LIST */
typedef struct
{
	u_int top;
	u_int idx[PTRC_HASH_ARR_SIZE];
} PTRC_HASH_STK;

/* 서비스 Depth 정보 저장 */
typedef struct
{
	char gid[GID_LEN + 1]; 					/* Global ID */
	char service_id[SERVICE_ID_LEN + 1];    /* 서비스명 */
	char tr_cd[TR_CD_LEN + 1]; 				/* 거래코드 */
} PTRC_VAR;

/* Process Trace Info HASH 저장 로그 */
typedef struct
{
	/* 수행중인 TR 기본 정보(Depth1 기준) */
	char gid[GID_LEN + 1];
	char service_id[SERVICE_ID_LEN + 1];
	char tr_cd[TR_CD_LEN + 1];

	/* 서비스 Depth 정보 저장 */
	PTRC_VAR ptrc_var[MAX_SERVICE_DEPTH];
	char service_depth;

	/* 예비필드 */
	char rsv_fld[RSV_FLD_LEN];
	/* 필드 내용 byte 0 : 온라인('O')/센터컷('C') 거래유무 */
	/* 필드 내용 byte 1 : TRAN_DONE 수행시 trc_sts값 저장 */
	/* 필드 내용 byte 2 : TRAN_START, TRAN_END PAIR 발생 유무 */
	/* 필드 내용 byte 3 : 함수호출 에러 리턴값 비교, 최초 에러 발생 유무(0 or 1) */
	/* 필드 내용 byte 4 : Tmax tpsvctimeout() 발생 유무 (0 or 1) */
	/* 필드 내용 byte 5 : Tmax pfmDbioXXX() 처리상태 - DBIO함수진입:0, sqlcxt 수행중:1, sqlcxt 종료:2 */
	/* 필드 내용 byte 6 : get_mtr_cxt 정합성 에러 발생 유무 (0 or 1) */

	char proc_nm[PROC_NM_LEN + 1];
	char cont_nm[CONT_NM_LEN + 1];

	char pid[PID_LEN + 1]; /* pid */
	char tid[TID_LEN + 1]; /* tid */
	char idx[IDX_LEN + 1]; /* MTR_CXT_VAR idx */

	/* 데이터 비교용 */
	pid_t       _pid;
	pthread_t   _tid;

	/* SnapShot 정보 */
	char ss_flag; /* 동작 플래그 - 0: off, 1: on, 2: start, 3: end */
	char ss_tr_cd[TR_CD_LEN + 1]; /* 거래코드 */
	time_t ss_set_tm; /* SnapShot 요청 시간 */

	/* START, END API 사용 시각 미리 설정 시, 호출 시점에 s_tm, f_tm을 대신한다 
	   사용한 후, tv_sec 값을 0으로 초기화시켜 OFF 시킨다 */
	struct timeval  t_tm;

	/* START, END API 수행 성능계산 */
	struct timeval  s_tm;
	struct timeval  f_tm;

	/* 트레이스 상태값 */
	char trc_sts;

	/* 프로세스 Alive 상태값 (0:Down, 1:Alive, 2:Clear요청, 3:Clear완료) */
	char isalive;

	/* Call Depth 정보 */
	signed char in_depth;
	signed char post_call_trc_depth;
	signed char show_call_trc_depth;
	int         cur_call_trc_depth;

	/* Call 시작 시 마다 Sequence 증가 */
	int  call_seq;

	/* 최종 데이터 전송 큐 번호 */
	char write_qidx;

	/* 동적모듈 이벤트 전송 유무 */
	char evt_flag;

	/* 주기적체크를 위한 경과 시간 */
	char chk_elps_sec;

	/* DBIO 함수 모니터링 On/Off */
	char show_dbio_flag;

	/* 임계치 */
	long show_call_trc_limit;
	long show_dbio_trc_limit;
	long show_sql_trc_limit;

	/* 현재 Call Depth별 정보 */
	CALL_TRC_DEPTH call_trc_depth_list[MAX_CALL_TRC_DEPTH + 1];

	/* SQL 저장 */
	long db_exe_usec;
	int  sql_stmt_keep_cnt;
	TRAN_SQL_STMT_KEEP_LOG  sql_stmt_keep_log[MAX_SQL_STMT_KEEP_CNT];
	char keep_sql_id[MAX_SQL_ID_LEN + 1];
#define MAX_ERR_RC_SET	128
	char err_rc_set[MAX_ERR_RC_SET];
	long sqlca_sqlcode; /* 최근 수행된 쿼리의 SQLCA sqlcode */
	char sqlerr_msg[SQLERR_MSG_LEN + 1]; /* SqlCode Error Text  */

	/* FETCH 정보 */
    int  fetch_row_cnt;
    int  fetch_time;
    int  src_line_no;

    int  acc_fetch_update_cnt;
    int  acc_fetch_row_cnt;
    int  acc_fetch_time;

    /* DB 접속정보 */
    char db_user[DB_USER_LEN + 1]; /* 접속 유저 */
    char db_sid[DB_SID_LEN + 1]; /* DB SID */

#if 0
	/* 바인드변수 사전 저장후 장애발생 시 분석용 자료로 활용함 */
	char keep_sql_bindvar_list[MAX_SQL_BINDVAR_LIST_LEN +1];
#endif
	/* Hash 최근 접근 시간(초) */
	time_t lasted_access;
} PTRC_HASH_ARR;

/* SERVICE HASH 저장 엘리먼트*/
typedef struct
{
	u_int			my_idx;
	int				hash_idx;
	int				pre_idx;
	int				next_idx;
	PTRC_HASH_ARR	param;
} PTRC_HASH_ARR_LIST;

typedef struct
{
	u_int alloc_cnt;
	int h_idx[PTRC_HASH_IDX_SIZE];
	PTRC_HASH_ARR_LIST h_arr[PTRC_HASH_ARR_SIZE];
	PTRC_HASH_STK available;
	PTRC_HASH_STK used;
} PTRC_HASH_TBL;

typedef PTRC_HASH_TBL PTRC_DEFAULT_HASH_TBL;
#define PTRC_DEFAULT_HASH_SIZE sizeof(PTRC_HASH_TBL)

#endif /*__ptrc_hash_tbl_h__*/
