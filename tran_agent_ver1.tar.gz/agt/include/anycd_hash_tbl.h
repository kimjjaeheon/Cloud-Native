#ifndef __anycd_hash_tbl_h__
#define __anycd_hash_tbl_h__

#include "tran_def_len.h"

#ifdef _SMALL
	#define ANYCD_HASH_IDX_SIZE	(16 * 32)
	#define ANYCD_HASH_ARR_SIZE	2000
#else
	#define ANYCD_HASH_IDX_SIZE	(16 * 32)
	#define ANYCD_HASH_ARR_SIZE	2000
#endif

#define ANYCD_HASH_IDX_MASK	(ANYCD_HASH_IDX_SIZE - 1)

#ifdef _FEP_ANYLINK_JAVA
#define ANY_PTRN_TYPE_ETC          0
#define ANY_PTRN_TYPE_ONE_WAY      1
#define ANY_PTRN_TYPE_TWO_WAY      2
#define ANY_PTRN_TYPE_OUT          3
#define ANY_PTRN_TYPE_TWO_WAY_ETC  4

#define ANY_PTRN_KEY_LEN    6
#define ANY_PTRN_IN_LEN     12
#define ANY_PTRN_OUT_LEN    12
#define ANY_PTRN_TRCD_LEN   15

#define ANY_MAX_TRCD_CNT    3

enum eIN_PTRN
{
	eANY_IN_PTRN_FST    = 0,
	eANY_IN_PTRN_SND      ,
	eANY_IN_PTRN_CNT
};
#endif



/*ANYCD HASH STACK LIST*/
typedef struct
{
	u_int top;
	u_int idx[ANYCD_HASH_ARR_SIZE];
} ANYCD_HASH_STK;


/*ANYCD HASH 저장 로그 - XXbytes*/
typedef struct
{
#ifdef _FEP_ANYLINK_JAVA
	char ptrn_key[ANY_PTRN_KEY_LEN  + 1];
	char in_ptrn [eANY_IN_PTRN_CNT][ANY_PTRN_IN_LEN   + 1];
	char out_ptrn[ANY_PTRN_OUT_LEN  + 1];
	char tr_cd   [ANY_PTRN_TRCD_LEN + 1][ANY_PTRN_TRCD_LEN + 1];
	char in_ptrn_type[eANY_IN_PTRN_CNT];
	char out_ptrn_type;
#else
	char org_cd[ANY_ORG_CD_LEN + 1];
	char biz_cd[ANY_BIZ_CD_LEN + 1];
	char kind_cd[ANY_KIND_CD_LEN + 1];
	char tr_cd[ANY_TR_CD_LEN + 1];
	char sync_flag[ANY_SYNC_FLAG_LEN + 1];
	char inout_flag[ANY_INOUT_FLAG_LEN + 1];
#endif
} ANYCD_HASH_ARR;


/*ANYCD HASH 저장 엘리먼트*/
typedef struct
{
	int		my_idx;
	int		hash_idx;
	int		pre_idx;
	int		next_idx;
	ANYCD_HASH_ARR	param;
} ANYCD_HASH_ARR_LIST;


typedef struct
{
	u_int alloc_cnt;
	int h_idx[ANYCD_HASH_IDX_SIZE];
	ANYCD_HASH_ARR_LIST h_arr[ANYCD_HASH_ARR_SIZE];
	ANYCD_HASH_STK available;	
	ANYCD_HASH_STK used;	
} ANYCD_HASH_TBL;

#endif /*__anycd_hash_tbl_h__*/
