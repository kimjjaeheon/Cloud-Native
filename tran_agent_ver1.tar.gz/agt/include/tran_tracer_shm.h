#ifndef __tran_tracer_shm_h__
#define __tran_tracer_shm_h__

#ifndef MAX_TRACER_FILE_LIST
#ifdef _SUNOS
#define MAX_TRACER_FILE_LIST            100
#else
#define MAX_TRACER_FILE_LIST		300	
#endif
#endif

#ifndef MAX_TRACER_FILE_LIST_INFO
#define MAX_TRACER_FILE_LIST_INFO	86400	/* 최대 1일 */
#endif

#define HOST_NAME_LEN				64
#define CONT_NAME_LEN				30
#define TRACER_FILE_NAME_LEN		128

#define MAX_TRACER_NUM				8

typedef struct
{
	 unsigned long long offset_pos;					/* 파일의 오프셋 정보 */
} TRACER_FILE_LIST_INFO;

typedef struct
{
	int cflag;												/* core 덤프 스택 정보 표기값. c=core 덤프 스택파일, s=redis 전송완료 파일 */
	int mflag;												/* 현재 모니터링 중인 파일 구분 (0: 모니터링 종료, 1: 모니터링 중) */
	int exist;
	int cnt;											/* file이 가지고 있는 offset 개수 */
	int backup_cnt;
	int idx;											/* file list index */
	int agt_idx;											/* agent에서 관리중인 idx */
	int file_type;											/* 파일타입. ((0:날짜형식, 1:그외)) */
	int start_day;											/* 파일 등록 일자 */
	unsigned long inode;									/* 파일 inode */
	char host_name[HOST_NAME_LEN + 1];					/* Host Name */
	char cont_name[CONT_NAME_LEN + 1];					/* 컨테이너 명 */
	char file_name[TRACER_FILE_NAME_LEN + 1];			/* 현재 모니터링 중인 경로를 포함한 파일명 */
	char back_file_name[TRACER_FILE_NAME_LEN + 1];		/* 모니터링 중이 파일이 백업 디렉토리로 이동 시 새로 저장될 파일 명 */
	char backup_dir[TRACER_FILE_NAME_LEN + 1];			/* 현재 모니터링 중인 파일이 백업될 경로 지정 */
	char format_name[TRACER_FILE_NAME_LEN + 1];				/* 현재 모니터링 중인 포맷정보 */
	char sort_key[TRACER_FILE_NAME_LEN + 1];				/* 정렬키 (백업파일없으면 원본파일명, 있으면 백업파일명) */
	time_t s_tm;										/* 대상파일 모니터링 시작 시간 (1408327887) */
	time_t f_tm;										/* 대상파일 모니터링 종료 시간 (1408327887) */
	TRACER_FILE_LIST_INFO info[MAX_TRACER_FILE_LIST_INFO];	/* 파일의 상세 정보를 저장하는 구조체 */
} TRACER_FILE_LIST;

typedef struct
{
	int tracer_cnt;												/* tracer 파일 리스트 저장 개수 */
	int log_level;
	int storage_cycle;
	TRACER_FILE_LIST tracer_file_list[MAX_TRACER_FILE_LIST];	/* tracer 파일 리스트 저장 */
} TRAN_TRACER;

typedef struct
{
	TRAN_TRACER tran_tracer[MAX_TRACER_NUM];
} TRAN_TRACER_SHM;

#endif /*__tran_tracer_shm_h__*/
