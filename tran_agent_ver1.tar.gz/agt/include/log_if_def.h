#ifndef __log_if_def_h__
#define __log_if_def_h__

typedef struct
{
        char log_interface_nm[IF_NM_LEN + 1];
} LOG_INTERFACE_NM_INFO;


#define MAX_CONT_NM                             50
typedef struct
{
        char cont_nm[CONT_NM_LEN + 1];
        char log_interface[LOG_INTERFACE_LEN + 1];
        char tr_section[TR_SECTION_LEN + 1];
} CONT_NM_INFO;

#endif /* __log_if_def_h__ */
