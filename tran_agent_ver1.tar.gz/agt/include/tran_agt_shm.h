#ifndef __tran_agt_shm_h__
#define __tran_agt_shm_h__

#ifdef _SUNOS
#define MAX_TRACER_FILE_LIST            100
#else
#define MAX_TRACER_FILE_LIST		300
#endif

#define MAX_FILE_SYSTEM			5

#define MAX_TRACER_NUM			8

#define MAX_PROCESS				68
#define PROC_BIN_LEN			50
#define MAX_EXEC_ARGS			10
#define EXEC_ARGS_LEN			256

#define PROCESS_ACT				1
#define PROCESS_DEACT			0

#define MAX_TRAN_LOGF_QUE_COUNT	16

#define ALIVE_SIGN              0
#define START_SIGN              1
#define STOP_SIGN               2

/* 프로세스 실행정보 */
typedef struct
{
	int   	proc_idx;
	pid_t  	proc_pid;
	char    proc_bin[PROC_BIN_LEN + 1];
	char    exec_args[EXEC_ARGS_LEN + 1];
	int     exec_args_num;
	char    cur_sts;
	char    act_sts;
	u_char  cur_retry_cnt;
	u_char  set_retry_cnt;
	int     chk_retry_cnt_sec;
	time_t  proc_uptime;
	char    proc_sign; /* 0: alive, 1: start, 2: stop, 3: restart */
} PROCESS_INFO;

#define PATH_LEN				256
#define MAX_DIR_CLEANUP			64


/* 로그삭제 디렉토리 리스트정보 */
typedef struct
{
	int		timeup_sec;
	char    path[PATH_LEN + 1];
} DIR_CLEANUP;

#define FILE_SYSTEM_LEN			256

/* 파일시스템 감시 */
typedef struct
{
	int		alert_cnt; /* 횟수 - 현재 3초마다 Check */
	int		alert_pcnt;
	char    file_system[FILE_SYSTEM_LEN + 1];
} FILE_SYSTEM;

/* CPU 사용률 감시 */
typedef struct
{
	int		alert_sec; /* 초 */
	int		alert_pcnt;
} CPU;

/* log_collector 로그파일 수집 대상 리스트 */

#define FILE_NAME_LEN			256
#define MAX_LOG_FILE			512
#define MAX_LOG_PROC			16
#define MAX_LINE_BUF			2048 /* MAX_TEXT : fgets에서 가져오는 최대 사이즈, MAX_LINE_BUF : 거래 데이터 분석을 위한 데이터 사이즈 */

#define HOST_NAME_LEN			64		/* 호스트명 */
#define CONT_NAME_LEN			30		/* 컨테이너명 (WAS기준) */
#define FORMAT_NAME_LEN			128		/* 포맷 명 */
#define TRACER_FILE_NAME_LEN	128

typedef struct
{
	int 	file_idx;						/* 파일리스트 순번 */
	int 	log_type;						/* 로그 타입 */
	int 	msg_type;						/* 메시지 타입 - 거래로그 분석시 활용 */
	int     read_type;						/* 파일 읽기 타입 정의 (0:fgets, 1:fread) */
	char    file_name[FILE_NAME_LEN + 1]; 	/* 경로를 포함한 전체 파일 명 */
	unsigned long file_inode;				/* 파일 inode */
	FILE    *fpbin;							/* 파일 포인터 */
	long 	offset_pos;						/* 파일 오프셋 */
	int     act_sts;						/* 파일 모니터링 유무 (0: 모니터링 안함 - 파일갱신 시 Deact 실행, 1 : 처음부터, 2: 새로들어오는 내용부터  */
	int 	cur_sts;						/* 현재 상태 (0 : Not Open, 1: Opened) */
	int 	get_line_cnt;					/* 주기동안 읽기 로그 수 (0 : Full) */
	int		line_buf_len;					/* line_buf에 저장된 데이터 길이, 0이면 최초, 0이 아니면 continue */
	char	line_buf[MAX_LINE_BUF + 1];		/* fgets 리턴시 데이터 마지막에 new-line이 아닌경우, new-line이 올때까지 임시저장하는 버퍼 */
	time_t	last_update;					/* 최종 Update 시간 */
} LOG_FILE_LIST;


typedef struct
{
	int				cnt;
	LOG_FILE_LIST   list[MAX_LOG_FILE];
} LOG_PROC;


#define DIR_NAME_LEN			1024
#define HHMM_LEN				4
#define MAX_LOG_DIR				20
#define MAX_TMP_LOG_FILE		10000

typedef struct
{
	int		log_type;					/* 로그타입 */
	int		dist_from;					/* 분산처리 시작 프로세스 번호 */
	int		dist_to;					/* 분산처리 종료 프로세스 번호 */
	char	log_dir[DIR_NAME_LEN + 1];	/* 로그 폴더 */
	int     incl_sub_dir;				/* 지정 로그 폴더의 하위 폴더 포함 여부 */
	int		act_sts;					/* 파일 모니터링 유무 (0: 모니터링 안함, 1 : 처음부터, 2: 새로들어오는 내용부터 */
	int     get_line_cnt;               /* 주기동안 읽기 로그 수 (0 : Full) */
	int     read_type;                  /* 파일 읽기 타입 정의 (0:fgets, 1:fread) */
	char	clear_tm[HHMM_LEN + 1];		/* Daily Clear주기 지정시간 */
	int		clear_yn;
} LOG_DIR_LIST;


typedef struct
{
	int				cnt;
	LOG_DIR_LIST	list[MAX_LOG_DIR];
} LOG_DIR;


typedef struct
{
	int     proc_id;
	char    file_name[FILE_NAME_LEN + 1];   
} TMP_LOG_FILE_LIST;

typedef struct
{
	int					cnt;                   
	TMP_LOG_FILE_LIST	list[MAX_TMP_LOG_FILE];
} TMP_LOG_FILE;


/*
< Input Log > -------------------------------------------------------------------------

	 1) log_type1 : TRAN_START()호출 시 발생 
	 2) log_type2 : TRAN_END()호출 시 발생 
	 3) log_type9 : TRAN_ERROR()호출 시 발생
	 4) log_typeI : TRAN_INFO(), TRAN_CALLINFO_S(), TRAN_CALLINFO_F() 호출 시 발생
	 5) log_typeB : TRAN_CALLINFO_S(), TRAN_CALLINFO_F() 호출 시 CALL_FUNC에서 pfmDbio 발생
	 6) log_typeC : TRAN_CALLINFO_S(), TRAN_CALLINFO_F() 호출 시 CALL_FUNC에서발생
	 7) log_typeE : TRAN_ERRINFO() 호출시 발생
	 8) 1og_typeV : TRAN_EVENT()호출 시 발생
	 9) log_typeX : TRAN_INFO_EX() 호출시 발생

< Output Result Flag > ----------------------------------------------------------------

	 1) S_msgs : 서비스 시작
	 2) P_msg  : 서비스 진행중 (현재 안쓰임)
	 3) F_msgs : 서비스 종료
	 4) G_msgs : 시작없는 서비스 종료
	 5) E_msgs : 에러
	 6) D_msgs : 시작없는 에러
	 7) R_msgs : 에러 종료
	 8) I_msgs : 정보성 메시지
	 9) B_msgs : DBIO 메시지
	10) Q_msgs : 수행된 SQL 문
	11) C_msgs : CALL STACK TRACE 메시지
	12) J_msgs : 에러 정보성 로그
	13) V_msgs : API로부터 수신된 이벤트
	14) N_msgs : 엔진에서 생성한 이벤트
	15) U_msgs : 미정의 메시지
	16) O_msgs : 서비스타임아웃
	17) X_msgs : 확장정보 메시지 - 휘발성 데이터 (DB 저장 안함) 
	18) Y_msgs : TRSYNC를 위한 메시지
	19) A_msgs : Active 서비스 임계치 초과 이벤트 

--------------------------------------------------------------------------------------- 
*/

typedef struct
{
	/* input - 10ea */
	u_int log_type1;
	u_int log_type2;
	u_int log_type9;
	u_int log_typeI;
	u_int log_typeX;
	u_int log_typeB;
	u_int log_typeQ;
	u_int log_typeC;
	u_int log_typeE;
	u_int log_typeV;

	/* ouput - 18ea */
	u_int S_msgs;
	u_int P_msgs;
	u_int F_msgs;
	u_int G_msgs;
	u_int E_msgs;
	u_int D_msgs;
	u_int R_msgs;
	u_int Y_msgs;
	u_int O_msgs;
	u_int I_msgs;
	u_int X_msgs;
	u_int B_msgs;
	u_int Q_msgs;
	u_int C_msgs;
	u_int J_msgs;
	u_int V_msgs;
	u_int N_msgs;
	u_int U_msgs;

	/* notify - active service */
	u_int A_msgs;

	/* error - 3ea */
	u_int discard_logs;
	u_int return_null;
	u_int return_keep_state;
} LOG_STAT;

typedef struct
{
	u_int in_qcnt;
	u_int in_discard_qcnt;
	u_int out_qcnt;
	u_int out_discard_qcnt;
	u_int cur_qcnt;
	float log_hashtbl_used_pcnt;
} QUE_STAT;

#define	MAX_FORMAT_LIST		100		/* 최대 포맷 저장 개수 */
#define MAX_FILE_LIST		10000	/* 최대 파일 리스트 저장 개수 */

/* 로그 추적 - 로그 포맷 및 로그 리스트 */
typedef struct
{
	int idx;
	char host_name[HOST_NAME_LEN + 1];			/* 호스트명 */
	char cont_name[CONT_NAME_LEN + 1];			/* 컨테이너명 */
	char format_name[FORMAT_NAME_LEN + 1];		/* 경로포함 파일포맷 */
	char format_dir[TRACER_FILE_NAME_LEN + 1];	/* 포맷 파일 경로 - 삭제 */
	char backup_dir[TRACER_FILE_NAME_LEN + 1];	/* 백업 될 경로 */
} FILE_FORMAT;

typedef struct 
{
	int idx;									/* 파일 리스트 순번 */
	int q_num;									/* 해당 파일 모니터링 중인 tracer 번호 */
	char file_name[TRACER_FILE_NAME_LEN + 1];	/* 경로 포함한 대상 파일명 */
	char format_name[FORMAT_NAME_LEN + 1];		/* 경로포함 파일포맷 */
	char cont_name[CONT_NAME_LEN+1];
	char backup_dir[TRACER_FILE_NAME_LEN+1];
	char exist;									/* file exist 유무 값 0:삭제, 1:유지 (log_tracer가 update 한다.) */
} FILE_LIST;

typedef struct 
{
    int file_cnt;
    time_t file_time;
    FILE_LIST	file_list[MAX_TRACER_FILE_LIST];		/* 로그 파일 정보 */
}FNUM_FILE_LIST;

#define MAX_SKIP_PATTERN     100
#define MAX_SKIP_PATTERN_LEN 1024

typedef struct
{
    bool  pattern_refresh;                         /* 패턴정보 리로딩 */ 
    int   pattern_cnt;                             /* 저장된 패턴 수  */
    char* pattern [MAX_SKIP_PATTERN];              /* 패턴정보 배열   */
    char  pattern_string[MAX_SKIP_PATTERN_LEN+1];  /* 패턴정보 스트링 */
}FILE_SKIP_PATTERN;

typedef struct 
{
    int    tracer_cnt;
	int format_cnt;								/* 로그 파일 포맷 개수 */
	int file_cnt;								/* 로그 파일 개수 */
    time_t dir_modi_time_list [MAX_FORMAT_LIST];    /* 패턴별 디렉토리 수정 시간 */
    FILE_SKIP_PATTERN skip_pattern;                 /* 제외 패턴 */
	FILE_FORMAT file_format[MAX_FORMAT_LIST]; 	/* 로그 파일 포맷 정보 */
	FNUM_FILE_LIST	fnum_file_list[MAX_TRACER_NUM];		/* 로그 파일 정보 */
	/* added by LIANDLI in 2016.06.04 */
} TRACER_FILE_INFO;

#define OS_INFO_LEN        200
typedef struct
{
	char host_name[HOST_NAME_LEN + 1];          /* 호스트명 */
	char os_info[OS_INFO_LEN + 1];
	int core_cnt;
	double mem_total;
} DEVICE_INFO;

typedef struct
{
	int				dir_num;
	int				proc_num;
	int				file_sys_num;
	DIR_CLEANUP		dir_cleanup[MAX_DIR_CLEANUP];
	PROCESS_INFO	proc_info[MAX_PROCESS];

	/* 시스템 자원사용률 체크 */
	FILE_SYSTEM		file_system[MAX_FILE_SYSTEM];
	CPU				cpu;
	
	LOG_PROC		log_proc[MAX_LOG_PROC];
	LOG_DIR			log_dir;
	TMP_LOG_FILE	tmp_log_file;

	/* 거래데이터 분석 결과 처리건수 통계 - log_parser 와 hash_mgr에서 Update함 */
	LOG_STAT		log_stat[MAX_TRAN_LOGF_QUE_COUNT + 1];
	/* Que별 처리건수 통계 */
	QUE_STAT        que_stat[MAX_TRAN_LOGF_QUE_COUNT];
	/* 인터페이스별 ACTIVE SERVICE 모니터링 기준치 - 이벤트 발생을 위한 임계치(ms) */
	int				act_svc_limit[MAX_IF_NUM];

	/* 로그 포맷 및 파일 정보 저장, 관리 */
	TRACER_FILE_INFO	tracer_file_info;
	/* 디바이스 정보 */
	DEVICE_INFO 	device_info;
} TRAN_AGT_SHM;

typedef TRAN_AGT_SHM TRAN_DEFAULT_SHM;
#define TRAN_DEFAULT_SHM_SIZE sizeof(TRAN_AGT_SHM)

#endif /*__tran_agt_shm_h__*/
