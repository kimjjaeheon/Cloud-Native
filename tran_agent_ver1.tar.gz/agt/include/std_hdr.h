#ifndef __std_hdr_h__
#define __std_hdr_h__

/* 표준전문헤더부 */
#define STD_ETXT_LNTH					8	/* 표준전문길이 */
#define STD_ETXT_ENCR_DV_C				1	/* 표준전문암호화구분코드 */
#define STD_ETXT_LANG_DV_C				2	/* 표준전문언어구분코드 */
#define STD_ETXT_VER_DV_C				3	/* 표준전문버전구분코드 */
#define STD_ETXT_CRT_DT					8	/* 표준전문생성일자 */
#define STD_ETXT_CRT_SYS_NM				8	/* 표준전문생성시스템명 */
#define STD_ETXT_SN						14	/* 표준전문일련번호 */
#define STD_ETXT_PRG_DV_NO				2	/* 표준전문진행구분번호 */
#define STD_ETXT_PRG_NO					2	/* 표준전문진행번호 */
#define STD_ETXT_IPADR					39	/* 표준전문IP주소 */
#define STD_ETXT_MACADR					12	/* 표준전문MAC주소 */
#define FST_AK_SYS_DV_C					3	/* 최초요청시스템구분코드 */
#define ENVR_INF_DV_C					1	/* 환경정보구분코드 */
#define FST_AK_DTM						17	/* 최초요청일시 */
#define SEND_SYS_DV_C					3	/* 송신시스템구분코드 */
#define SEND_NODE_ID					12	/* 송신노드ID */
#define STD_ETXT_SEND_DTM				17	/* 표준전문송신일시 */
#define AK_RSP_DV_C						1	/* 요청응답구분코드 */
#define STD_IF_ID						15	/* 표준인터페이스ID */
#define RCV_SYS_DV_C					3	/* 수신시스템구분코드 */
#define ETXT_TP_DV_C					1	/* 전문유형구분코드 */
#define AK_RCV_SV_ID					64	/* 요청수신서비스ID */
#define RSP_RCV_SV_ID					64	/* 응답수신서비스ID */
#define STD_ETXT_RSP_DTM				17	/* 표준전문응답일시 */
#define PROCS_RS_DV_C					1	/* 처리결과구분코드 */
#define ERR_OC_SYS_DV_C					3	/* 오류발생시스템구분코드 */
#define STD_ETXT_ERR_C					9	/* 표준전문오류코드 */
#define MATL_CHNL_C						8	/* 물적채널코드 */
#define PESL_CHNL_C						8	/* 인적채널코드 */
#define TERM_SES_ID						47	/* 단말기세션ID */
#define MCI_AK_NODE_ID					12	/* MCI 요청노드ID */
#define SH_FILLER						95	/* 시스템헤더예비내용 */
#define DLNG_EVN_DV_C					1	/* 거래이벤트구분코드 */
#define CST_INF_INC_YN					1	/* 고객정보포함여부 */
#define LETXT_YN						1	/* 장전문여부 */
#define IN_SRN_ID						12	/* 입력화면ID */
#define MENU_SST_DV_C					2	/* 메뉴체계구분코드 */
#define APR_SAF_KEY_CN					34	/* 승인SAF_KEY내용 */
#define DLNG_PCP_EMPNO					8	/* 거래처리자사원번호 */
#define PCP_DEPT_C						10	/* 처리자부서코드 */
#define PCP_JBC							10	/* 처리자직무코드 */
#define PCP_POSIT_C						10	/* 처리자직위코드 */
#define USR_CNNT_MCHN_IPADR				39	/* 이용자접속기기IP주소 */
#define USR_CNNT_MCHN_MACADR			12	/* 이용자접속기기MAC주소 */
#define RSPP_APR_STC					1	/* 책임자승인상태코드 */
#define APR_RSPP_EMPNO					8 	/* 승인책임자사원번호 */
#define RNK1_RSPP_EMPNO					8 	/* 1순위책임자사원번호 */
#define RNK2_RSPP_EMPNO					8	/* 2순위책임자사원번호 */
#define RNK3_RSPP_EMPNO					8	/* 3순위책임자사원번호 */
#define IF_FRG_BUR_C					3	/* 인터페이스대외기관코드 */
#define IF_FRG_BUR_FILLER				1	/* 대외기관예비필드 */
#define FRG_TSK_C						4	/* 대외업무코드 */
#define FRG_SLF_C						4	/* 대외종별코드 */
#define FRG_DLNG_C						4	/* 대외거래코드 */
#define FRG_LNE_INDX					4	/* 대외회선인덱스번호 */
#define FRG_ONL_ETXT_TP_DV_C			2	/* 대외전문유형구분코드 */
#define TH_FILLER						155	/* 거래공통헤더예비내용 */

/* 시스템 공통부 HEADER */
typedef struct
{
	char std_etxt_lnth[STD_ETXT_LNTH];					/* 표준전문길이 */
	char std_etxt_encr_dv_c[STD_ETXT_ENCR_DV_C];		/* 표준전문암호화구분코드 */
	char std_etxt_lang_dv_c[STD_ETXT_LANG_DV_C];		/* 표준전문언어구분코드 */
	char std_etxt_ver_dv_c[STD_ETXT_VER_DV_C];			/* 표준전문버전구분코드 */
	/********** GUID **********/
	char std_etxt_crt_dt[STD_ETXT_CRT_DT];				/* 표준전문생성일자 */
	char std_etxt_crt_sys_nm[STD_ETXT_CRT_SYS_NM];		/* 표준전문생성시스템명 */
	char std_etxt_sn[STD_ETXT_SN];						/* 표준전문일련번호 */
	char std_etxt_prg_dv_no[STD_ETXT_PRG_DV_NO];		/* 표준전문진행구분번호 */
	char std_etxt_prg_no[STD_ETXT_PRG_NO];				/* 표준전문진행번호 */
	/**************************/
	char std_etxt_ipadr[STD_ETXT_IPADR];				/* 표준전문IP주소 */
	char std_etxt_macadr[STD_ETXT_MACADR];				/* 표준전문MAC주소 */
	char fst_ak_sys_dv_c[FST_AK_SYS_DV_C];				/* 최초요청시스템구분코드 */
	char envr_inf_dv_c[ENVR_INF_DV_C];					/* 환경정보구분코드 */
	char fst_ak_dtm[FST_AK_DTM];						/* 최초요청일시 */
	char send_sys_dv_c[SEND_SYS_DV_C];					/* 송신시스템구분코드 */
	char send_node_id[SEND_NODE_ID];					/* 송신노드ID */
	char std_etxt_send_dtm[STD_ETXT_SEND_DTM];			/* 표준전문송신일시 */
	char ak_rsp_dv_c[AK_RSP_DV_C];						/* 요청응답구분코드 */
	char std_if_id[STD_IF_ID];							/* 표준인터페이스ID */
	char rcv_sys_dv_c[RCV_SYS_DV_C];					/* 수신시스템구분코드 */
	char etxt_tp_dv_c[ETXT_TP_DV_C];					/* 전문유형구분코드 */
	char ak_rcv_sv_id[AK_RCV_SV_ID];					/* 요청수신서비스ID */
	char rsp_rcv_sv_id[RSP_RCV_SV_ID];					/* 응답수신서비스ID */
	char std_etxt_rsp_dtm[STD_ETXT_RSP_DTM];			/* 표준전문응답일시 */
	char procs_rs_dv_c[PROCS_RS_DV_C];					/* 처리결과구분코드 */
	char err_oc_sys_dv_c[ERR_OC_SYS_DV_C];				/* 오류발생시스템구분코드 */
	char std_etxt_err_c[STD_ETXT_ERR_C];				/* 표준전문오류코드 */
	char matl_chnl_c[MATL_CHNL_C];						/* 물적채널코드 */
	char pesl_chnl_c[PESL_CHNL_C];						/* 인적채널코드 */
	char term_ses_id[TERM_SES_ID];						/* 단말기세션ID */
	char mci_ak_node_id[MCI_AK_NODE_ID];				/* MCI 요청노드ID */
	char sh_filler[SH_FILLER];							/* 시스템헤더예비내용 */
	char dlng_evn_dv_c[DLNG_EVN_DV_C];					/* 거래이벤트구분코드 */
	char cst_inf_inc_yn[CST_INF_INC_YN];				/* 고객정보포함여부 */
	char letxt_yn[LETXT_YN];							/* 장전문여부 */
	char in_srn_id[IN_SRN_ID];							/* 입력화면ID */
	char menu_sst_dv_c[MENU_SST_DV_C];					/* 메뉴체계구분코드 */
	char apr_saf_key_cn[APR_SAF_KEY_CN];				/* 승인SAF_KEY내용 */
	char dlng_pcp_empno[DLNG_PCP_EMPNO];				/* 거래처리자사원번호 */
	char pcp_dept_c[PCP_DEPT_C];						/* 처리자부서코드 */
	char pcp_jbc[PCP_JBC];								/* 처리자직무코드 */
	char pcp_posit_c[PCP_POSIT_C];						/* 처리자직위코드 */
	char usr_cnnt_mchn_ipadr[USR_CNNT_MCHN_IPADR];		/* 이용자접속기기IP주소 */
	char usr_cnnt_mchn_macadr[USR_CNNT_MCHN_MACADR];	/* 이용자접속기기MAC주소 */
	char rspp_apr_stc[RSPP_APR_STC];					/* 책임자승인상태코드 */
	char apr_rspp_empno[APR_RSPP_EMPNO];				/* 승인책임자사원번호 */
	char rnk1_rspp_empno[RNK1_RSPP_EMPNO];				/* 1순위책임자사원번호 */
	char rnk2_rspp_empno[RNK2_RSPP_EMPNO];				/* 2순위책임자사원번호 */
	char rnk3_rspp_empno[RNK3_RSPP_EMPNO];				/* 3순위책임자사원번호 */
	char if_frg_bur_c[IF_FRG_BUR_C];					/* 인터페이스대외기관코드 */
	char if_frg_bur_filler[IF_FRG_BUR_FILLER];			/* 대외기관예비필드 */
	char frg_tsk_c[FRG_TSK_C];							/* 대외업무코드 */
	char frg_slf_c[FRG_SLF_C];							/* 대외종별코드 */
	char frg_dlng_c[FRG_DLNG_C];						/* 대외거래코드 */
	char frg_lne_indx[FRG_LNE_INDX];					/* 대외회선인덱스번호 */
	char frg_onl_etxt_tp_dv_c[FRG_ONL_ETXT_TP_DV_C];	/* 대외전문유형구분코드 */
	char th_filler[TH_FILLER];							/* 거래공통헤더예비내용 */
} STD_HDR_FMT;

/* 표준전문헤더부 */
typedef struct
{
	STD_HDR_FMT std_hdr;
} STD_TOT_HDR;
 
#define STD_TOT_HDR_SZ sizeof(STD_TOT_HDR)

#endif /*__std_hdr_h__*/
