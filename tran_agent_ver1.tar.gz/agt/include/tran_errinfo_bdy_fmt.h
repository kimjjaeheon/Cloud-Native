#ifndef __tran_errinfo_bdy_fmt_h__
#define __tran_errinfo_bdy_fmt_h__

#include "tran_def_len.h"

typedef struct
{
	char err_id[ERR_ID_LEN + 1];
	char err_tr_cd[ERR_TR_CD_LEN + 1];
	char err_info_fld[ERR_INFO_FLD_LEN + 1];
	char err_info_str[ERR_INFO_STR_LEN + 1];
} TRAN_ERRINFO_BDY_FMT;

#endif /*__tran_errinfo_bdy_fmt_h__*/
