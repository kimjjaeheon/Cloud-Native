#ifndef __tcp_cmd_msg_h__
#define __tcp_cmd_msg_h__

#include "tran_def_len.h"

#ifdef _MAGIC_BIT
#	ifndef MAGIC_BIT_SIZE
#	define MAGIC_BIT_SIZE          4
#	endif
#endif

#define HEALTH_CHECK_REQ                	'0'
#define HEALTH_CHECK_RSP                	'1'
#define RENEW_SERVICE_LIST_REQ          	'2'
#define RENEW_SERVICE_LIST_RSP          	'3'
#define GET_SERVICE_LIST_REQ            	'4'
#define GET_SERVICE_LIST_RSP            	'5'
#define GET_SERVICE_LIST_RSPACK         	'6'
#define SET_SYS_CONFIG_SET_REQ          	'7'
#define SET_SYS_CONFIG_SET_RSP          	'8'
#define UPDATE_SERVICE_LIST_REQ         	'9'
#define UPDATE_SERVICE_LIST_RSP         	'A'
#define SET_MODIFIED_SERVICE_REQ        	'B'
#define SET_MODIFIED_SERVICE_RSP        	'C'

/* 시스템 자원 사용률 */
#define SET_SYS_RESOURCE_SET_REQ        	'D'
#define SET_SYS_RESOURCE_SET_RSP        	'E'

/* ACTIVE SERVICE DETAIL NOTIFY */
#define NOTIFY_ACTIVE_SERVICE_DETAIL_REQ	'F'
#define NOTIFY_ACTIVE_SERVICE_DETAIL_RSP	'G'

/* DEVICE_INFO - jhp */
#define DEVICE_INFO_REQ             'H'

/* 20210621 iknights - command message */
#define EXT_REQ                         (unsigned char)0x02
#define EXT_REQ_USE                     "\037"
#define EXT_SVCID_LEN                   4
#define EXT_SVCID_CMD                   "0001"
#define EXT_SVCID_FILE_UP               "0002"
#define EXT_SVCID_FILE_DOWN             "0003"
#define EXT_PDU_REQ                     'R' /* request */
#define EXT_PDU_ANS                     'A' /* answer (normal success) */
#define EXT_PDU_ERROR                   'E' /* error */
#define EXT_FILE_MODE_UP                'U' /* file upload */
#define EXT_FILE_MODE_DOWN              'D' /* file download */


/* RESULT VALUE */
#define SUCCESS         '0'
#define FAIL            '1'
#define DATA_READY      '2'
#define DATA_BEGIN      '3'
#define DATA_CONTINUE   '4'
#define DATA_END        '5'

#define _PROC_IDX_LEN 		3
#define _PROC_PID_LEN 		8
#define _PROC_BIN_LEN 		10
#define _EXEC_ARGS_LEN 		30
#define _CUR_STS_LEN 		1
#define _ACT_STS_LEN 		1
#define _CUR_RETRY_CNT_LEN 	3
#define _SET_RETRY_CNT_LEN 	3
#define _CHK_RETRY_CNT_SEC_LEN 	5
#define _PROC_UPTIME_LEN 	12

/* Agent와 서버간 시각 동기화 */
#define SVR_GAP_TIME_LEN    10

typedef struct
{
	char proc_idx[_PROC_IDX_LEN + 1];
	char proc_pid[_PROC_PID_LEN + 1];
	char proc_bin[_PROC_BIN_LEN + 1];
	char exec_args[_EXEC_ARGS_LEN + 1];
	char cur_sts[_CUR_STS_LEN + 1];
	char act_sts[_ACT_STS_LEN + 1];
	char cur_retry_cnt[_CUR_RETRY_CNT_LEN + 1];
	char set_retry_cnt[_SET_RETRY_CNT_LEN + 1];
	char chk_retry_cnt_sec[_CHK_RETRY_CNT_SEC_LEN + 1];
	char proc_uptime[_PROC_UPTIME_LEN + 1];
} PROCESS_INFO_S;


/* Shell Script(shcmd)로 TP서비스 정보를 수집서버로 전달 */
typedef struct
{
	char host_name[HOST_NAME_LEN + 1];
	char service_id[SERVICE_ID_LEN + 1];
	char limit[LIMIT_LEN + 1];
} SERVICE_SMALL;


typedef struct
{
	char host_name[HOST_NAME_LEN + 1];
	char server_id[SERVER_ID_LEN + 1];
	char service_id[SERVICE_ID_LEN + 1];
	char call_trc_depth[CALL_TRC_DEPTH_LEN + 1];
	char call_trc_limit[CALL_TRC_LIMIT_LEN + 1];
	char dbio_trc_limit[DBIO_TRC_LIMIT_LEN + 1];
	char sql_trc_limit[SQL_TRC_LIMIT_LEN + 1];
	char limit[LIMIT_LEN + 1];
	char uflag_set[UFLAG_SET_LEN + 1];
	char tflag[TFLAG_LEN + 1];
	char update_mode[UPDATE_MODE_LEN + 1];
} SERVICE_ELEMENT;

typedef struct
{
	char in_qcnt[STAT_QUE_CNT_LEN + 1];
	char in_discard_qcnt[STAT_QUE_CNT_LEN + 1];
	char out_qcnt[STAT_QUE_CNT_LEN + 1];
	char out_discard_qcnt[STAT_QUE_CNT_LEN + 1];
	char cur_qcnt[STAT_QUE_CNT_LEN + 1];
	char log_hashtbl_used_pcnt[USED_PCNT_LEN + 1];
} QUE_STAT_STR;

typedef struct
{
	char sw_type[API_SW_TYPE_LEN + 1];
	char total_cnt[API_TOTAL_CNT_LEN + 1];
	char init_cnt[API_INIT_CNT_LEN + 1];
	char miss_cnt[API_MISS_CNT_LEN + 1];
	char miss_info[API_MISS_INFO_LEN + 1];
} API_STAT_STR;

#define CALL_SEQ_LEN					6
#define ELAPSED_TIME_LEN				7
#define PROC_NM_LEN                     30
/*
#define MAX_FUNC_STR_LEN                70
*/

/* Active Service 항목 */
typedef struct
{
	char    tr_cd[TR_CD_LEN + 1 ]; /* 거래코드 */
	char    host_name[HOST_NAME_LEN + 1]; /* 호스트명 */
	char    service_id[SERVICE_ID_LEN + 1]; /* 서비스ID */
	char    tr_section[TR_SECTION_LEN + 1]; /* 구간구분 */
	char    gid[GID_LEN + 1]; /* GID */
	char    pid[PID_LEN + 1]; /* PID */
	char    tid[TID_LEN + 1]; /* TID */
	char    proc_nm[PROC_NM_LEN + 1]; /* 프로세스명 */
	char    call_trc_depth[CALL_TRC_DEPTH_LEN + 1]; /* Call Depth */
	char    call_seq[CALL_SEQ_LEN + 1]; /* Call Sequence */
	char    call_func1[MAX_FILE_STR_LEN + 1]; /* Java Package Name */
	char    call_func2[MAX_FUNC_STR_LEN + 1]; /* Java Method */
	char	call_sql_id[MAX_SQL_ID_LEN + 1]; /* Call Sql Id (SQL 200bytes) */
	char    svc_logdt[LOG_TIME_LEN + 1]; /* 시작시각 - 서비스 시작시각 기준 */
	char    svc_elapsed_time[ELAPSED_TIME_LEN + 1]; /* 경과시간 - 서비스 시작시각 기준 */
	char    func_logdt[LOG_TIME_LEN + 1]; /* 시작시각 - 함수 시작시각 기준 */
	char    func_elapsed_time[ELAPSED_TIME_LEN + 1]; /* 경과시간 - 함수 시작시각 기준 */
} ACTIVE_SERVICE_DETAIL;

#define MAX_SEND_PROCESS_INFO_S			(1400 / sizeof(PROCESS_INFO_S))
#define MAX_SEND_SERVICE_ELEMENT		(1400 / sizeof(SERVICE_ELEMENT))
#define MAX_SEND_SERVICE_SMALL			(1400 / sizeof(SERVICE_SMALL))
#define MAX_SEND_ACTIVE_SERVICE_DETAIL	(1400 / sizeof(ACTIVE_SERVICE_DETAIL))

typedef struct
{
#ifdef _MAGIC_BIT
	/* magic_bit added by LIANDLI in 2019.02.08 */
	unsigned char magic_bit[MAGIC_BIT_SIZE];
#endif

	char msg_type[MSG_TYPE_LEN + 1];
} TCP_CMD_HDR;

/* BODY_UPDATE_SERVICE_LIST */
typedef struct
{
	char result_code[RESULT_CODE_LEN + 1];
	char element_num[ELEMENT_NUM_LEN + 1];
	SERVICE_SMALL elements[MAX_SEND_SERVICE_SMALL];
} BODY_UPDATE_SERVICE_LIST_REQ;

typedef struct
{
	char result_code[RESULT_CODE_LEN + 1];
} BODY_UPDATE_SERVICE_LIST_RSP;

/* BODY_UPDATE_PROCESS_LIST */
typedef struct
{
	char result_code[RESULT_CODE_LEN + 1];
	char element_num[ELEMENT_NUM_LEN + 1];
	PROCESS_INFO_S elements[MAX_SEND_PROCESS_INFO_S];
} BODY_UPDATE_PROCESS_LIST_REQ;

typedef struct
{
	char result_code[RESULT_CODE_LEN + 1];
} BODY_UPDATE_PROCESS_LIST_RSP;

/* BODY_HEALTH_CHECK */
typedef struct
{
	char  host_name[HOST_NAME_LEN + 1];
	char  ipaddr[IPADDR_LEN + 1];
	char  port[PORT_LEN + 1];
	char  log_interface[LOG_INTERFACE_LEN + 1];
	char  log_flag_set[LOG_FLAG_SET_LEN + 1];
	char  log_qcnt[LOG_QCNT_LEN + 1];
	char  log_onoff[LOG_ONOFF_LEN + 1];
	char  sfilter_onoff[SFILTER_ONOFF_LEN + 1];
	char  call_trc_depth[CALL_TRC_DEPTH_LEN + 1];
	char  call_trc_limit[CALL_TRC_LIMIT_LEN + 1];
	char  dbio_trc_limit[DBIO_TRC_LIMIT_LEN + 1];
	char  sql_trc_limit[SQL_TRC_LIMIT_LEN + 1];
	/* added 2008.09.30 */
	char  api_shm_nattch[API_SHM_NATTCH_LEN + 1];
	char  svc_shm_nattch[SVC_SHM_NATTCH_LEN + 1];
	char  svc_list_cnt[SVC_LIST_CNT_LEN + 1];
	/* added 2015.04.24 */
	char  api_log[API_LOG_LEN + 1];
	char  tong_log[TONG_LOG_LEN + 1];
	char  engine_sts[ENGINE_STS_LEN + 1];
	char  init_proc_num[INIT_PROC_NUM_LEN + 1];
	char  ptrc_hashtbl_used_pcnt[USED_PCNT_LEN + 1];
	char  jcache_hashtbl_used_pcnt[USED_PCNT_LEN + 1];
	QUE_STAT_STR que_stat[MAX_TRAN_LOGF_QUE_COUNT];
	/* added 2016.06.01 */
	API_STAT_STR api_stat[MAX_API_STAT_COUNT];
	/* added 2010.12.27 */
	char  sys_time[LOG_TIME_LEN + 1];
	/* added 2019.08.19 */
	char  chk_msg[CHK_MSG_LEN + 1];
} BODY_HEALTH_CHECK_REQ;

typedef struct
{
	char result_code[RESULT_CODE_LEN + 1];
	/* added 2010.12.27 */
	char svr_gap_time[SVR_GAP_TIME_LEN + 1]; /* us 단위 */
} BODY_HEALTH_CHECK_RSP;

/* jhp 추가 */
#define OS_INFO_LEN 200
#define CORE_CNT_LEN 5
#define MEM_TOTAL_LEN 30  /* 소수점 고려 */
/* DEVICE_INFO */
typedef struct
{
    char  host_name[HOST_NAME_LEN + 1];
    char  os_info[OS_INFO_LEN + 1];
    char  core_cnt[CORE_CNT_LEN + 1]; /* core는 99999 코어 까지 커버 가능 */
    char  mem_total[MEM_TOTAL_LEN + 1]; /* mem size는 TB 단위 까지 커버 가능함 */
} BODY_DEVICE_INFO_REQ;

typedef struct
{
	char result_code[RESULT_CODE_LEN + 1];
} BODY_DEVICE_INFO_RSP;

/* BODY_RENEW_SERVICE_LIST */
typedef struct
{
	char ipaddr[IPADDR_LEN + 1];
} BODY_RENEW_SERVICE_LIST_REQ;

typedef struct
{
	char result_code[RESULT_CODE_LEN + 1];
} BODY_RENEW_SERVICE_LIST_RSP;

/* BODY_GET_SERVICE_LIST */
typedef struct
{
	char host_name[HOST_NAME_LEN + 1];
} BODY_GET_SERVICE_LIST_REQ;

typedef struct
{
	char result_code[RESULT_CODE_LEN + 1];
	char element_num[ELEMENT_NUM_LEN + 1];
	SERVICE_ELEMENT elements[MAX_SEND_SERVICE_ELEMENT];
} BODY_GET_SERVICE_LIST_RSP;

typedef struct
{
	char result_code[RESULT_CODE_LEN + 1];
} BODY_GET_SERVICE_LIST_RSPACK;

/* SET_LOG_FLAG_SET */
typedef struct
{
	char ipaddr[IPADDR_LEN + 1];
	char log_flag_set[LOG_FLAG_SET_LEN + 1];
	char log_qcnt[LOG_QCNT_LEN + 1];
	char log_onoff[LOG_ONOFF_LEN + 1];
	char sfilter_onoff[SFILTER_ONOFF_LEN + 1];
	char call_trc_depth[CALL_TRC_DEPTH_LEN + 1];
	char call_trc_limit[CALL_TRC_LIMIT_LEN + 1];
	char dbio_trc_limit[DBIO_TRC_LIMIT_LEN + 1];
	char sql_trc_limit[SQL_TRC_LIMIT_LEN + 1];
} BODY_SET_SYS_CONFIG_SET_REQ;

typedef struct
{
	char result_code[RESULT_CODE_LEN + 1];
} BODY_SET_SYS_CONFIG_SET_RSP;

/* SET_MODIFIED_SERVICE */
typedef struct
{
	char element_num[ELEMENT_NUM_LEN + 1];
	SERVICE_ELEMENT elements[MAX_SEND_SERVICE_ELEMENT];
} BODY_SET_MODIFIED_SERVICE_REQ;

typedef struct
{
	char result_code[RESULT_CODE_LEN + 1];
	char element_num[ELEMENT_NUM_LEN + 1];
} BODY_SET_MODIFIED_SERVICE_RSP;

/* NOTIFY ACTIVE_SERVICE DETAIL DETAIL */
typedef struct
{
	char element_num[ELEMENT_NUM_LEN + 1];
	ACTIVE_SERVICE_DETAIL elements[MAX_SEND_ACTIVE_SERVICE_DETAIL];
} BODY_NOTIFY_ACTIVE_SERVICE_DETAIL_REQ;

typedef struct
{
	char result_code[RESULT_CODE_LEN + 1];
	char element_num[ELEMENT_NUM_LEN + 1];
} BODY_NOTIFY_ACTIVE_SERVICE_DETAIL_RSP;

#define CPU_ALERT_SEC_LEN				5
#define CPU_ALERT_PCNT_LEN				3
#define FILE_SYS_ALERT_PCNT_LEN			3
#define MAX_FILE_SYS_LIST_LEN			1024

/* RESOURCE 사용률 */
typedef struct
{
	char cpu_alert_sec[CPU_ALERT_SEC_LEN + 1];
	char cpu_alert_pcnt[CPU_ALERT_PCNT_LEN + 1];
	char file_sys_alert_pcnt[FILE_SYS_ALERT_PCNT_LEN + 1];
	char file_sys_list[MAX_FILE_SYS_LIST_LEN + 1];
} BODY_SET_SYS_RESOURCE_SET_REQ;

typedef struct
{
	char result_code[RESULT_CODE_LEN + 1];
} BODY_SET_SYS_RESOURCE_SET_RSP;


typedef struct
{
	TCP_CMD_HDR hdr;
	union
	{
		/* AGENT -> SERVER */
		BODY_HEALTH_CHECK_REQ               		health_check_req;
		BODY_HEALTH_CHECK_RSP               		health_check_rsp;
		
		BODY_DEVICE_INFO_REQ						device_info_req; /* jhp */
		BODY_DEVICE_INFO_RSP						device_info_rsp;

		BODY_GET_SERVICE_LIST_REQ           		get_service_list_req;
		BODY_GET_SERVICE_LIST_RSP           		get_service_list_rsp;
		BODY_GET_SERVICE_LIST_RSPACK        		get_service_list_rspack;

		BODY_UPDATE_SERVICE_LIST_REQ	    		update_service_list_req;
		BODY_UPDATE_SERVICE_LIST_RSP	    		update_service_list_rsp;

		/* SERVER -> AGENT */
		BODY_SET_MODIFIED_SERVICE_REQ       		set_modified_service_req;
		BODY_SET_MODIFIED_SERVICE_RSP       		set_modified_service_rsp;

		BODY_SET_SYS_RESOURCE_SET_REQ				set_sys_resource_set_req;
		BODY_SET_SYS_RESOURCE_SET_RSP				set_sys_resource_set_rsp;

		/* SERVER <-> CLIENT */
		BODY_SET_SYS_CONFIG_SET_REQ					set_sys_config_set_req;
		BODY_SET_SYS_CONFIG_SET_RSP					set_sys_config_set_rsp;

		/* CLIENT <-> SERVER, SERVER <-> AGENT */
		BODY_RENEW_SERVICE_LIST_REQ         		renew_service_list_req;
		BODY_RENEW_SERVICE_LIST_RSP         		renew_service_list_rsp;

		/* NOTIFY ACTIVE SERVICE */
		BODY_NOTIFY_ACTIVE_SERVICE_DETAIL_REQ		notify_active_service_detail_req;
		BODY_NOTIFY_ACTIVE_SERVICE_DETAIL_RSP		notify_active_service_detail_rsp;
	} body;
} TCP_CMD_MSG;

#endif /*__tcp_cmd_msg_h__*/
