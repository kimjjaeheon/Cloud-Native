#ifndef __tran_ifxx_bdy_fmt_h__

#include "tran_def_len.h"

/*
	공통 바디부
*/

typedef struct
{
	/* 공통항목 */
	char exe_time[EXE_TIME_LEN + 1];							/* 총 수행시간 (DB포함) */
	char db_exe_time[EXE_TIME_LEN + 1];							/* DB소요시간 */
	char service_depth[SERVICE_DEPTH_LEN + 1];					/* 서비스 호출 Depth-'01'기본 */
	char service_type[SERVICE_TYPE_LEN + 1];			/* 서비스 호출타입 (TP-0:TPCALL,1:DLCALL) */
	char br_cd[BR_CD_LEN + 1];							/* 지점코드(거래그룹사코드 + 거래점번호) */       
	char meth_cd[METH_CD_LEN + 1];						/* 매체코드(채널유형코드) */                    
	char tr_cd[TR_CD_LEN + 1];							/* 거래코드(수신서비스코드) */                  
	char scrn_id[SCRN_ID_LEN + 1];						/* 화면번호(화면ID) */                          
	char usr_no[USR_NO_LEN + 1];						/* 사용자번호(직원번호) */                      
	char rslt_cd[RSLT_CD_LEN + 1];								/* 응답처리결과구분코드(처리결과구분코드) */
	char msg_cd[MSG_CD_LEN + 1];						/* 메시지코드(표준전문오류코드) */              
	/* 개별항목 */
	char std_tmsg_len[STD_TMSG_LEN_LEN + 1];			/* 표준전문길이(8) */
	char ipv6_adr[IPV6_ADR_LEN + 1];					/* IPV6 주소(39) */            
	char fst_trms_sys_cd[FST_TRMS_SYS_CD_LEN + 1];		/* 최초전송시스템코드(3) */    
	char trms_sys_cd[TRMS_SYS_CD_LEN + 1];				/* 전송시스템코드(3) */        
	char rqst_rsps_dv_cd[RQST_RSPS_DV_CD_LEN + 1];		/* 요청응답구분코드(1) */      
	char trsc_sync_dv_cd[TRSC_SYNC_DV_CD_LEN + 1];		/* 거래동기화구분코드(1) */    
	char rslt_recv_svc_cd[RSLT_RECV_SVC_CD_LEN + 1];	/* 결과수신서비스코드(12) */   
	char eai_intf_id[EAI_INTF_ID_LEN + 1];				/* EAI인터페이스ID(16) */      
	char dsbl_sys_cd[DSBL_SYS_CD_LEN + 1];				/* 장애시스템코드(3) */        
	char otsd_inst_cd[OTSD_INST_CD_LEN + 1];			/* 대외기관코드(4) */          
	char otsd_biz_cd[OTSD_BIZ_CD_LEN + 1];				/* 대외업무코드(3) */          
	char fst_trms_mdcl_ctt[FST_TRMS_MDCL_CTT_LEN + 1];	/* 최초전송매체내용(39) */     
	/* 제어항목 */                                                              
	char eai_tr_type[EAI_TR_TYPE_LEN + 1];				/* EAI거래유형(1) */        
	char async_svc_type[ASYNC_SVC_TYPE_LEN + 1];		/* 비동기서비스(1) */       
} TRAN_IF00_BDY_FMT, TRAN_IF01_BDY_FMT, TRAN_IF02_BDY_FMT, TRAN_IF03_BDY_FMT, TRAN_IF04_BDY_FMT, TRAN_IF05_BDY_FMT, TRAN_IF06_BDY_FMT, TRAN_IF07_BDY_FMT, TRAN_IF08_BDY_FMT, TRAN_IF09_BDY_FMT, TRAN_IF10_BDY_FMT, TRAN_IF11_BDY_FMT, TRAN_IF22_BDY_FMT, TRAN_IF23_BDY_FMT, TRAN_IF26_BDY_FMT, TRAN_IF27_BDY_FMT, TRAN_IF28_BDY_FMT, TRAN_IF30_BDY_FMT, TRAN_IF31_BDY_FMT, TRAN_IF32_BDY_FMT, TRAN_IF33_BDY_FMT;

typedef struct
{
	/* 공통항목 */
	char exe_time[EXE_TIME_LEN + 1];							/* 총 수행시간 (DB포함) */
	char db_exe_time[EXE_TIME_LEN + 1];							/* DB소요시간 */
	char service_depth[SERVICE_DEPTH_LEN + 1];					/* 서비스 호출 Depth-'01'기본 */
	char service_type[SERVICE_TYPE_LEN + 1];			/* 서비스 호출타입 (TP-0:TPCALL,1:DLCALL) */
	char br_cd[BR_CD_LEN + 1];							/* 지점코드(거래그룹사코드 + 거래점번호) */
	char meth_cd[METH_CD_LEN + 1];						/* 매체코드(채널유형코드) */
	char tr_cd[TR_CD_LEN + 1];							/* 거래코드(수신서비스코드) */
	char scrn_id[SCRN_ID_LEN + 1];						/* 화면번호(화면ID) */
	char usr_no[USR_NO_LEN + 1];						/* 사용자번호(직원번호) */
	char rslt_cd[RSLT_CD_LEN + 1];								/* 응답처리결과구분코드(처리결과구분코드) */
	char msg_cd[MSG_CD_LEN + 1];						/* 메시지코드(표준전문오류코드) */
	/* 개별항목 */
	char pt_service_id[PT_SERVICE_ID_LEN + 1];			/* PT서비스ID(30) */
	char cli_ip_adr[CLI_IP_ADR_LEN + 1];				/* 클라이언트IP(20) */
	char login_id[LOGIN_ID_LEN + 1];					/* 로그인ID(20) */
	char url[URL_LEN + 1];								/* URL(30) */
	char svc_sub_cd[SVC_SUB_CD_LEN + 1];					/* E채널 하위 업무코드(3) */	
} TRAN_IF12_BDY_FMT, TRAN_IF13_BDY_FMT, TRAN_IF14_BDY_FMT, TRAN_IF15_BDY_FMT, TRAN_IF16_BDY_FMT, TRAN_IF17_BDY_FMT, TRAN_IF18_BDY_FMT, TRAN_IF19_BDY_FMT, TRAN_IF20_BDY_FMT, TRAN_IF24_BDY_FMT, TRAN_IF21_BDY_FMT, TRAN_IF25_BDY_FMT, TRAN_IF29_BDY_FMT, TRAN_IF34_BDY_FMT, TRAN_IF35_BDY_FMT, TRAN_IF36_BDY_FMT, TRAN_IF37_BDY_FMT, TRAN_IF38_BDY_FMT, TRAN_IF39_BDY_FMT, TRAN_IF40_BDY_FMT, TRAN_IF41_BDY_FMT;
#endif /*__tran_ifxx_bdy_fmt_h__*/
