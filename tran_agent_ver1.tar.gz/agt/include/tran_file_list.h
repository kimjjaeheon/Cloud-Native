#ifndef __tran_file_list_h__
#define __tran_file_list_h__

#define FILE_NAME_LEN			256
#define MAX_FILE_LIST_INFO		86400
#define MAX_FILE_LIST			16

typedef struct
{
	int offset_pos;
	time_t last_update;
} FILE_LIST_INFO;

typedef struct
{
	int cnt;
	char file_name[FILE_NAME_LEN + 1];
	FILE *fpbin;
	FILE_LIST_INFO info[MAX_FILE_LIST_INFO];
} FILE_LIST;

#endif /*__tran_file_list_h__*/
