#ifndef __tran_def_len_h__
#define __tran_def_len_h__

#define LOG_LVL_LEN				1   /* 로그레벨  */
#define LOG_TYPE_LEN			1   /* 로그타입  */
#define LOG_INTERFACE_LEN		2   /* 로그인터페이스  */
#define TR_SECTION_LEN			1   /* 구간 구분( E2E:0, WEB:1, MCA:2, WAS:3, WAS-DB:4, TP:5, TP-DB:6, EAI:7, 대외(FEP):8, ETC:9 ) */

#define GID_UNI_LEN				30  /* GLOBAL ID UNIQ (30 byte) */
#define GID_SEQ_LEN				2   /* GLOBAL ID SEQ  ( 2 byte) */
#define GID_LEN					GID_UNI_LEN + GID_SEQ_LEN  /* GLOBAL ID */  
#define SERVICE_ID_LEN			16  /* 서비스ID */
#define HOST_NAME_LEN			64  /* 호스트명 */
#define PID_LEN					8   /* 프로세스ID */
#define TID_LEN					15   /* Thread ID */
#define IDX_LEN					5   /* GLOBAL VAR INDEX */
#define QID_LEN					2   /* Send QID */
#define RT_CTRL_SET_LEN			8	/* 실시간 데이터 처리제어 플래그SET */
#define SERVICE_TIME_LEN		4	/* 서비스 수행시간 임계치(sec) */
#define LOG_DAY_LEN				8   /* 로그일자 */
#define LOG_TIME_LEN			12  /* 로그일시 */


/* 공통항목 */
#define EXE_TIME_LEN			10  /* 소요시간 */
#define SERVICE_TYPE_LEN		1   /* 서비스타입(TP-DLCALL:0,TPCALL:1) */
#define SERVICE_DEPTH_LEN		2   /* 서비스DEPTH */
#define BR_CD_LEN				6   /* 지점코드(거래그룹사코드 + 거래점번호) */
#define METH_CD_LEN				3   /* 매체코드(채널유형코드) */
#define TR_CD_LEN				12 	/* 거래코드(수신서비스코드) */
#define SCRN_ID_LEN				9   /* 화면번호(화면ID) */
#define USR_NO_LEN				7   /* 사용자번호(직원번호) */
#define RSLT_CD_LEN				1   /* 응답처리결과구분코드(처리결과구분코드) */
#define MSG_CD_LEN				9	/* 메시지코드(표준전문오류코드) */

#define GLBL_ID_LEN				GID_LEN		/* 표준전문글로벌ID(32) */
#define RECV_SVC_CD_LEN			TR_CD_LEN	/* 수신서비스코드(12) */
#define PROC_RSLT_DV_CD_LEN		RSLT_CD_LEN	/* 처리결과구분코드(1) */
#define STD_TMSG_ERR_CD_LEN		MSG_CD_LEN	/* 표준전문오류코드(9) */
#define CHNL_TYP_CD_LEN			METH_CD_LEN	/* 채널유형코드(3) */
#define EMP_NO_LEN				USR_NO_LEN	/* 직원번호(7) */
#define TRSC_GRCO_CD_LEN		2			/* 거래그룹사코드(2) */
#define TRSC_BR_NO_LEN			4			/* 거래점번호(4) */

/* 처리결과 구분코드 의미값 */
#define RSLT_CD_BLANK				' '	/* 정상 - 임시 */
#define RSLT_CD_NORMAL				'0'	/* 정상 */
#define RSLT_CD_BIZERR				'1'	/* 비즈니스오류 */
#define RSLT_CD_SYSERR				'8'	/* 시스템오류 */
#define RSLT_CD_TIMEOUT				'9'	/* 타임아웃 */

/* 추가항목 */
#define STD_TMSG_LEN_LEN		8	/* 표준전문길이(8) */
#define IPV6_ADR_LEN			39	/* IPV6 주소(39) */
#define FST_TRMS_SYS_CD_LEN		3	/* 최초전송시스템코드(3) */
#define TRMS_SYS_CD_LEN			3	/* 전송시스템코드(3) */
#define RQST_RSPS_DV_CD_LEN		1	/* 요청응답구분코드(1) */
#define TRSC_SYNC_DV_CD_LEN		1	/* 거래동기화구분코드(1) */
#define RSLT_RECV_SVC_CD_LEN	12	/* 결과수신서비스코드(12) */
#define EAI_INTF_ID_LEN			16	/* EAI인터페이스ID(16) */
#define DSBL_SYS_CD_LEN			3	/* 장애시스템코드(3) */
#define OTSD_INST_CD_LEN		4	/* 대외기관코드(4) */
#define OTSD_BIZ_CD_LEN			3	/* 대외업무코드(3) */
#define FST_TRMS_MDCL_CTT_LEN	39	/* 최초전송매체내용(39) */
#define EAI_TR_TYPE_LEN			1   /* EAI거래패턴유형 */
#define ASYNC_SVC_TYPE_LEN		1	/* 비동기서비스 */

/* PT구간 추가항목 */
#define PT_SERVICE_ID_LEN		30 /* PT서비스ID */
#define CLI_IP_ADR_LEN			20 /* 클라이언트IP */
#define LOGIN_ID_LEN			20 /* 로그인ID */
#define URL_LEN					30 /* URL */
#define SVC_SUB_CD_LEN			3	/* E채널하위 업무코드 */

/* 정보성 로그 */
#define LOG_INFO_STR_LEN		350 /* 정보성 로그스트링 350 byte  */

/* SQL문 수집로그 */
#define SQL_STMT_STR_LEN		350 /* SQL문 스트링 350 byte  */

/* INFO_EX-LOG */
#define LOG_INFO_EX_ID_LEN		4	/* INFO_EX ID */
#define LOG_INFO_EX_STR_LEN		350	/* 정보성 추가 메시지 350 byte */

#define EVT_ID_LEN				4   /* 이벤트 ID */
#define EVT_TR_CD_LEN			TR_CD_LEN	/* 이벤트발생 거래코드 */
#define EVT_INFO_FLD_LEN		4	/* 이벤트 정보 예비필드 */
#define EVT_INFO_STR_LEN		512 /* 이벤트 정보스트링 */

#define ERR_ID_LEN				4	/* 에러 ID */
#define ERR_TR_CD_LEN			TR_CD_LEN	/* 에러발생 거래코드 */
#define ERR_INFO_FLD_LEN		4	/* 에러 정보 예비필드 */
#define ERR_INFO_STR_LEN		350 /* 에러 정보성 로그스트링 350 byte */

/* VITRIA */
#define EAI_IF_ID_LEN			12  /* VITRIA EAI INTERFACE ID */
#define EAI_SVC_ID_LEN			10  /* VITRIA 서비스명 */
#define EAI_INOUT_BND_LEN		1   /* Core기준 In/Out BOUND */
#define EAI_TR_TYPE_LEN			1   /* EAI거래패턴유형 */

/* ANYLINK */
#define ANY_TR_CD_LEN			10  /* ANY LINK 거래코드 */
#define ANY_ORG_CD_LEN			4   /* 기관코드(4) */
#define ANY_BIZ_CD_LEN			4   /* 업무코드(4) */
#define ANY_KIND_CD_LEN			4   /* 종별코드(4) */
#define ANY_LOG_ID_LEN			28  /* LOG_ID(28) */
#define ANY_ERR_CD_LEN			1   /* 에러코드(1) */
#define ANY_SYNC_FLAG_LEN		1   /* ASync, Sync */
#define ANY_INOUT_FLAG_LEN		1   /* In/Out BOUND */

/* IMECO */
#define IMC_FEP_PROC_NM_LEN		11  /* 처리프로세스명(11) */
#define IMC_SEQ_NUM_LEN			11  /* 메시지일련번호(11) */
#define IMC_TR_CODE_LEN			11  /* 트랜잭션 코드(11) */
#define IMC_MEM_NO_LEN			5   /* 회원번호(5) */
#define IMC_BR_NO_LEN			5   /* 지점번호(5) */
#define IMC_ORDR_ID_LEN			10  /* 주문ID(10) */
#define IMC_ORG_ORDR_ID_LEN		10  /* 원주문ID(10) */
#define IMC_ISSU_CODE_LEN		12  /* 종목코드(12) */
#define IMC_TRADE_NO_LEN		11  /* 체결번호(11) */
#define IMC_CAUSE_CD_LEN		4   /* 거부사유코드(4) */

/* HEALTH CHECK */
#define IPADDR_LEN				15  /* Agent IP 저장 */
#define RESULT_FLAG_LEN			1	/* 로그 메시지 처리 결과 플래그 */

#define BUS_GROUP_CD_LEN		3	/* 업무 대분류코드 */
#define BUS_CD_LEN				3	/* 업무 중분류코드 */
#define UNTBUS_CD_LEN			5	/* 업무 소분류코드(3) + 업무구분코드(1) + 온라인(O), 센터컷(C), 배치(B)(1) */

/* 서비스 테이블 항목 길이 정의 */
#define SERVER_ID_LEN			15
#define SERVICE_ID_LEN			16
#define LIMIT_LEN				10
#define CALL_TRC_DEPTH_LEN		5
#define CALL_TRC_LIMIT_LEN		10
#define DBIO_TRC_LIMIT_LEN		10
#define SQL_TRC_LIMIT_LEN		10
#define UFLAG_SET_LEN			8
#define TFLAG_LEN				1
#define UPDATE_MODE_LEN			1

/* 명령어 처리 메시지 항목 길이 정의 */
#define MSG_TYPE_LEN			1
#define RESULT_CODE_LEN			1
#define ELEMENT_NUM_LEN			3

/* 커맨드 프로세스 - HEALTH CHECK BODY */
#define PORT_LEN				5
#define AGENT_CNT_LEN			1

#define LOG_QCNT_LEN			3
#define LOG_FLAG_SET_LEN		8
#define LOG_ONOFF_LEN			1
#define SFILTER_ONOFF_LEN		1
/* 추가 */
#define CALL_TRC_DEPTH_LEN		5
#define CALL_TRC_LIMIT_LEN		10
#define DBIO_TRC_LIMIT_LEN		10
#define SQL_TRC_LIMIT_LEN		10
/* ---- */
#define API_SHM_NATTCH_LEN		8
#define SVC_SHM_NATTCH_LEN		8
#define SVC_LIST_CNT_LEN		8

/* 요청/응답구분 */
#define RQST_CHAR				'Q' 	/* 요청 */
#define RSPS_CHAR				'S' 	/* 응답 */

/* 동기/비동기구분 */
#define SYNC_CHAR				'S' 	/* 동기 */
#define ASYNC_CHAR				'A' 	/* 비동기 */

/* 전송 로그 유형 */
#define REAL_TIME_LOG			'0'		/* 실시간 로그 */
#define TCP_FAIL_LOG			'1'		/* 전송 실패 로그 */

/* 에이전트 모니터링 항목추가 */
#define ENGINE_STS_LEN					1  /* 엔진 프로세스 상태 - 0:정상, 1:비정상 */
#define INIT_PROC_NUM_LEN				5  /* 초기화 함수 호출 프로세스 개수 */
#define USED_PCNT_LEN					6  /* LOG HASH-TABLE, JCACHE HASH-TABLE, PTRC HASH-TABLE 사용률(%) */
#define API_LOG_LEN						1  /* 0:LOG OFF, 1:MSGQ DATA 출력, 2:MSGQ + PARSING DATA 출력 */
#define TONG_LOG_LEN					1  /* 0:LOG OFF, 1:통전문 출력 */
#define STAT_QUE_CNT_LEN				5  /* In Queueing/Discard, Out Queueing/Discard Que Count, Periodic(5sec) Processing Count */
#define MAX_TRAN_LOGF_QUE_COUNT			16 /* 로그 데이터 수신 큐 개수 */

#define API_SW_TYPE_LEN					15 /* API초기화 S/W 종류 */
#define API_TOTAL_CNT_LEN				5  /* API초기화 대상 전체 프로세스 개수 */
#define API_INIT_CNT_LEN				5  /* API초기화된 프로세스 개수 */
#define API_MISS_CNT_LEN				5  /* API초기화 누락 프로세스 개수 */ 
#define API_MISS_INFO_LEN				70 /* API초기화 누락 프로세스 리스트 */
#define MAX_API_STAT_COUNT				2  /* API초기화 상태정보 개수 */
#define CHK_MSG_LEN						300 /* Check Result String */

/* sms_mon */
#define FS_NUM_LEN              1   /* Filesystem 모니터링 수 ( 1자리수 ) */
#define FS_NAME_LEN             64  /* Filesystem 명 길이 */
#define FS_TOTAL_LEN            10  /* Filesystem TOTAL 길이 */
#define FS_USED_LEN             10  /* Filesystem USED 길이 */
#define FS_FREE_LEN             10  /* Filesystem FREE 길이 */
#define FS_USED_PCT_LEN         3   /* Filesystem 사용율 */
#define FS_TYPE_LEN             1   /* Filesystem 타입 플래그 (INFO_EX_ID : F) */


/* 거래 추적 클라이언트 필터링 플래그
  - 인터페이스당 필터플래그 값 구성 내역(바이트 기준)
     byte 1 : interface id
     byte 2 : 정상 로그
     byte 3 : 비정상 로그
     byte 4 : 정보성 로그
     byte 5 ~ 8 : Reserved
 */
#define FILTER_FLAGSET_LEN		8 * 7

/* 동적 함수호출 정보 Depth, 함수명 지정 */
#define MAX_CALL_TRC_DEPTH		50
#define MAX_FUNC_STR_LEN		70
#define MAX_FILE_STR_LEN		100
#define MAX_SQL_ID_LEN			200

/* DB 정보 저장 */
#define SQLERR_MSG_LEN			100
#define DB_USER_LEN				10
#define DB_SID_LEN				10

#define BLANK20_STRING			"                    "
#define BLANK32_STRING			"                                "
#define BLANK34_STRING			"                                  "
#define BLANK50_STRING			"                                                  "

#define YYYY_LEN				4
#define MM_LEN					2
#define DD_LEN					2
#define HH_LEN					2
#define MI_LEN					2
#define SS_LEN					2
#define MS_LEN					3
#define US_LEN					6
#define US_OFFSET				HH_LEN + MI_LEN + SS_LEN

#define SPACE64_STR             "                                                                "

#define IF_NM_LEN				64
#define MAX_CONT_NM				50

#endif /*__tran_def_len_h__*/
