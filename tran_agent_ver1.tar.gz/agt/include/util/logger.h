
#ifndef __LOGGER_H__
#define __LOGGER_H__

#include <stdio.h>
#include <stdarg.h>
#include <pthread.h>

enum E_LOG_LEVEL {
  eLL_          = -1,
  eLL_trace         , // 0
  eLL_debug         , // 1
  eLL_info          , // 2
  eLL_warn          , // 3
  eLL_err           , // 4
  eLL_critical      , // 5
  eLL_off           , // 6
  eLL_size          , // 7
};

enum E_LOG_MODE {
  eLM_          = -1,
  eLM_daily         ,
  eLM_split         ,
};

typedef struct _st_logger_t {
  
  int use_thread;
  int level;
  int display_console_stderr;
  char path[512];
  char name[128];
  char date[10+1];
  char logbuf[4096];
  int is_mode;  // daily, split
  int split_count;
  unsigned long split_size;
  FILE* fp;
  
  pthread_mutex_t mutex;
  
  void (*trace   )(struct _st_logger_t* logger, const char* fmt, ...);
  void (*debug   )(struct _st_logger_t* logger, const char* fmt, ...);
  void (*info    )(struct _st_logger_t* logger, const char* fmt, ...);
  void (*warn    )(struct _st_logger_t* logger, const char* fmt, ...);
  void (*err     )(struct _st_logger_t* logger, const char* fmt, ...);
  void (*critical)(struct _st_logger_t* logger, const char* fmt, ...);
    
} st_logger_t;

st_logger_t* make_logger(const char* path, const char* name, int level);
void free_logger(st_logger_t* logger);
void dump_logger(st_logger_t* logger);

const char* log_lvl_to_str(int level);
const char* log_lvl_to_short_str(int level);

// write log with file, line
#define LOG_T_FL(logger,fmt,args...) do { if(logger) logger->trace   (logger, fmt " [%s:%d]", ## args, __FILE__, __LINE__); } while(0)
#define LOG_D_FL(logger,fmt,args...) do { if(logger) logger->debug   (logger, fmt " [%s:%d]", ## args, __FILE__, __LINE__); } while(0)
#define LOG_I_FL(logger,fmt,args...) do { if(logger) logger->info    (logger, fmt " [%s:%d]", ## args, __FILE__, __LINE__); } while(0)
#define LOG_W_FL(logger,fmt,args...) do { if(logger) logger->warn    (logger, fmt " [%s:%d]", ## args, __FILE__, __LINE__); } while(0)
#define LOG_E_FL(logger,fmt,args...) do { if(logger) logger->err     (logger, fmt " [%s:%d]", ## args, __FILE__, __LINE__); } while(0)
#define LOG_C_FL(logger,fmt,args...) do { if(logger) logger->critical(logger, fmt " [%s:%d]", ## args, __FILE__, __LINE__); } while(0)

#define LOG_T(logger,fmt,args...) LOG_T_FL(logger,fmt,## args)
#define LOG_D(logger,fmt,args...) LOG_D_FL(logger,fmt,## args)

#ifdef _DEBUG
#define LOG_I(logger,fmt,args...) LOG_I_FL(logger,fmt,## args)
#define LOG_W(logger,fmt,args...) LOG_W_FL(logger,fmt,## args)
#define LOG_E(logger,fmt,args...) LOG_E_FL(logger,fmt,## args)
#define LOG_C(logger,fmt,args...) LOG_C_FL(logger,fmt,## args)
#else 
#define LOG_I(logger,fmt,args...) do { if(logger) logger->info    (logger, fmt, ## args); } while(0)
#define LOG_W(logger,fmt,args...) do { if(logger) logger->warn    (logger, fmt, ## args); } while(0)
#define LOG_E(logger,fmt,args...) do { if(logger) logger->err     (logger, fmt, ## args); } while(0)
#define LOG_C(logger,fmt,args...) do { if(logger) logger->critical(logger, fmt, ## args); } while(0)
#endif



#endif /* __LOGGER_H__ */