
#ifndef __USRUTIL_H__
#define __USRUTIL_H__

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#define FILETYPE_REG 1
#define FILETYPE_FILE FILETYPE_REG
#define FILETYPE_DIR 2
#define FILETYPE_ETC 3
#define ARRAY_COUNT(arr) (sizeof(arr)/sizeof(arr[0]))
#define SWAP(x) swap_byteas(&x, sizeof(x));

#ifdef __cplusplus
extern "C" {
#endif

// envstr to str 
// ex) $TRAN_HOME/agt -> /sw/tranm/agt
void env2str(char* src, char* outbuf, int len);

char* get_procname(char* procname);
char* get_path(char* fullname, char* buf, int len);


// success:0, error: etc
int check_regex(const char* pattern);

// match: 0, nomatch: -1, error: -2
int strcmp_regex(const char* src, const char* pattern, int ignorecase);

void get_current_dir(char* buf, size_t buf_size);
// 0:success, -1:fail
int makedir(char *dir, int if_file_del);
int removedir(char* path, int recursive);
int copy_file(char* src, char* dst);
int rename_file(char* src, char* dst, int if_exist_del);

// 0:not exist, 1:file, 2:directory, 3:etc
int is_file_exist(char *file);
long file_size(const char* file);

void trim_right(char* str, char* del);
void trim_left(char* str, char* del);
void trim_all(char* str, char* dle);

// need free
char* str_replace(char* org_str, const char* word, const char* rep_str);
char* format(const char* fmt, ...);
char* file_content(char* file);
char* file_extension(char* file);

int starts_with(char* src, char* str);
int ends_with(char* src, char* str);
int str_split(char* src, const char* del, char** result, int max_count);
int str_split_str(const char* str, char* src, char** result, int max_count);
void to_uppercase(char* src);
void to_uppercase_copy(char* src, char* dst);
void to_lowercase(char* src);
void to_lowercase_copy(char* src, char* dst);
int is_numstr(const char* str);

int hangul_euckr_ex(const char* str, int len, int cut_len);

void do_daemon();
int is_running(const char *proc_name);

int get_lastday(int year, int month);
void seconds_to_day(time_t sec, int* days, int* hours, int* minutes, int* seconds);
void timestring(long sec, const char* fmt, char* buf, int buf_len);

int is_big_endian();
void swap_byteas(void* p, size_t n);

void hexprint(const char* buffer, int size);
int hexdump(const char* buffer, int size, char* _obuf, int obuf_sz, int width);

#ifdef __cplusplus
}
#endif

#ifdef _DEBUG
#define DEBUG_PRINT(fp, fmt, ...) do { \
  fprintf(fp, fmt " [%s:%d]\n" \
    , ## __VA_ARGS__, __FILE__, __LINE__ ); \
} while(0)
#define PRINT_D(fp, fmt, ...) DEBUG_PRINT(fp, fmt, ## __VA_ARGS__)
  #ifdef _DEBUG2
    #define PRINT_D2(fp, fmt, ...) DEBUG_PRINT(fp, fmt, ## __VA_ARGS__)
  #else 
    #define PRINT_D2(fp, fmt, ...)
  #endif
#else
#define DEBUG_PRINT(fp, fmt, ...) 
#define PRINT_D(fp, fmt, ...)
#define PRINT_D2(fp, fmt, ...)
#endif

#define LOG_PRINT(fp, fmt, ...) do { \
  if(fp) { \
    fprintf(fp, fmt "\n", ## __VA_ARGS__); \
    fflush(fp); \
  }\
} while(0)

#endif /* __USRUTIL_H__ */
