
#ifndef __OFFSET_PARSER_H__
#define __OFFSET_PARSER_H__

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _st_offset_info st_offset_info;
typedef struct _st_offset_parser st_offset_parser;

struct _st_offset_info {
  int pos;
  int size;
  char desc[32];
};

struct _st_offset_parser{
  int   (*parser)(st_offset_parser* op, char* buf, int buf_len);
  char* (*get_item)(st_offset_parser* op, int idx);
  int   (*get_item_size)(st_offset_parser* op, int idx);

  int count;
  st_offset_info* offset_infos;
  char** items;
  int max_size;
};

st_offset_parser* make_offset_parser(st_offset_info* infos, int count);
void free_offset_parser(st_offset_parser* op);
void init_offset_parser(st_offset_parser* op);
void dump_offset_parser(st_offset_parser* op, FILE* fp);

#ifdef __cplusplus
}
#endif

#endif // __OFFSET_PARSER_H__
