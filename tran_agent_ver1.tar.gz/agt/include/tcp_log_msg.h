#ifndef __tcp_log_msg_h__
#define __tcp_log_msg_h__

#define MAX_PACKING_LOG_SIZE	1400
#define LOG_NUM_SIZE			3
#define LOG_LEN_SIZE			4

#ifdef _MAGIC_BIT
#	ifndef MAGIC_BIT_SIZE
#	define MAGIC_BIT_SIZE          4
#	endif
#endif

typedef struct
{
#ifdef _MAGIC_BIT
	/* magic_bit added by LIANDLI in 2019.02.08 */
	unsigned char magic_bit[MAGIC_BIT_SIZE];
#endif

	union
	{
		char str[LOG_NUM_SIZE + 1];
		u_short  val;
	} log_num;

	union
	{
		char str[LOG_LEN_SIZE + 1];
		int  val;
	} log_len;

	char log_sts; /* 로그 상태 - '0':실시간 로그, '1':전송 실패 로그 */
	char packing_logs[MAX_PACKING_LOG_SIZE];
} TCP_LOG_MSG;

#endif /*__tcp_log_msg_h__*/
