#ifndef __log_hash_tbl_h__
#define __log_hash_tbl_h__

#include <time.h>
#include "tran_log_fmt.h"
#include "svc_hash_tbl.h"

#define EXE_TIME_BEGIN		0
#define EXE_TIME_END		1

#define TRAN_START_BIT  		0x0001
#define TRAN_END_BIT    		0x0002
#define TRAN_ERROR_BIT  		0x0004
#define TRAN_CORRECT_BIT  		0x0008
#define TRAN_NEXTLOG_BIT  		0x0010
#define TRAN_START_SND_BIT		0x0020
/* 강제 서비스 종료 메시지 생성을 위한 BIT */
#define PROC_CORE_START_BIT		0x0040	/* PROC_CORE */
#define PROC_CORE_ERROR_BIT		0x0080	/* PROC_CORE */
#define SVC_TIMEOUT_START_BIT	0x0100	/* SVC_TIMEOUT */
#define SVC_TIMEOUT_ERROR_BIT	0x0200	/* SVC_TIMEOUT */
#define CLH_RSPS_ERROR_BIT		0x0400	/* CLH_RSPS_ERROR */

#define PROC_CORE		0
#define SVC_TIMEOUT		1

#ifdef _SMALL
	#define MAX_LOG_HASH_TBL	8
#else
	#define MAX_LOG_HASH_TBL	16
#endif

#define LOG_HASH_IDX_SIZE	(256 * 256)
#define LOG_HASH_ARR_SIZE	10000
#define LOG_HASH_IDX_MASK	(LOG_HASH_IDX_SIZE - 1)

/* 동작제어 Timer */
#define MAX_ACTION_TIMER		4

#define ACTION_TIMER_SVCTIME		0 /* 서비스 타임아웃 발생 left시간(sec) */
#define ACTION_TIMER_KEEP_STATE 	1 /* 일정시간 동안 ResultFlag 값을 유지 한 후, 로그를 발생한다 */
#define ACTION_TIMER_CLH_RSPS_CHK 	2 /* 일정시간 동안 CLH 응답종료가 발생하지 않으면, 강제 종료로그를 생성한다 */

/* LOG HASH STK LIST */
typedef struct
{
	u_int top;
	u_int idx[LOG_HASH_ARR_SIZE];
} LOG_HASH_STK;

/* LOG HASH 저장 로그 - XXbytes */
typedef struct
{
	TRAN_LOG_FMT keep_log;
	SVC_HASH_ARR keep_svc;
	int    pre_log_idx; /* GID가 동일한 S->S->S->F->F->F 진행시 중복된 시작로그 기준 이전 중복 시작로그를 기억 */
	struct timespec exe_time[2]; /* 0 : 실행 시작 시각 저장, 1 : 실행 종료 시각 저장 */
	int    action_timer[MAX_ACTION_TIMER]; /* 동작제어 Timer 설정 */
	int    db_exe_time; /* DB 총 수행 시간(ms) */
	char   result_flag;  /* 로그 진행 현재 결과 값 */
	short  log_flag;  /* Hash 추적에 사용 */
	char   rt_ctrl_set[RT_CTRL_SET_LEN]; /* 실시간 데이터 처리제어 플래그SET - rt_ctrl_set_def.h 내용 참조 */
} LOG_HASH_ARR;

/* log_flag 값 의미
0x0001 : 시작 
0x0002 : 종료 
0x0004 : 에러
0x0008 : 순서보정
0x0010 : 중복로그있음
0x0020 : 시작로그가 전송되었음
0x0040 : 프로세스 비정상종료(코어) 거래 result_flag 가 GENERAL_START
0x0080 : 프로세스 비정상종료(코어) 거래 result_flag 가 GENERAL_ERROR
0x0100 : 서비스 타임아웃 발생시점 자체 감지
*/

/*LOG HASH 저장 엘리먼트*/
typedef struct
{
	int		my_idx;
	int		hash_idx;
	int		pre_idx;
	int		next_idx;
	LOG_HASH_ARR	param;
} LOG_HASH_ARR_LIST;


typedef struct
{
	u_int alloc_cnt;
	int h_idx[LOG_HASH_IDX_SIZE];
	LOG_HASH_ARR_LIST h_arr[LOG_HASH_ARR_SIZE];
	LOG_HASH_STK available;	
	LOG_HASH_STK used;	
} LOG_HASH_TBL;


typedef struct
{
	LOG_HASH_TBL log_hash_tbl[MAX_LOG_HASH_TBL];
} LOG_HASH_TBLS;

#endif /*__log_hash_tbl_h__*/
