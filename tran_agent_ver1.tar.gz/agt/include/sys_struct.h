/***********************************************************************************************
 *  System          : XMINS(eXtensible Multiple Interface and Solution)
 *  Program ID      : sys_struct.h
 *  Description     : define structure
 *  Author          : NAM
 *  Notice					:
 *  Revision        :
 ************************************************************************************************/
#ifndef _SYS_STRUCT_H
#define _SYS_STRUCT_H

#include	"etrade_fep_hdr.h"		/* FEPINFO define */

#define   	SZ_SEQ_NO 	8
#define		SZ_ERR_CD	4

/*------------------------------------------------------------------------------------------------
 * 장내 채권 HEAD
 *------------------------------------------------------------------------------------------------*/
typedef struct
{
     char       sTrCode     [ 9];
     char       sCompanyCd  [ 3];
     char       sTrType     [ 4];
     char       sNetInfo    [ 3];
     char       sRpCode     [ 2];
     char       sDateTime   [12];
     char       sRetryCnt   [ 2];
     char       sStartSeq   [ 8];
     char       sDataCnt    [ 2];
} T_BOND_HEAD;
#define SZ_BOND_HEAD          (sizeof(T_BOND_HEAD))

/*------------------------------------------------------------------------------------------------
 * 거래소 차세대 회원사항목  (40 bytes)
 *------------------------------------------------------------------------------------------------*/
typedef struct
{
	/*--------------------------
	;  회원처리항목(40)
	--------------------------*/
	/*--------------------------
	;  1. 공통영역(24)
	--------------------------*/
	char	sMbrComBTGb		[ 1];			/* 위탁자기구분					*/
											/*	B:위탁						*/
											/*	T:자기						*/
	char	sMbrComSpecGb	[ 1];			/* 특이구분 					*/
											/*	M: MTS임					*/
											/*	K: KTN(ktacc)				*/
											/*	T: ADS(tradap01)			*/
											/*	E: ELW-LP(lp01)				*/
											/* 	X: Trading(swing)			*/ 
											/* 	D: MTS Direct(only 위탁용)	*/
											/*  H: MCI (미정)				*/

	char	sMbrUserId		[12];			/* User ID						*/  
												
	char	sMbrUsrKQNo		[ 2];			/* KQ번호(자기매매는 상품구분)	*/
	char	sMbrMTSHTSKey	[ 8];			/* MTS, HTS Key					*/

	/*--------------------------
	;  2. 개별영역(16)
	--------------------------*/
	char	sMbrAppArea		[16];			/* 업무 영역					*/


} T_CUSTOM_AREA;
#define SZ_CUSTOM_AREA			(sizeof(T_CUSTOM_AREA))	

/*------------------------------------------------------------------------------------------------
 * 차세대 현/선물 공통 HEAD 82bytes
 *------------------------------------------------------------------------------------------------*/
typedef struct
{
	char       	sApiVer  	[ 8];			/* KMAPv1.0								*/
	char       	sBodyLen	[ 6]; 			/* Header를 제외한 Body 길이			*/ 
	char       	sTrType    	[11];			/* Messages Type						*/
  char       	sSessionSeq	[11];			/* 일련번호								*/
											/* 최종 처리 번호 						*/
											/* 6건중 2건 정상이면 2수신				*/
	char		sCompanyID	[ 5];			/* 회원번호								*/
	char		sLinkedID	[10];			/* 연계시도착 회원사 번호				*/
	char		sReplyID	[10];			/* 회신시동신 회원사 번호				*/
	char		sDateTime	[17];			/* 전송일시 YYYYmmddHHMMSSsss 1/1000초	*/
	char		sDataCnt	[ 3];	   		/* 데이터 전송 건수						*/ 
											/* 최종 처리건수 + 에러 1건 			*/
											/* 6건중 2건 정상이면 에러포함 3건수신 	*/
											/* 4, 5번 주문은 데이터 페기함 			*/
											/* 4, 5번 회원사로 데이터 안줌			*/ 
											/* 모두비정상인경우 1수신				*/ 
	char		sEncYn		[ 1];			/* 암호화 여부 Y / N					*/	
} T_STOCKS_HEAD;
#define SZ_STOCKS_HEAD          (sizeof(T_STOCKS_HEAD))

/*------------------------------------------------------------------------------------------------
 * 세션키 교환 교보 <--> 거래소
 * szMsgType = SCHLIQ00101
 * szMsgType = SCHLIQ00102
 * szMsgType = SCHLIQ00103
 * szMsgType = SCHLIQ00104
 * szMsgType = SCHLIQ00105
 *------------------------------------------------------------------------------------------------*/
typedef struct
{
	char		sErrCode	[4];     		/* 에러 코드 							*/
	char		sData		[4096];			/* 키교환 데이터 						*/	

} T_KEY_DATA;
#define SZ_KEY_DATA		(sizeof(T_KEY_DATA))

/*------------------------------------------------------------------------------------------------
 * 로그온 요청 교보 -> 거래소
 * szMsgType = SCHLIQ00000
 *------------------------------------------------------------------------------------------------*/
typedef struct
{
    char    	sUserID		[10];  			/* 사용자 ID 							*/
    char    	sPassword	[30];          	/* 사용자 PassWord 						*/
	char		sEncYn		[ 1];			/* 암호화 여부 Y / N					*/	

} T_LOGON_REQUEST;
#define SZ_LOGON_REQUEST		(sizeof(T_LOGON_REQUEST))

/*------------------------------------------------------------------------------------------------
 * 로그온 응답 거래소 -> 교보 
 * szMsgType = SCHLIR00000 
 *------------------------------------------------------------------------------------------------*/
typedef struct 
{
	char		sErrCode	[4];     		/* 에러 코드 							*/
	char		sEncYn		[1];			/* 암호화 여부 Y / N					*/	
} T_LOGON_RESPONSE;
#define	SZ_LOGON_RESPONSE		(sizeof(T_LOGON_RESPONSE))

/*------------------------------------------------------------------------------------------------
 * Openning 요청. 거래소 -> 교보  
 * szMsgType = SCHOPQ00000 
 *------------------------------------------------------------------------------------------------*/
typedef struct
{
    char		sErrCode	[4];     		/* 에러 코드 */
    char    	sTrCode		[11];          	/* TR-Code 번호 */                              
	char    	sSeqNo		[11];          	/* 일련 번호 */
} T_OPEN_REQUEST;
#define	SZ_OPEN_REQUEST			(sizeof(T_OPEN_REQUEST))

/*------------------------------------------------------------------------------------------------
 * Openning 응답 교보 -> 거래소 
 * szMsgType = SCHOPQ00000 
 *------------------------------------------------------------------------------------------------*/
typedef struct
{
    char		sErrCode	[4];     		/* 에러 코드 */
    char    	sTrCode		[11];          	/* TR-Code 번호 */
	char    	sSeqNo		[11];          	/* 일련 번호 */
} T_OPEN_RESPONSE;
#define	SZ_OPEN_RESPONSE		(sizeof(T_OPEN_RESPONSE))

/*------------------------------------------------------------------------------------------------
 * HeartBeat 요청 
 * HeartBeat 요청은 BODY없이 헤더만 전송되므로 정의되지 않는다. 
 * szMsgType = SCHHEQ00000 
 *------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------------------
 * HeartBeat 응답 
 * HeartBeat 요청은 BODY없이 헤더만 전송되므로 정의되지 않는다. 
 * szMsgType = SCHHER00000 
 *------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------------------
 * 로그아웃 요청  
 * Logout 요청은 BODY없이 헤더만 전송되므로 정의되지 않는다. 
 * szMsgType = SCHLOQ00000 
 *------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------------------
 * 로그아웃 응답  
 * szMsgType = SCHLOR00000
 *------------------------------------------------------------------------------------------------*/
typedef struct
{
    char    	sErrCode	[4];             /* 에러 코드 */
} T_LOGOUT_RESPONSE;
#define	SZ_LOGOUT_RESPONSE		(sizeof(T_LOGOUT_RESPONSE))

/*------------------------------------------------------------------------------------------------
 * 일련번호 요청 
 * 일련번호 요청은 BODY없이 헤더만 전송되므로 정의되지 않는다. 
 * szMsgType = SCHSQQ00000
 *------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------------------
 * 일련번호 요청 
 * 일련번호 요청은 BODY없이 헤더만 전송되므로 정의되지 않는다. 
 * szMsgType = SCHSQQ00000 
 *------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------------------
 * 일련번호 응답 
 * szMsgType = SCHSQR00000 
 *------------------------------------------------------------------------------------------------*/
typedef struct
{
    char    	sSeqNo		[11];  			/* 최종 일련번호 */
} T_SEQUENCE_RESPONSE;
#define	SZ_SEQUENCE_RESPONSE		(sizeof(T_SEQUENCE_RESPONSE))

/*------------------------------------------------------------------------------------------------
 * 재송신 요청
 * szMsgType = SCHRSQ00000
 *------------------------------------------------------------------------------------------------*/
typedef struct
{
    char		szSeqNo		[11];  			/* 일련 번호 */
} T_RESEND_REQUEST;
#define	SZ_RESEND_REQUEST		(sizeof(T_RESEND_REQUEST))
   
/*------------------------------------------------------------------------------------------------
 * 재송신 응답  
 * szMsgType = SCHRSR00000 
 *------------------------------------------------------------------------------------------------*/
typedef struct
{
    char    	szErrCode	[4]; 			/* 에러 코드 */
    char    	szSeqNo		[11];   		/* 일련 번호 */
} T_RESEND_RESPONSE;
#define	SZ_RESEND_RESPONSE		(sizeof(T_RESEND_RESPONSE))

/* Business Messages */

/*-------------------------
 * 주문 300 Bytes 
 * p.39 호가입력 
 * 신규호가:TCHODR10001
 * 정정호가:TCHODR10002
 * 취소호가:TCHODR10003 
 *-----------------------*/
typedef struct
{
    char        sSeq         	[11];      	/* 데이타일련번호    			*/
    char        sTrCode         [11];      	/* 개별 TR   (신규,정정,취소)   */
    char        sRegulOffhrTpCd [1];       	/* 정규시간외구분코드           */
    char        sMbrNo          [5];       	/* 회원번호                     */
    char        sBrnNo          [5];       	/* 지점번호                     */
    char        sOrderId        [10];      	/* 주문 ID                      */
    char        sOrgnOrdId      [10];      	/* 원주문ID                     */
    char        sIsuCd          [12];      	/* 종목코드                     */
    char        sBidaskTpCd     [1];       	/* 매수매도구분코드             */
    char        sModcanclTpCd   [1];       	/* 정정취소구분코드             */
                                           	/* 1 : 정상,    2 : 정정,   3 : 취소 */
    char        sAcntNo         [12];       /* 계좌번호                    */
                                            /* * 지점번호(4)+계좌번호(8)    */
    char        sOrdQty         [10];       /* 호가수량                     */
    char        sOrdPrc         [11];       /* 호가가격                     */
    char        sOrdTpCd        [1];        /* 호가유형코드                 */
                                            /* 1 시장가 2 지정가        I 조건부지정가  X 최유리    Y 최우선 */
    char        sOrdCondCd      [1];        /* 호가조건코드                 */
                                            /* 0 일반 (FAS) 1 IOC (FAK) 2 FOK */
    char        sMmOrdTpNo      [11];       /* 시장조성자호가구분번호       */
                                            /* 0 : 일반 1~ : LP호가일련번호 *선물방식중용 */
    char        sTrstkStatSeq   [5];        /* 자사주신고서일련번호         */
    char        sTrstkTpCd      [1];        /* 자사주구분코드               */
    char        sSrtsellTpCd    [2];        /* 매도 유형코드                */
    char        sCreditTpCd     [2];        /* 신용구분코드                 */
    char        sTrstPrincTpCd  [2];        /* 위탁자기구분코드             */
    char        sTrstMbrNo      [5];        /* 위탁회원번호                 */
    char        sPtTpCd         [2];        /* PT구분코드                   */
    char        sSbRghtAcntNo   [12];       /* 대용주권계좌번호             */
    char        sAcntTpCd       [2];        /* 계좌구분코드                 */
    char        sAcntMrgnTpCd   [2];        /* 계좌증거금유형코드           */
    char        sCntrCd         [3];        /* 국가코드                     */
    char        sInvstTpCd      [4];        /* 투자자구분코드               */
    char        sForninvstTpCd  [2];        /* 외국인투자자구분코드         */
    char        sOrdMediaTpCd   [1];        /* 주문매체구분코드             */
    char        sOrdererid      [12];       /* 주문자식별정보               */
    char        sOrdDd          [8];        /* 호가일자                     */
    char        sMbrOrdTm       [9];        /* 회원사주문시각               */
	T_CUSTOM_AREA 		tCustomArea;		/* 회원사 사용영역				*/
    char        sFiller         [73];       /* Filler                       */
} T_ORDER_DATA;
#define SZ_ORDER_DATA    (sizeof(T_ORDER_DATA))

/*------------------------------------------------------
 * 주문접수 데이터 24Bytes
 *----------------------------------------------------*/
typedef struct
{
    char        sErrCode            [4];   	/* 거부사유코드					*/ 
    char        sAcceptSeq  		[11];  	/* 정상처리데이터 일련번호		*/
	char		sAcceptTime			[9];	/* 메세지도달시간				*/					
} T_ORDER_CONFIRM_DATA;
#define SZ_ORDER_CONFIRM_DATA  (sizeof(T_ORDER_CONFIRM_DATA))

/*------------------------------------------------------
 * 대량 호가  300Bytes  
 * p.47 대량호가입력 
 * 회원사 --> 거래소 
 * 	대량신규호가:TCHBOR10001
 *	대량취소호가:TCHBOR10003
 *	협의대량신규:TCHBOR20001
 *	협의대량취소:TCHBOR20003
 *----------------------------------------------------*/
typedef struct
{
    char        sSeq        	[11];     	/* 주문일련번호       			*/
    char        sTrCode         [11];      	/* 개별 TR   (신규,정정,취소)   */
    char        sRegulOffhrTpCd [1];       	/* 정규시간외구분코드           */
    char        sMbrNo          [5];       	/* 회원번호                     */
    char        sBrnNo          [5];       	/* 지점번호                     */
    char        sOrderId        [10];      	/* 주문 ID                      */
    char        sOrgnOrdId      [10];      	/* 원주문ID                     */
    char        sIsuCd          [12];       /* 종목코드                     */
    char        sBlktrdTpCd     [1];        /* 대량매매구분코드             */
                                            /* 1 대량 2 바스켓 3 협의대량   */
											/* 4 EFP    5 FLEX				*/
    char        sBidaskTpCd     [1];        /* 매수매도구분코드             */
    char        sModcanclTpCd   [1];        /* 정정취소구분코드             */
                                            /* 1 : 정상,    2 : 정정,   3 : 취소 */
    char        sAcntNo         [12];       /* 계좌번호                     */
                                            /* * 지점번호(4)+계좌번호(8)    */
    char        sOrdQty         [10];       /* 호가수량                     */
    char        sOrdPrc         [11];       /* 호가가격                     */
    char        sTrstkId        [5];        /* 자사주신고서ID               */
    char        sTrstkTpCd      [1];        /* 자사주매매방법코드           */
                                            /* 0 자사주일반					*/
                                            /* 1 한은 등 자사주				*/
                                            /* 3 정부 등 자사주            	*/
    char        sOrdTpCd        [2];       	/* 매도유형코드                 */
    char        sCreditTpCd     [2];       	/* 신용구분코드                 */
    char        sTrstPrincTpCd  [2];        /* 위탁자기구분코드             */
    char        sAcntTpCd       [2];        /* 계좌구분코드                 */
    char        sAcntMrgnTpCd   [2];        /* 계좌증거금유형코드           */
    char        sCntrCd         [3];        /* 국가코드                     */
    char        sInvstTpCd      [4];        /* 투자자구분코드               */
    char        sForninvstTpCd  [2];        /* 외국인투자자구분코드         */
    char        sOrdMediaTpCd   [1];        /* 주문매체구분코드             */
    char        sOrdererid      [12];       /* 주문자식별정보               */
    char        sNegoNo         [6];        /* 협상번호                     */
    char        sNegoDtlNo      [6];        /* 협상상세번호                 */
    char        sNegoprnId      [10];       /* 협상자ID                     */
    char        sCtpartMbrNo    [5];        /* 상대회원번호                 */
    char        sCtpartAcntNo   [12];       /* 상대계좌번호                 */
    char        sNegoCompltTm   [9];        /* 협의완료시각                 */
    char        sOrdDd          [8];        /* 호가일자                     */
    char        sMbrOrdTm       [9];        /* 회원사주문시각               */
	T_CUSTOM_AREA       tCustomArea;        /* 회원사 사용영역              */
    char        sSpotPrice      [11];       /* 현물가격                     */
    char        sFiller         [45];       /* Filler                       */
} T_AMOUNT_DATA;
#define SZ_AMOUNT_DATA    (sizeof(T_AMOUNT_DATA))


/*------------------------------------------------------
 * 주문 업무계 수신데이터 대량매매주문서거절  
 * p.52 대량매매주문서거절
 * TCHBOP10001
 *----------------------------------------------------*/

typedef struct
{
    char        sSeq            [11];  		/* 주문일련번호                 */
    char        sTrCode         [11];      	/* 개별 TR   (신규,정정,취소)   */
    char        sRegulOffhrTpCd [1];       	/* 정규시간외구분코드           */
    char        sIsuCd          [12];      	/* 종목코드                     */
                                           	/* 표준종목코드 12자리 			*/
    char        sBlktrdTpCd     [1];       	/* 대량매매구분코드             */
                                           	/* 1 대량 2 바스켓 3 협의대량 	*/
    char        sBidaskTpCd     [1];        /* 매수매도구분코드             */
                                            /* 1 매수   2 매도              */
    char        sTrstkId        [5];        /* 자사주신고서ID               */
    char        sTrstkTpCd      [1];        /* 자사주매매방법코드           */
                                            /* 0 해당없음					*/
                                            /* 1 자사주일반					*/
                                            /* 2 한은 등 자사주				*/
                                            /* 3 정부 등 자사주            	*/
    char        sNegoInvalidCd  [1];       	/* 협상무효구분코드             */
    char        sMbrNo          [5];        /* 회원번호                     */
    char        sAcntNo         [12];       /* 계좌번호                     */
                                            /* * 지점번호(4)+계좌번호(8)    */
    char        sOrdQty         [10];       /* 호가수량                     */
    char        sOrdPrc         [11];       /* 호가가격                     */
    char        sNegoNo         [6];        /* 협상번호                     */
    char        sNegoDtlNo      [6];        /* 협상상세번호                 */
    char        sNegoprnId      [10];       /* 협상자ID                     */
    char        sNegoRsltRejRsnCd[2];       /* 협상결과거부사유코드         */
    char        sOrdDd          [8];        /* 호가일자                     */
    char        sRsltRejTm      [9];        /* 회원사 거부시각              */
	T_CUSTOM_AREA       tCustomArea;        /* 회원사 사용영역              */
    char        sFiller         [137];      /* Filler                       */
} T_AMOUNT_REJECT_DATA;
#define SZ_AMOUNT_REJECT_DATA    (sizeof(T_AMOUNT_REJECT_DATA))

/*-------------------------
 * 프로그램매매 사전공시
 * 회원사 --> 거래소 온라인 TR
 * TCHPGP10001
 *-----------------------*/
typedef struct
{
    char        sSeq            [11];       /* 일련번호						*/
    char        sTrCode         [11];       /* 개별 TR   					*/
    char        sOrdDd          [8];        /* 호가일자                     */
    char        sMbrNo          [5];        /* 회원번호                     */
    char        sIsuCd          [12];       /* 종목코드                     */
	char		sBasketNo		[6];		/* 바스켓 번호					*/
    char        sBidaskTpCd     [1];        /* 매수매도구분코드             */
	char		sPtBeforeTypeCd [3];		/* PT사전공시구분코드			*/		
	char		sPtBeforeMthdCd	[1];		/* PT사전공시방법코드			*/	
	char		sMarketId		[3];		/* 현물시장 ID					*/
    char        sOrdQty         [12];       /* 호가수량                     */
    char        sOrdTm          [9];        /* 호가시각                     */
	T_CUSTOM_AREA       tCustomArea;        /* 회원사 사용영역              */
    char        sFiller         [178];      /* Filler                       */
} T_PROGRAM_DATA;
#define SZ_PROGRAM_DATA    (sizeof(T_PROGRAM_DATA))


/*-------------------------
 * 회원체결결과  
 * TTRTDP21301
 * 거래소 --> 회원사
 *-----------------------*/
typedef struct
{
    char        sSeq         	[11];      	/* 주문일련번호     			*/
    char        sTrCode         [11];       /* 개별 TR   					*/
	char    	sRegulOffhrTpCd	[1];        /* 정규시간외구분코드   		*/
                                            /* 1) 일반호가  				*/
											/* 1 : 정규장  					*/
											/* 2 : 장개시전시간외  			*/
											/* 3 : 장종료후 시간외종가  	*/
											/* 4 : 장종료후시간외단일가    	*/ 
											/* 2) 대량호가 					*/
											/* 1 : 정규장  					*/
											/* 2 : 장개시전시간외  			*/
											/* 5 : 장종료후시간외(대량) 	*/
	char    	sMbrNo			[5];        /* 회원번호    					*/
    char    	sBrnNo			[5];  		/* 지점번호						*/
    char    	sOrdId			[10];  		/* 주문ID                    	*/
    char    	sOrgnOrdId		[10];    	/* 원주문ID    					*/
    char        sIsuCd          [12];       /* 종목코드                     */
	char    	sTrdNo			[11];     	/* 체결번호  					*/
	char    	sTrdPrc			[11];       /* 체결가격     				*/
	char    	sTrdvol			[10]; 		/* 체결수량 					*/
	char    	sTrdType		[2]; 		/* 체결유형코드 				*/
	char		sTrdDt			[8];		/* 체결일자						*/
	char		sTrdTm			[9];		/* 체결시각	hhmmss.000			*/
											/* 끝세자리는 0으로 Setting		*/
	char    	sFstmmTrdPrc	[11];      	/* 근월물체결가격				*/
	char    	sScndmmTrdPrc	[11];     	/* 원월물체결가격				*/
	char    	sBidaskTpCd		[1];        /* 매수매도구분코드 			*/
                                            /* 1 : 매수,    2 : 매도       	*/
    char        sAcntNo         [12];       /* 계좌번호                     */
    char    	sMmOrdTpNo		[11];       /* 시장조성자호가구분번호    	*/
    char    	sTrstMbrNo		[5];		/* 위탁회원번호      			*/
    char    	sSbRghtAcntNo	[12];     	/* 대용주권계좌번호         	*/
	T_CUSTOM_AREA       tCustomArea;        /* 회원사 사용영역              */
    char        sFiller         [81];       /* Filler                       */
} T_SETTLE_DATA;
#define	SZ_SETTLE_DATA	(sizeof(T_SETTLE_DATA))


/*-------------------------
 * 회원처리호가 
 * 정상 TTRODP11301
 * 거부 TTRODP11321
 * 자동취소 TTRODP11303
 * 거래소 매매  --> 회원사
 *-----------------------*/
typedef struct
{
    char        sSeq         	[11];      		/* 주문일련번호     			*/
    char        sTrCode         [11];          	/* 개별 TR   					*/
	char    	sRegulOffhrTpCd	[1];           	/* 정규시간외구분코드   		*/
	char    	sMbrNo			[5];        	/* 회원번호    					*/
    char    	sBrnNo			[5];  			/* 지점번호						*/
    char    	sOrdId			[10];  			/* 주문ID                    	*/
    char    	sOrgnOrdId		[10];    		/* 원주문ID    					*/
    char        sIsuCd          [12];           /* 종목코드                     */
	char    	sBidaskTpCd		[1];        	/* 매수매도구분코드 			*/
	char    	sModcanclTpCd	[1];    		/* 정정취소구분코드   			*/
                                            	/* 1 : 정상,   					*/ 
												/* 2 : 정정,   					*/
												/* 3 : 취소 					*/
    char        sAcntNo         [12];           /* 계좌번호                     */
    char        sOrdQty         [10];           /* 호가수량                     */
	char    	sOrdPrc			[11];    		/* 호가가격     				*/
	char    	sOrdTpCd		[1];    		/* 호가유형코드					*/
	char   		sOrdCondCd		[1];     		/* 호가조건코드   				*/
	char    	sMmOrdTpNo		[11];  			/* 시장조성자호가구분번호  		*/
	char        sTrstkID        [5];            /* 자사주신고서ID               */
	char        sTrstkTpCd      [1];            /* 자사주매매방법코드           */
                                                /* 0 해당없음					*/
												/* 1 자사주일반					*/
                                                /* 2 한은 등 자사주				*/
                                                /* 3 정부 등 자사주            	*/
	char        sSrtsellTpCd    [2];            /* 매도 유형코드                */
	char        sCreditTpCd     [2];            /* 신용구분코드                 */
	char        sTrstPrincTpCd  [2];            /* 위탁자기구분코드             */
	char        sTrstMbrNo      [5];            /* 위탁회원번호                 */
	char        sPtTpCd         [2];            /* PT구분코드                   */
	char        sSbRghtAcntNo   [12];           /* 대용주권계좌번호             */
    char        sAcntTpCd       [2];            /* 계좌구분코드                 */
    char        sAcntMrgnTpCd   [2];            /* 계좌증거금유형코드           */
    char        sCntrCd         [3];            /* 국가코드                     */
    char        sInvstTpCd      [4];            /* 투자자구분코드               */
    char        sForninvstTpCd  [2];            /* 외국인투자자구분코드         */
    char        sOrdMediaTpCd   [1];            /* 주문매체구분코드             */
    char        sOrdererid      [12];           /* 주문자식별정보               */
    char        sOrdDd          [8];            /* 호가일자                     */
    char        sMbrOrdTm       [9];            /* 회원사주문시각               */
	T_CUSTOM_AREA       tCustomArea;        	/* 회원사 사용영역              */
	char    	sRModcanclOrdQty[10];       	/* 실정정취소호가수량  			*/
	char    	sAutoCanclProcsTpCd[1];         /* 자동취소처리구분코드    		*/
	char    	sOrdRejRsnCd	[4];            /* 호가거부사유코드  			*/
    char        sFiller         [58];           /* Filler                       */
} T_ACCEPT_ORDER_DATA;
#define	SZ_ACCEPT_ORDER_DATA	(sizeof(T_ACCEPT_ORDER_DATA))


/*-------------------------
 * 대량체결 결과
 * TTRBTP22301 
 * p.69
 * 거래소 --> 회원사
 *-----------------------*/
typedef struct
{
    char        sSeq            [11];        	/* 주문일련번호                 */
    char        sTrCode         [11];          	/* 개별 TR                      */
    char        sRegulOffhrTpCd [1];           	/* 정규시간외구분코드           */
                                               	/* 1) 일반호가					*/
                                               	/* 1 : 정규장					*/
                                                /* 2 : 장개시전시간외			*/
                                               	/* 3 : 장종료후 시간외종가		*/
                                               	/* 4 : 장종료후시간외단일가		*/
                                                /* 2) 대량호가					*/
                                                /* 1 : 정규장					*/
                                                /* 2 : 장개시전시간외			*/
                                               	/* 5 : 장종료후시간외(대량)    	*/
    char        sMbrNo          [5];           	/* 회원번호                     */
    char        sBrnNo          [5];            /* 지점번호                     */
    char        sOrdId          [10];           /* 주문ID                       */
    char        sIsuCd          [12];           /* 종목코드                     */
	char		sBlockType		[1];			/* 대량매매 구분				*/
    char        sTrdNo          [11];          	/* 체결번호                     */
    char        sTrdPrc         [11];          	/* 체결가격                     */
    char        sTrdvol         [10];           /* 체결수량                     */
    char        sTrdType        [2];            /* 체결유형코드                 */
    char        sTrdDt          [8];            /* 체결일자                     */
    char        sTrdTm          [9];            /* 체결시각 hhmmss.000          */
                                                /* 끝세자리는 0으로 Setting     */
    char        sBidaskTpCd     [1];            /* 매수매도구분코드             */
                                                /* 1 : 매수,    2 : 매도        */
    char        sAcntNo         [12];           /* 계좌번호                     */
    char    	sNegoNo			[6]; 			/* 협상번호    					*/
    char    	sNegoDtlNo		[6];            /* 협상상세번호              	*/
	char		sNegotiatorId	[10];			/* 협상자ID						*/			
	T_CUSTOM_AREA       tCustomArea;        	/* 회원사 사용영역              */
    char        sFiller         [118];			/* Filler                       */
} T_AMOUNT_SETTLE_DATA;
#define SZ_AMOUNT_SETTLE_DATA  (sizeof(T_AMOUNT_SETTLE_DATA))


/*-------------------------
 * 회원대량처리호가 
 * 정상 : 				TTRBOP12301
 * 거부 : 				TTRBOP12321
 * 협의정상 : 			TTRBOP12302
 * 협의거부 : 			TTRBOP12322
 * 협의자동취소처리 : 	TTRBOP12303
 * p.71
 * 거래소 --> 회원사 (정정 취소 대량 처리)
 *-----------------------*/
typedef struct
{
    char        sSeq            [11];           /* 주문일련번호                 */
    char        sTrCode         [11];           /* 개별 TR                      */
    char        sRegulOffhrTpCd [1];            /* 정규시간외구분코드           */
                                                /* 1) 일반호가					*/
                                                /* 1 : 정규장					*/
                                               	/* 2 : 장개시전시간외			*/
                                                /* 3 : 장종료후 시간외종가		*/
                                                /* 4 : 장종료후시간외단일가		*/
                                                /* 2) 대량호가					*/
                                                /* 1 : 정규장					*/
                                                /* 2 : 장개시전시간외			*/
                                                /* 5 : 장종료후시간외(대량)    	*/
    char        sMbrNo          [5];            /* 회원번호                     */
    char        sBrnNo          [5];            /* 지점번호                     */
    char        sOrdId          [10];           /* 주문ID                       */
    char    	sOrgnOrdId		[10];    		/* 원주문ID    					*/
    char        sIsuCd          [12];           /* 종목코드                     */
    char        sBlktrdTpCd     [1];            /* 대량매매구분코드             */
                                                /* 1 대량   					*/
												/* 2 바스켓    					*/
												/* 3 협의대량 					*/
    char        sBidaskTpCd     [1];            /* 매수매도구분코드             */
    char        sModcanclTpCd   [1];            /* 정정취소구분코드             */
                                                /* 1 : 정상    					*/
												/* 2 : 정정						*/
												/* 3 : 취소 					*/
    char        sAcntNo         [12];           /* 계좌번호                     */
                                                /* * 지점번호(4)+계좌번호(8)    */
    char        sOrdQty         [10];           /* 호가수량                     */
    char        sOrdPrc         [11];           /* 호가가격                     */
    char        sTrstkId        [5];            /* 자사주신고서ID               */
    char        sTrstkTpCd      [1];            /* 자사주매매방법코드           */
                                                /* 0 해당없음					*/
                                                /* 1 자사주일반					*/
                                                /* 2 한은 등 자사주				*/
                                                /* 3 정부 등 자사주            	*/
    char        sOrdTpCd        [2];            /* 매도유형코드                 */
    char        sCreditTpCd     [2];            /* 신용구분코드                 */
    char        sTrstPrincTpCd  [2];            /* 위탁자기구분코드             */
    char        sAcntTpCd       [2];            /* 계좌구분코드                 */
    char        sAcntMrgnTpCd   [2];            /* 계좌증거금유형코드           */
    char        sCntrCd         [3];            /* 국가코드                     */
    char        sInvstTpCd      [4];            /* 투자자구분코드               */
    char        sForninvstTpCd  [2];            /* 외국인투자자구분코드         */
    char        sOrdMediaTpCd   [1];            /* 주문매체구분코드             */
    char        sOrdererid      [12];           /* 주문자식별정보               */
    char        sNegoNo         [6];            /* 협상번호                     */
    char        sNegoDtlNo      [6];            /* 협상상세번호                 */
    char        sNegoprnId      [10];           /* 협상자ID                     */
    char        sCtpartMbrNo    [5];            /* 상대회원번호                 */
    char        sCtpartAcntNo   [12];           /* 상대계좌번호                 */
    char        sNegoCompltTm   [9];            /* 협의완료시각                 */
    char        sOrdDd          [8];            /* 호가일자                     */
    char        sMbrOrdTm       [9];            /* 회원사주문시각               */
	T_CUSTOM_AREA       tCustomArea;            /* 회원사 사용영역              */
	char    	sOrdRejRsnCd	[4];			/* 호가거부사유코드				*/
	char    	sSpotPrice		[11];			/* 현물가격						*/
    char        sFiller         [41];           /* Filler                       */
} T_AMOUNT_ACCEPT_DATA;
#define SZ_AMOUNT_ACCEPT_DATA  (sizeof(T_AMOUNT_ACCEPT_DATA))


/*-------------------------
 * 대량매매주문서(K-BLOX --> Kyobo)
 * TTBSDP40002 
 * p.77
 * 거래소 --> 회원사
 *-----------------------*/
typedef struct
{
    char        sSeq            [11];    		/* 주문일련번호                 */
    char        sTrCode         [11];          	/* 개별 TR                      */
    char        sRegulOffhrTpCd [1];           	/* 정규시간외구분코드           */
                                                /* 1) 일반호가					*/
                                                /* 1 : 정규장					*/
                                                /* 2 : 장개시전시간외			*/
                                                /* 3 : 장종료후 시간외종가		*/
                                                /* 4 : 장종료후시간외단일가		*/
                                                /* 2) 대량호가					*/
                                                /* 1 : 정규장					*/
                                                /* 2 : 장개시전시간외			*/
                                                /* 5 : 장종료후시간외(대량)    	*/
    char        sMbrNo          [5];            /* 회원번호                     */
    char        sIsuCd          [12];           /* 종목코드                     */
    char        sBlktrdTpCd     [1];            /* 대량매매구분코드             */
                                                /* 1 대량   					*/
												/* 2 바스켓    					*/
												/* 3 협의대량 					*/
    char        sBidaskTpCd     [1];            /* 매수매도구분코드             */
    char        sTrstkId        [5];            /* 자사주신고서ID               */
    char        sTrstkTpCd      [1];            /* 자사주매매방법코드           */
                                                /* 0 해당없음					*/
                                                /* 1 자사주일반					*/
                                                /* 2 한은 등 자사주				*/
                                                /* 3 정부 등 자사주            	*/
    char        sNegoInvalidCd	[1];            /* 협상무효구분코드				*/
    char        sNegoNo         [6];            /* 협상번호                     */
    char        sNegoDtlNo      [6];            /* 협상상세번호                 */
    char        sNegoprnId      [10];           /* 협상자ID                     */
    char        sAcntNo         [12];           /* 계좌번호                     */
                                                /* 지점번호(4)+계좌번호(8)    	*/
    char        sOrdQty         [10];           /* 호가수량                     */
    char        sOrdPrc         [11];           /* 호가가격                     */
	char		sCounterPartTpCd[1];			/* 상대자사주구분코드			*/
	T_CUSTOM_AREA       tCustomArea;        	/* 회원사 사용영역              */
    char        sOrdTpCd        [2];            /* 매도유형코드                 */
	char		sForeignUniqNo	[6];			/* 한도시스템외국인교유번호		*/ 
	char		sAcntModYn		[1];			/* 계좌정정여부					*/
    char        sTransDt		[8];            /* 전송일자                     */
    char        sTransTm		[9];            /* 주문서전송시각 				*/
	char		sTotalNegoVol	[15];			/* 총협상수량					*/
    char        sFiller         [117];			/* Filler                       */
} T_AMOUNT_REQUEST_DATA;
#define SZ_AMOUNT_REQUEST_DATA  (sizeof(T_AMOUNT_REQUEST_DATA))


/*-------------------------
 * 종목마감 
 * TTRMIP31304 
 * p.80
 * 거래소 --> 회원사
 *-----------------------*/
typedef struct
{
    char        sSeq            [11];         	/* 주문일련번호                 */
    char        sTrCode         [11];          	/* 개별 TR                      */
    char        sRegulOffhrTpCd [1];           	/* 정규시간외구분코드           */
                                                /* 1) 일반호가					*/
                                                /* 1 : 정규장					*/
                                                /* 2 : 장개시전시간외			*/
                                                /* 3 : 장종료후 시간외종가		*/
                                                /* 4 : 장종료후시간외단일가		*/
                                                /* 2) 대량호가					*/
                                                /* 1 : 정규장					*/
                                                /* 2 : 장개시전시간외			*/
                                                /* 5 : 장종료후시간외(대량)    	*/
    char        sIsuCd          [12];           /* 종목코드                     */
	char		sIsuClosingPrice[11];			/* 종목마감 종가				*/
	char		sIsuClosingTp	[1];			/* 종목마감가격구분코드			*/
	char		sIsuClosingUpper[11];			/* 종목마감시간외단일가상한가	*/
	char		sIsuClosingLower[11];			/* 종목마감시간외단일가하한가	*/ 
    char        sFiller         [131];          /* Filler                       */
} T_MARKET_CLOSE_DATA;
#define SZ_MARKET_CLOSE_DATA  (sizeof(T_MARKET_CLOSE_DATA))

/*-------------------------
 * 체결인터페이스종료 
 * TCHTDP99000 
 * p.81
 * 거래소 --> 회원사
 *-----------------------*/
typedef struct
{
    char        sSeq            [11];         	/* 주문일련번호                 */
    char        sTrCode         [11];          	/* 개별 TR                      */
    char        sTransDt        [8];           	/* 전송일자                     */
    char        sTransTm        [9];           	/* 전송시각    					*/
    char        sFiller         [261];         	/* Filler                       */
} T_IF_CLOSE_DATA;
#define SZ_IF_CLOSE_DATA  (sizeof(T_IF_CLOSE_DATA))


/*-------------------------
 * 공개장운영 	TTRMIP31301
 * 공개정보		TTRMIP32301 
 * 기준가결정	TTRMIP31302
 * 임의종료 	TTRMIP31303
 * p.148
 * 거래소 --> 회원사
 *-----------------------*/
typedef struct
{
    char        sSeq            [11];        	/* 주문일련번호   				*/
	char		sTrCode			[11];			/* 개별 TR						*/
    char        sData         	[178];         	/* Data							*/
} T_MARKET_INFO_DATA;
#define SZ_MARKET_INFO_DATA  (sizeof(T_MARKET_INFO_DATA))


#endif

