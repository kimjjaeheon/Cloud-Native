#ifndef __jcache_def_h__
#define __jcache_def_h__

#define MAX_FUNC_STR_LEN		70
#define MAX_FILE_STR_LEN		100

#endif /* __jcache_def_h__ */
