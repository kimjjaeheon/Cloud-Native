#ifndef __jcache_hash_tbl_h__
#define __jcache_hash_tbl_h__

#ifdef _SMALL
        #define JCACHE_HASH_IDX_SIZE       (128 * 128)
        #define JCACHE_HASH_ARR_SIZE       5000
#else
        #define JCACHE_HASH_IDX_SIZE       (256 * 256 * 64)
        #define JCACHE_HASH_ARR_SIZE       2000000
#endif

#define JCACHE_HASH_IDX_MASK       (JCACHE_HASH_IDX_SIZE - 1)

/* JCACHE_HASH STACK LIST */
typedef struct
{
	u_int top;
	u_int idx[JCACHE_HASH_ARR_SIZE];
} JCACHE_HASH_STK;

/* Package,Method Cache Info HASH 저장 로그 */
typedef struct
{
	/* Package,Method별 고유 HashCode 생성 */
	int  hash_code;
	char package_arr[MAX_FILE_STR_LEN + 1];
	int  package_len;
	char method_arr[MAX_FUNC_STR_LEN + 1];
	int  method_len;
	/* Hash 최근 접근 시간(초) */
	time_t lasted_access;
} JCACHE_HASH_ARR;

/* JCACHE HASH 저장 엘리먼트*/
typedef struct
{
	u_int			my_idx;
	int				hash_idx;
	int				pre_idx;
	int				next_idx;
	JCACHE_HASH_ARR	param;
} JCACHE_HASH_ARR_LIST;

typedef struct
{
	u_int alloc_cnt;
	int h_idx[JCACHE_HASH_IDX_SIZE];
	JCACHE_HASH_ARR_LIST h_arr[JCACHE_HASH_ARR_SIZE];
	JCACHE_HASH_STK available;
	JCACHE_HASH_STK used;
} JCACHE_HASH_TBL;

#endif /*__jcache_hash_tbl_h__*/
