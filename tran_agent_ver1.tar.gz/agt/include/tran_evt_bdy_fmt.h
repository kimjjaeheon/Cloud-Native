#ifndef __tran_evt_bdy_fmt_h__
#define __tran_evt_bdy_fmt_h__

#include "tran_def_len.h"

typedef struct
{
	char evt_id[EVT_ID_LEN + 1];
	char evt_tr_cd[EVT_TR_CD_LEN + 1]; 
	char evt_info_fld[EVT_INFO_FLD_LEN + 1]; 
	char evt_info_str[EVT_INFO_STR_LEN + 1];
} TRAN_EVENT_BDY_FMT;

#endif /*__tran_evt_bdy_fmt_h__*/
