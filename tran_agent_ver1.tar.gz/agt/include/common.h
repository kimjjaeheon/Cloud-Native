#ifndef __common_h__
#define __common_h__

enum boolean { false, true };
typedef enum boolean bool;

#define _(x) gettext(x)

#define NULL_IDX				-1

#define RET_OK					1
#define RET_FAIL				-1

#define MAX_AGT_CRITICAL_SECTIONS	8
#define SEM_TRAN_AGT_SHM			0
#define SEM_TRAN_DEFAULT_SHM		SEM_TRAN_AGT_SHM

/* LOG_TYPE */
#define START_LOG				'1'
#define END_LOG					'2'

/* INTERFACE */
#define MAX_IF_NUM				42
#define IF00					0
#define IF01					1
#define IF02					2
#define IF03					3
#define IF04					4
#define IF05					5
#define IF06					6
#define IF07					7
#define IF08					8
#define IF09					9
#define IF10					10	
#define IF11					11
#define IF12					12
#define IF13					13
#define IF14					14
#define IF15					15
#define IF16					16
#define IF17					17
#define IF18					18
#define IF19					19
#define IF20					20
#define IF21					21
#define IF22					22
#define IF23					23
#define IF24					24
#define IF25					25
#define IF26					26
#define IF27					27
#define IF28					28
#define IF29					29
#define IF30					30
#define IF31					31
#define IF32					32
#define IF33					33
#define IF34					34
#define IF35					35
#define IF36					36
#define IF37					37
#define IF38					38
#define IF39					39
#define IF40					40
#define IF41					41

#define IFID(a) (a[0] - '0') * 10 + a[1] - '0'

/* LOG_TYPE */
#define LOG_TYPE1				'1'
#define LOG_TYPE2				'2'
#define LOG_TYPE7				'7'
#define LOG_TYPE8				'8'
#define LOG_TYPE9				'9'

#define START_TYPE				'1'
#define END_TYPE				'2'
#define ERR_TYPE				'9'
#define INFO_TYPE				'I'
#define DBIO_TYPE				'B'
#define CALL_STACK_TYPE			'C'
#define ERRINFO_TYPE			'E'
#define V_EVENT_TYPE			'V'
#define INFO_EX_TYPE			'X'
#define SQL_STMT_TYPE			'Q'

/* RESULT_FLAG */
#define GENERAL_START			'S'
#define PROCESSING				'P'
#define GENERAL_END				'F'
#define NO_START_END			'G'
#define GENERAL_ERROR			'E'
#define NO_START_ERROR			'D'
#define SERVICE_TIME_OVER		'O'
#define GENERAL_INFO			'I'
#define GENERAL_INFO_STR		"I"
#define TRAN_EVENT_V			'V'
#define TRAN_EVENT_N			'N'
#define DBIO_CALL_INFO			'B'
#define SQL_STMT				'Q'
#define UNKNOWN_RESULT			'U'
#define INCL_ERROR_END			'R'
#define ERROR_INFO				'J'
#define INFO_EX					'X'

/* LOG FILETER FLAGSET */
#define FLAG_ON					'1'
#define FLAG_OFF				'0'

#define KIBS_FLAGSET_ID			0
#define DUMMY1_FLAGSET_ID		1
#define DUMMY2_FLAGSET_ID		2
#define DUMMY3_FLAGSET_ID		3
#define DUMMY4_FLAGSET_ID		4
#define DUMMY5_FLAGSET_ID		5
#define DUMMY6_FLAGSET_ID		6
#define NORMAL_FLAGSET_ID		7
#define ABNORMAL_FLAGSET_ID		8
#define INFO_FLAGSET_ID			9

/* PTRC Hash 상태 값 */
#define HASH_ALLOC_TRC_STS		100
#define TRAN_INIT_TRC_STS		101
#define TRAN_START_TRC_STS		102
#define TRAN_END_TRC_STS		103
#define TRAN_DONE_TRC_STS		104
/*
#define TRAN_EVT_SEND_TRC_STS	105
*/
#define PID_NOT_EXIST			106
#define HASH_CLEAR_TRC_STS		107

/* EXECUTION TIME_NULL STRING */
#define EXE_TIME_NULL_STR		"0000000000"

/* SPACE STRING*/
#define SPACE32_STR				"                                "

#define CORRECT_LIMIT			5 		/* 서비스 타임아웃 임계치 보정(초) */

#if 0
#define HTS_LOG_FILE			0   /* */
#define CHN_LOG_FILE			1   /* 통합단말 - SMART-CS */
#define COM_LOG_FILE			3   /* */
#define EAI_LOG_FILE			4   /* EAI - VITRIA */
#define FEP5_LOG_FILE			5   /* 주문FEP - IMECO */
#define INFO_EX_LOG_FILE		9   /* 시스템 CPU/MEM정보 전송 */
#define TMAX_SLOG_FILE			10  /* TMAX-SLOG */
#define TUXEDO_ULOG_FILE		11  /* TUXEDO-ULOG */
#define ORDER_ULOG_FILE			12  /* 주문로그 */
#define EFS_LOG_FILE			13  /* 인터넷 뱅킹 로그 */
#define ETRADE_FEP_LOG_FILE		14  /* ETRADE FEP 로그 */
#define SHINHAN_EAI_LOG_FILE	15  /* SHINHAN EAI 로그 */
#endif

#define TONG_LOG_FILE			1   /* TONG 로그 */
#define WAS_INIT_FAIL_LOG		2   /* WAS 초기화 실패 로그 */
#define ANY_LOG_FILE			3   /* FEP - ANYLINK */
#define ANY_LOG_CUS_FILE		4   /* FEP - ANYLINK CUS */
#define INFO_EX_LOG_FILE		9   /* 시스템 CPU/MEM정보 전송 */

#define EUC_KR 	0
#define UTF_8 	1

#endif /*__common_h__*/
