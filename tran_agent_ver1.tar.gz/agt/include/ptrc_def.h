#ifndef __ptrc_def_h__
#define __ptrc_def_h__

#define LOG_TYPE_LEN            1   /* 로그타입  */
#define LOG_INTERFACE_LEN       2   /* 로그인터페이스  */
#define TR_SECTION_LEN          1   /* 구간 구분( E2E:0, WEB:1, MCA:2, WAS:3, WAS-DB:4, TP:5, TP-DB:6, EAI:7, 대외(FEP):8, ETC:9 ) */
#define GID_UNI_LEN             30  /* GLOBAL ID UNIQ (30 byte) */
#define GID_SEQ_LEN             2   /* GLOBAL ID SEQ  ( 2 byte) */
#define GID_LEN                 GID_UNI_LEN + GID_SEQ_LEN  /* GLOBAL ID */  
#define SERVER_ID_LEN           15  /* 서버ID(프로세스명(TP서버,WAS인스턴스)) */
#define SERVICE_ID_LEN          16  /* 서비스ID */
#define HOST_NAME_LEN           64  /* 호스트명 */
#define PID_LEN                 8   /* 프로세스ID */
#define TID_LEN                 15  /* Thread ID */
#define IDX_LEN                 5   /* GLOBAL VAR INDEX */
#define LOG_DAY_LEN             8   /* 로그일자 */
#define LOG_TIME_LEN            12  /* 로그일시 */

/* ITEM : MAX_SQL_STMT_BUF_LEN */
#define MAX_SQL_STMT_BUF_LEN    8192 /* SQL문 수집버퍼 - Full String */
#define MAX_SQL_STMT_KEEP_STR_LEN    MAX_SQL_STMT_BUF_LEN /* SQL문 수집버퍼 - global_var 저장 */

/* 동적 함수호출 정보 Depth, 함수명 지정 */
#define MAX_CALL_TRC_DEPTH      50
#define MAX_FUNC_STR_LEN        70
#define MAX_FILE_STR_LEN        100

/* SQL문 처리 */
#define MAX_SQL_STMT_KEEP_CNT	5  
#define MAX_SQL_STMT_BUF_LEN    8192

/* PTRC_HASH의 프로세스명 기억 */
#define PROC_NM_LEN             30

/* PTRC_HASH의 WAS 컨테이너명 기억 */
#define CONT_NM_LEN             30

/* PTRC_HASH의 여분필드 정의 */
#define	RSV_FLD_LEN                     8
#define RSV_FLD_0_CTC_FLAG              0  /* 여분필드(RSV_FLD) byte 0 : 온라인('O')/센터컷('C') 거래유무 저장 Flag위치 */
#define RSV_FLD_1_TRC_STS_FLAG          1  /* 여분필드(RSV_FLD) byte 1 : TRAN_DONE 수행시 trc_sts값 저장 Flag 위치 */
#define RSV_FLD_2_START_END_PAIR_FLAG   2  /* 여분필드(RSV_FLD) byte 2 : TRAN_START, TRAN_END PAIR 발생 유무 */
#define RSV_FLD_3_ERR_RC_YN_FLAG        3  /* 여분필드(RSV_FLD) byte 3 : 최초 함수 에러리턴 감지를 위한 Flag */
#define RSV_FLD_4_SVCTIMEOUT_FLAG       4  /* 여분필드(RSV_FLD) byte 4 : Tmax tpsvctimeout 발생 감지를 위한 Flag */
#define RSV_FLD_5_DBIO_STS_FLAG         5  /* 여분필드(RSV_FLD) byte 5 : Tmax pfmDbioXXX() 함수 처리 상태 */

#define DBIO_ENTRY				0 /* DBIO함수 진입 */
#define DBIO_SQLCXT_RUN			1 /* sqlcxt 수행중 */
#define DBIO_SQLCXT_EXIT		2 /* sqlcxt 종료 */

/*
	공통 헤더 로그항목
*/

typedef struct
{
	char log_type[LOG_TYPE_LEN + 1];
	char log_interface[LOG_INTERFACE_LEN + 1];
	char tr_section[TR_SECTION_LEN + 1];
	char gid[GID_LEN + 1];
	char server_id[SERVER_ID_LEN + 1];
	char service_id[SERVICE_ID_LEN + 1];
	char host_name[HOST_NAME_LEN + 1];
	char pid[PID_LEN + 1];
	char tid[TID_LEN + 1];
	char idx[IDX_LEN + 1];
	char pidx[IDX_LEN + 1];
	char log_day[LOG_DAY_LEN + 1];
	char log_time[LOG_TIME_LEN + 1];
} TRAN_LOG_HDR;

/*
	SQL문 KEEP 로그 바디
*/
typedef struct
{
	short   log_len;
	short   sql_code;
	struct  timeval s_tm;
	struct  timeval f_tm;
	/*
	long    exe_usec; 필요한가?
	*/
	char    called_func[MAX_FUNC_STR_LEN + 1];
	char    sql_stmt_keep_str[MAX_SQL_STMT_KEEP_STR_LEN + 1];
	u_int   update_cnt;
} TRAN_SQL_STMT_KEEP_LOG_BDY;

/*
	SQL문 global_var keep 로그 정의
*/
typedef struct
{
	TRAN_LOG_HDR        hdr;
	TRAN_SQL_STMT_KEEP_LOG_BDY  bdy;
} TRAN_SQL_STMT_KEEP_LOG;

#endif /* __ptrc_def_h__ */
