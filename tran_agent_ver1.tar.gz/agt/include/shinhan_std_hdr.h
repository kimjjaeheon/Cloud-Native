#ifndef __shinhan_std_hdr_h__
#define __shinhan_std_hdr_h__

/* EAI CLI 헤더 정보(49 bytes) */
#define CIL_TNR_C_VL_LEN			1		/* 'S'송신 , 'R' 수신 */
#define CIL_MSG_GB_LEN				1		/* 'C' 신한카드 , 'B' 신한은행 */
#define CIL_MCI_PV_SV_ID_LEN	12	/* MCI 서비스인 경우에만 */
#define CIL_PS_BNE_VL_LEN			3		/* 로그 송신 시스템 */
#define CIL_PS_SYS_TNR_DT_LEN	16	/* 메시지 송/수신 시간 */
#define CIL_RQ_RP_DT_LEN			16	/* 로그요청시간 */

typedef struct
{
	char cil_tnr_c_vl[CIL_TNR_C_VL_LEN];
	char cil_msg_gb[CIL_MSG_GB_LEN];
	char cil_mci_pv_sv_id[CIL_MCI_PV_SV_ID_LEN];
	char cil_ps_bne_vl[CIL_PS_BNE_VL_LEN];
	char cil_ps_sys_tnr_dt[CIL_PS_SYS_TNR_DT_LEN];
	char cil_rq_rp_dt[CIL_RQ_RP_DT_LEN];
} SHINHAN_EAI_CIL_HDR;

#define SHINHAN_EAI_CIL_HDR_SZ sizeof(SHINHAN_EAI_CIL_HDR_SZ) 

/* 표준전문 시스템헤더부(284 bytes) */
#define SDD_TG_LTH_LEN				8		/* 표준전문길이 */
#define TG_ECR_CCD_LEN				1		/* 전문암호화구분코드 */
#define SH_GP_CO_CD_LEN				4		/* 신한그룹사코드 */
#define TG_WRT_D_LEN					8		/* 전문작성일자 (Global_ID) */
#define TG_CRT_SYS_NM_LEN			8		/* 전문생성 시스템명 (Global_ID) */
#define SDD_TG_SRL_N_LEN			14	/* 표준전문시리얼번호 (Global_ID) */
#define SDD_TG_PGS_N_LEN			2		/* 표준전문진행번호 (Global_ID) */
#define TG_IP_AR_LEN					32	/* 전문 IP 주소 */
#define TG_MAC_AR_LEN					12	/* 전문 MAC 주소 */
#define EVN_IF_CCD_LEN				1		/* 환경 정보 구분코드 */
#define NI_TI_BNE_CCD_LEN			3		/* 최초 전송시스템 업무구분코드 */
#define TI_BNE_CCD_LEN				3		/* 전송시스템 업무구분코드 */
#define TI_NOD_N_LEN					4		/* 전송노드번호 */
#define XAC_TS_CCD_LEN				1		/* XA거래구분코드 */
#define RQ_SO_CCD_LEN					1		/* 요청응답구분코드 */
#define TS_MTV_CCD_LEN				1		/* 거래동기구분코드 */
#define NI_TG_RQ_DT_LEN				16	/* 최초전문요청일시 */
#define TTL_SE_CCD_LEN				1		/* TTL 사용구분코드 */
#define NI_SR_TM_LEN					6		/* 최초시작시간 */
#define MTN_HMS_LEN						3		/* 유지시분초 */
#define RP_SV_CD_LEN					12	/* 수신서비스코드 */
#define RU_RP_SV_CD_LEN				12	/* 결과수신서비스 코드 */
#define RLT_SV_CD_LEN					12	/* 실제 서비스 코드 */
#define EAI_ITF_ID_LEN				16	/* EAI인터페이스 ID */
#define TG_SO_DT_LEN					16	/* 전문응답일시 */
#define PS_RU_CCD_LEN					1		/* 처리결과구분코드 */
#define OUT_TG_TP_CD_LEN			1		/* 출력전문유형코드 */
#define NI_ER_BNE_CCD_LEN			3		/* 최초오류업무구분코드 */
#define NI_SYS_ER_KCD_LEN			2		/* 최초시스템 오류종류코드 */
#define NI_SDD_TG_ERR_CD_LEN	8		/* 최초표준전문오류코드 */
#define TG_VER_CCD_LEN				3		/* 전문버전 구분코드 */
#define LAG_CCD_LEN						1		/* 언어구분코드 */
#define OM_TS_F_LEN						1		/* 보상거래여부 */
#define MCI_NOD_N_LEN					2		/* MCI 노드 번호 */
#define MCI_SSS_ID_N_LEN			8		/* MCI 세션 ID 번호 */
#define SMU_TS_CD_LEN					1		/* 시뮬레이션 거래코드 */
#define TST_CMI_RLB_CD_LEN		1		/* 테스트커밋롤백코드 */
#define SYS_HDR_PPR_ITM_LEN		55	/* 시스템헤더예비항목 */

typedef struct
{
	char sdd_tg_lth[SDD_TG_LTH_LEN];
	char tg_ecr_ccd[TG_ECR_CCD_LEN];
	char sh_gp_co_cd[SH_GP_CO_CD_LEN];
	char tg_wrt_d[TG_WRT_D_LEN];
	char tg_crt_sys_nm[TG_CRT_SYS_NM_LEN];
	char sdd_tg_srl_n[SDD_TG_SRL_N_LEN];
	char sdd_tg_pgs_n[SDD_TG_PGS_N_LEN];
	char tg_ip_ar[TG_IP_AR_LEN];
	char tg_mac_ar[TG_MAC_AR_LEN];
	char evn_if_ccd[EVN_IF_CCD_LEN];
	char ni_ti_bne_ccd[NI_TI_BNE_CCD_LEN];
	char ti_bne_ccd[TI_BNE_CCD_LEN];
	char ti_nod_n[TI_NOD_N_LEN];
	char xac_ts_ccd[XAC_TS_CCD_LEN];
	char rq_so_ccd[RQ_SO_CCD_LEN];
	char ts_mtv_ccd[TS_MTV_CCD_LEN];
	char ni_tg_rq_dt[NI_TG_RQ_DT_LEN];
	char ttl_se_ccd[TTL_SE_CCD_LEN];
	char ni_sr_tm[NI_SR_TM_LEN];
	char mtn_hms[MTN_HMS_LEN];
	char rp_sv_cd[RP_SV_CD_LEN];
	char ru_rp_sv_cd[RU_RP_SV_CD_LEN];
	char rlt_sv_cd[RLT_SV_CD_LEN];
	char eai_itf_id[EAI_ITF_ID_LEN];
	char tg_so_dt[TG_SO_DT_LEN];
	char ps_ru_ccd[PS_RU_CCD_LEN];
	char out_tg_tp_cd[OUT_TG_TP_CD_LEN];
	char ni_er_bne_ccd[NI_ER_BNE_CCD_LEN];
	char ni_sys_er_kcd[NI_SYS_ER_KCD_LEN];
	char ni_sdd_tg_err_cd[NI_SDD_TG_ERR_CD_LEN];
	char tg_ver_ccd[TG_VER_CCD_LEN];
	char lag_ccd[LAG_CCD_LEN];
	char om_ts_f[OM_TS_F_LEN];
	char mci_nod_n[MCI_NOD_N_LEN];
	char mci_sss_id_n[MCI_SSS_ID_N_LEN];
	char smu_ts_cd[SMU_TS_CD_LEN];
	char tst_cmi_rlb_cd[TST_CMI_RLB_CD_LEN];
	char sys_hdr_ppr_itm[SYS_HDR_PPR_ITM_LEN];
} SHINHAN_STD_HDR1_FMT;

/* 표준전문 시스템헤더부(303 bytes) */
#define TG_MSG_TP_CD_LEN				1		/* 전문메시지유형코드 */
#define PCK_EN_LEN							8		/* 처리자사번 */
#define PCK_DCD_LEN							4		/* 처리자부서코드 */
#define PCK_DTY_CD_LEN					5		/* 처리자직무코드 */
#define PCK_JBT_CD_LEN					5		/* 처리자직위코드 */
#define PCK_KEY_N_LEN						3		/* 처리자KEY번호 */
#define PCK_OPS_HCD_LEN					4		/* 처리자소속지점코드 */
#define APV_K_CN_LEN						1		/* 승인자수*/
#define PMY_APV_K_DCD_LEN				4		/* 1차승인자 부서코드 */
#define PMY_APV_K_EN_LEN				8		/* 1차승인자사번 */
#define PMY_APV_K_DTY_CD_LEN		5		/* 1차승인자직무코드 */
#define PMY_APV_K_JBT_CD_LEN		5		/* 1차승인자직위코드 */
#define PMY_APV_K_KEY_N_LEN			3		/* 1차승인자KEY번호 */
#define SDY_APV_K_DCD_LEN				4		/* 2차승인자부서코드 */
#define SDY_APV_K_EN_LEN				8		/* 2차승인자사번 */
#define SDY_APV_K_DTY_CD_LEN		5		/* 2차승인자직무코드 */
#define SDY_APV_K_JBT_CD_LEN		5		/* 2차승인자직위코드 */
#define SDY_APV_K_KEY_N_LEN			3		/* 2차승인자KEY번호 */
#define SH_SCE_N_LEN						10	/* 신한화면번호 */
#define ITF_ID_LEN							8		/* 인터페이스ID */
#define BX_TS_CD_LEN						4		/* 대외거래코드 */
#define BK_TMN_ILL_BN_N_LEN			4		/* 은행단말기설치지점번호 */
#define BK_TMN_ILL_ISM_N_LEN		4		/* 은행단말기설치기기번호 */
#define K_TMN_TS_RQ_SRL_LEN			8		/* 은행단말기거래요청시리얼번호 */
#define BK_TS_BN_N_LEN					4		/* 은행단말거래지점번호 */
#define BK_TS_BN_ISM_N_LEN			4		/* 은행단말거래기기번호 */
#define BK_BNB_PRT_CNC_N_LEN		1		/* 은행통장프린터접속번호 */
#define BK_TMN_RP_BE_CD_LEN			1		/* 은행단말수신가능코드 */
#define BK_CLO_CD_LEN						1		/* 은행마감후코드 */
#define BK_ISM_ILL_GP_CD_LEN		4		/* 은행기기설치그룹사코드 */
#define BK_MDA_CCD_LEN					8		/* 은행매체구분코드 */
#define BK_BNE_BEG_CCD_LEN			1		/* 은행업무개시구분코드 */
#define BK_TNS_NOD_CCD_LEN			5		/* 은행송신노드구분코드 */
#define BK_SVC_NR_BN_N_LEN			4		/* 은행용역관리지점번호 */
#define BK_WND_CD_LEN						2		/* 은행창구코드 */
#define BK_SI_OR_CCD_LEN				1		/* 은행전표발생구분코드 */
#define BK_SCE_PUT_EVN_CCD_LEN	1		/* 은행화면입력실습환경구분코드 */
#define BK_SCE_PUT_SCA_N_LEN		4		/* 은행화면입력실습시나리오번호 */
#define K_SCE_PUT_PCI_ATL_LEN		2		/* 은행화면입력실습액션번호 */
#define BK_ARY_BN_N_LEN					4		/* 은행계리지점코드 */
#define BK_BSN_BN_N_LEN					4		/* 은행영업지점번호 */
#define BK_CSL_EN_LEN						8		/* 은행상담사번 */
#define BK_UFC_CHL_USR_LEN			1		/* 은행비대면채널사용자메시지출력코드 */
#define BK_CHL_TCD_LEN					2		/* 은행채널유형코드 */
#define ARS_CIB_ID_LEN					20	/* ARS콜ID */
#define ARS_SCA_CD_LEN					6		/* ARS시나리오코드 */
#define TS_COM_PPR_ITM_LEN			96	/* 거래공통예비항목 */

typedef struct
{
	char tg_msg_tp_cd[TG_MSG_TP_CD_LEN];
	char pck_en[PCK_EN_LEN];
	char pck_dcd[PCK_DCD_LEN];
	char pck_dty_cd[PCK_DTY_CD_LEN];
	char pck_jbt_cd[PCK_JBT_CD_LEN];
	char pck_key_n[PCK_KEY_N_LEN];
	char pck_ops_hcd[PCK_OPS_HCD_LEN];
	char apv_k_cn[APV_K_CN_LEN];
	char pmy_apv_k_dcd[PMY_APV_K_DCD_LEN];
	char pmy_apv_k_en[PMY_APV_K_EN_LEN];
	char pmy_apv_k_dty_cd[PMY_APV_K_DTY_CD_LEN];
	char pmy_apv_k_jbt_cd[PMY_APV_K_JBT_CD_LEN];
	char pmy_apv_k_key_n[PMY_APV_K_KEY_N_LEN];
	char sdy_apv_k_dcd[SDY_APV_K_DCD_LEN];
	char sdy_apv_k_en[SDY_APV_K_EN_LEN];
	char sdy_apv_k_dty_cd[SDY_APV_K_DTY_CD_LEN];
	char sdy_apv_k_jbt_cd[SDY_APV_K_JBT_CD_LEN];
	char sdy_apv_k_key_n[SDY_APV_K_KEY_N_LEN];
	char sh_sce_n[SH_SCE_N_LEN];
	char itf_id[ITF_ID_LEN];
	char bx_ts_cd[BX_TS_CD_LEN];
	char bk_tmn_ill_bn_n[BK_TMN_ILL_BN_N_LEN];
	char bk_tmn_ill_ism_n[BK_TMN_ILL_ISM_N_LEN];
	char k_tmn_ts_rq_srl[K_TMN_TS_RQ_SRL_LEN];
	char bk_ts_bn_n[BK_TS_BN_N_LEN];
	char bk_ts_bn_ism_n[BK_TS_BN_ISM_N_LEN];
	char bk_bnb_prt_cnc_n[BK_BNB_PRT_CNC_N_LEN];
	char bk_tmn_rp_be_cd[BK_TMN_RP_BE_CD_LEN];
	char bk_clo_cd[BK_CLO_CD_LEN];
	char bk_ism_ill_gp_cd[BK_ISM_ILL_GP_CD_LEN];
	char bk_mda_ccd[BK_MDA_CCD_LEN];
	char bk_bne_beg_ccd[BK_BNE_BEG_CCD_LEN];
	char bk_tns_nod_ccd[BK_TNS_NOD_CCD_LEN];
	char bk_svc_nr_bn_n[BK_SVC_NR_BN_N_LEN];
	char bk_wnd_cd[BK_WND_CD_LEN];
	char bk_si_or_ccd[BK_SI_OR_CCD_LEN];
	char bk_sce_put_evn_ccd[BK_SCE_PUT_EVN_CCD_LEN];
	char bk_sce_put_sca_n[BK_SCE_PUT_SCA_N_LEN];
	char k_sce_put_pci_atl[K_SCE_PUT_PCI_ATL_LEN];
	char bk_ary_bn_n[BK_ARY_BN_N_LEN];
	char bk_bsn_bn_n[BK_BSN_BN_N_LEN];
	char bk_csl_en[BK_CSL_EN_LEN];
	char bk_ufc_chl_usr[BK_UFC_CHL_USR_LEN];
	char bk_chl_tcd[BK_CHL_TCD_LEN];
	char ars_cib_id[ARS_CIB_ID_LEN];
	char ars_sca_cd[ARS_SCA_CD_LEN];
	char ts_com_ppr_itm[TS_COM_PPR_ITM_LEN];
} SHINHAN_STD_HDR2_FMT;               

typedef struct
{
	SHINHAN_STD_HDR1_FMT shinhan_std_hdr1;
	SHINHAN_STD_HDR2_FMT shinhan_std_hdr2;
} SHINHAN_STD_TOT_HDR;
 
#define SHINHAN_STD_TOT_HDR_SZ sizeof(SHINHAN_STD_TOT_HDR)       /* Size 49 + 284 + 303 = 636 Bytes */


#endif /*__shinhan_std_hdr_h__*/
