#ifndef __tran_event_h__
#define __tran_event_h__

/* TRANManager EVENT-ID List */

/* 일반 */
#define EVENT_CRITICAL_ERROR				"1100" /* 일반 Critical 장애 이벤트 */
#define EVENT_MAJOR_ERROR					"1101" /* 일반 Major 장애 이벤트 */
#define EVENT_MINOR_ERROR					"1102" /* 일반 Minor 장애 이벤트 */
#define EVENT_NORMAL_NOTIFY					"1103" /* 일반 Normal 이벤트 */
#define EVENT_STD_PARSE_ERROR				"1104" /* 표준전문 파싱에러 */
#define EVENT_STD_BIZ_ERROR					"1105" /* 표준전문 처리결과구분코드가 BIZ에러인 경우 */
#define EVENT_STD_TIMEOUT					"1106" /* 표준전문 처리결과구분코드가 TIMEOUT인 경우 */
#define EVENT_STD_SYS_ERROR					"1107" /* 표준전문 처리결과구분코드가 SYSTEM에러인 경우 */

/* 서비스 */
#define EVENT_SERVICE_TIMEOUT				"1200" /* 서비스 타임아웃 */
#define EVENT_SERVICE_TIMEOUT_CALLSTACK		"1201" /* 서비스 타임아웃시 CallStack 정보 */
#define EVENT_SERVICE_ERROR_MESSAGE			"1202" /* 서비스 에러 리턴 메시지 */
#define EVENT_SERVICE_LIMIT_OVER			"1203" /* 서비스 응답시간 임계치 초과 */
#define EVENT_SERVICE_FAIL_PCNT_OVER		"1204" /* 서비스 처리 결과 실패율 임계치 초과 */
#define EVENT_ACTIVE_SERVICE_TIMEOVER		"1205" /* Active 서비스 지정 임계치 오버 */
#define EVENT_ACTIVE_SERVICE_PATTERN_ERROR	"1206" /* Active 서비스 이상 거래 패턴 감지 */

/* 거래코드 */
#define EVENT_TR_CD_RESTM_LIMIT_OVER		"1207" /* 거래코드 처리 응답시간 임계치 초과 */
#define EVENT_TR_CD_FAIL_PCNT_OVER			"1208" /* 거래코드 처리 결과 실패율 임계치 초과 */
#define EVENT_TR_CD_PER_ACC_BIZ_ERR_CNT		"1209" /* 일정주기 동안 비즈니스에러 발생 건수 임계치 초과 */
#define EVENT_TR_CD_PER_ACC_SYS_ERR_CNT		"1210" /* 일정주기 동안 시스템에러 발생 건수 임계치 초과 */
#define EVENT_TR_CD_PER_ACC_TIMEOUT_CNT		"1211" /* 일정주기 동안 타임아웃 발생 건수 임계치 초과 */
#define EVENT_TR_CD_PER_ACC_E2E_WARN_CNT	"1212" /* 일정주기 동안 E2E경고 발생 건수 임계치 초과 */

/* 비즈니스 */
#define EVENT_FUNCION_CALL					"1300" /* 비즈니스 로직(함수) 과다 호출 */
#define EVENT_SNAPSHOT_START				"1301" /* SnapShot 명령 수행 시작 */
#define EVENT_SNAPSHOT_COMPLETED			"1302" /* SnapShot 명령 수행 완료 */

/* 패턴 매칭 */
#define EVENT_PATTERN_MATCHED				"1400" /* 이벤트 패턴 스트링 매치 */

/* 프로세스 */
#define EVENT_PROCESS_DOWN					"1500" /* 거래추적 대상 프로세스 다운 */
#define EVENT_PROCESS_COREDUMP              "1501" /* 거래추적 대상 프로세스 코어덤프 발생 */
#define EVENT_PROCESS_ABNORMAL              "1502" /* 거래수행 중 프로세스 비정상 종료 */
#define EVENT_AGENT_PROCESS_DOWN			"1503" /* Agent Process 종료 */
#define EVENT_AGENT_PROCESS_RESTARTED		"1504" /* Agent Process 자동 재시작 */
#define EVENT_AGENT_PROCESS_RESTART_ERROR	"1505" /* Agent Process 자동 재시작 에러 */
#define EVENT_AGENT_START					"1506" /* Agent 엔진 정상 기동 */
#define EVENT_AGENT_DOWN					"1507" /* Agent 엔진 정상 종료 */
#define EVENT_PROCESS_START					"1508" /* 거래추적 대상 프로세스 기동 */

/* 리소스 및 동작환경 에러 */
#define EVENT_CPU_LIMIT_OVER				"1600" /* CPU 사용률 임계치 초과 */
#define EVENT_FILE_SYSTEM_LIMIT_OVER		"1601" /* 파일시스템 사용률 임계치 초과 */
#define EVENT_DB_TABLE_SPACE_LIMIT_OVER		"1602" /* TRANManager DB Table SPACE 사용률 임계치 초과 */

/* AMS LIBRARY 초기화 */
#define EVENT_AMS_LIBRARY_INIT_ERROR		"1603" /* AMS Library 초기화 실패 */

/* 예외처리 */
#define EVENT_STATIS_SYNC_ERROR				"1700" /* Transaction 데이터 불일치로 인한 통계 처리 예외 발생 */
#define EVENT_AGENT_STATUS_ERROR			"1701" /* Agent 상태 체크 오류 */
#define EVENT_AGENT_TRANSACTION_ERROR		"1702" /* Agent 거래데이터 일정시간동안 미발생 */
#define EVENT_AGENT_OFF						"1703" /* Agent 로그OFF 상태 */
#define EVENT_TCPFAIL_DATA_SEND_START		"1704" /* Agent 미전송 거래 전송 시작 */
#define EVENT_TCPFAIL_DATA_SEND_COMPLETE	"1705" /* Agent 미전송 거래 전송 완료 */
#define EVENT_EAI_TR_STAT_ERROR				"1706" /* EAI 거래처리 상태값 에러 */
#define EVENT_FEP_SVC_STAT_ERROR			"1707" /* FEP 서비스 상태값 에러 */
#define EVENT_AGENT_TIME_SYNC_ERROR			"1708" /* Agent와 Server간 시각동기화 허용 임계치 초과 */
#define EVENT_AGENT_ENGINE_ERROR			"1709" /* Agent 엔진프로세스 기동 상태 에러 */
#define EVENT_PROCESS_TRANSACTION_ERROR     "1710" /* Process 거래데이터 일정시간동안 미발생 */
#define EVENT_THREAD_TRANSACTION_ERROR      "1711" /* Thread 거래데이터 일정시간동안 미발생 */

/* 전문 에러 */
#define EVENT_GLOBAL_ID_SYNTAX_ERROR		"1800" /* GLOBAL ID SYNTAX 에러(사이즈 및 NULL값) */
#define EVENT_GLOBAL_ID_CHANGED				"1801" /* GLOBAL ID 시작/종료시점 변경됨 */
#define EVENT_STD_PARAM_SYNTAX_ERROR        "1802" /* 표준전문 주요항목 SYNTAX 에러(NULL값 포함) */

/* APP DB 에러 */
#define EVENT_ORA_SQLCODE_ERROR				"1810" /* ORACLE SQL실행 리턴 코드 에러 (0, 1403 제외) */

/* 경험치 통계 기반 이벤트 */
#define EVENT_EXP_0_NOR_ACC_OVER			"1900" /* 평일 동시간대 경험치 통계 대비 정상 건수 증가 */
#define EVENT_EXP_0_NOR_ACC_BELOW			"1901" /* 평일 동시간대 경험치 통계 대비 정상 건수 감소 */
#define EVENT_EXP_0_BIZ_ERR_ACC_OVER		"1902" /* 평일 동시간대 경험치 통계 대비 비즈니스 에러 건수 증가 */
#define EVENT_EXP_0_SYS_ERR_ACC_OVER		"1903" /* 평일 동시간대 경험치 통계 대비 시스템 에러 건수 증가 */
#define EVENT_EXP_0_TIMEOUT_ACC_OVER		"1904" /* 평일 동시간대 경험치 통계 대비 타임아웃 건수 증가 */
#define EVENT_EXP_0_NOR_RESTM_OVER			"1905" /* 평일 동시간대 경험치 통계 대비 정상 처리 평균 응답시간(ms) 증가 */
#define EVENT_EXP_0_BIZ_ERR_RESTM_OVER		"1906" /* 평일 동시간대 경험치 통계 대비 비즈니스 에러 처리 평균 응답시간(ms) 증가 */
#define EVENT_EXP_0_SYS_ERR_RESTM_OVER		"1907" /* 평일 동시간대 경험치 통계 대비 시스템 에러 처리 평균 응답시간(ms) 증가 */

#define EVENT_EXP_1_NOR_ACC_OVER			"1910" /* 휴일 동시간대 경험치 통계 대비 정상 건수 증가 */
#define EVENT_EXP_1_NOR_ACC_BELOW			"1911" /* 휴일 동시간대 경험치 통계 대비 정상 건수 감소 */
#define EVENT_EXP_1_BIZ_ERR_ACC_OVER		"1912" /* 휴일 동시간대 경험치 통계 대비 비즈니스 에러 건수 증가 */
#define EVENT_EXP_1_SYS_ERR_ACC_OVER		"1913" /* 휴일 동시간대 경험치 통계 대비 시스템 에러 건수 증가 */
#define EVENT_EXP_1_TIMEOUT_ACC_OVER		"1914" /* 휴일 동시간대 경험치 통계 대비 타임아웃 건수 증가 */
#define EVENT_EXP_1_NOR_RESTM_OVER			"1915" /* 휴일 동시간대 경험치 통계 대비 정상 처리 평균 응답시간(ms) 증가 */
#define EVENT_EXP_1_BIZ_ERR_RESTM_OVER		"1916" /* 휴일 동시간대 경험치 통계 대비 비즈니스 에러 처리 평균 응답시간(ms) 증가 */
#define EVENT_EXP_1_SYS_ERR_RESTM_OVER		"1917" /* 휴일 동시간대 경험치 통계 대비 시스템 에러 처리 평균 응답시간(ms) 증가 */

#define EVENT_EXP_2_NOR_ACC_OVER			"1920" /* PeakDay 동시간대 경험치 통계 대비 정상 건수 증가 */
#define EVENT_EXP_2_NOR_ACC_BELOW			"1921" /* PeakDay 동시간대 경험치 통계 대비 정상 건수 감소 */
#define EVENT_EXP_2_BIZ_ERR_ACC_OVER		"1922" /* PeakDay 동시간대 경험치 통계 대비 비즈니스 에러 건수 증가 */
#define EVENT_EXP_2_SYS_ERR_ACC_OVER		"1923" /* PeakDay 동시간대 경험치 통계 대비 시스템 에러 건수 증가 */
#define EVENT_EXP_2_TIMEOUT_ACC_OVER		"1924" /* PeakDay 동시간대 경험치 통계 대비 타임아웃 건수 증가 */
#define EVENT_EXP_2_NOR_RESTM_OVER			"1925" /* PeakDay 동시간대 경험치 통계 대비 정상 처리 평균 응답시간(ms) 증가 */
#define EVENT_EXP_2_BIZ_ERR_RESTM_OVER		"1926" /* PeakDay 동시간대 경험치 통계 대비 비즈니스 에러 처리 평균 응답시간(ms) 증가 */
#define EVENT_EXP_2_SYS_ERR_RESTM_OVER		"1927" /* PeakDay 동시간대 경험치 통계 대비 시스템 에러 처리 평균 응답시간(ms) 증가 */

#define EVENT_EXP_3_NOR_ACC_OVER			"1930" /* 월말 동시간대 경험치 통계 대비 정상 건수 증가 */
#define EVENT_EXP_3_NOR_ACC_BELOW			"1931" /* 월말 동시간대 경험치 통계 대비 정상 건수 감소 */
#define EVENT_EXP_3_BIZ_ERR_ACC_OVER		"1932" /* 월말 동시간대 경험치 통계 대비 비즈니스 에러 건수 증가 */
#define EVENT_EXP_3_SYS_ERR_ACC_OVER		"1933" /* 월말 동시간대 경험치 통계 대비 시스템 에러 건수 증가 */
#define EVENT_EXP_3_TIMEOUT_ACC_OVER		"1934" /* 월말 동시간대 경험치 통계 대비 타임아웃 건수 증가 */
#define EVENT_EXP_3_NOR_RESTM_OVER			"1935" /* 월말 동시간대 경험치 통계 대비 정상 처리 평균 응답시간(ms) 증가 */
#define EVENT_EXP_3_BIZ_ERR_RESTM_OVER		"1936" /* 월말 동시간대 경험치 통계 대비 비즈니스 에러 처리 평균 응답시간(ms) 증가 */
#define EVENT_EXP_3_SYS_ERR_RESTM_OVER		"1937" /* 월말 동시간대 경험치 통계 대비 시스템 에러 처리 평균 응답시간(ms) 증가 */

/* Tmax, Tuxedo TP */
#define EVENT_TMAX_SLOG_SVC_TIMEOUT			"2000" /* TMAX SLOG 서비스 타임아웃 */
#define EVENT_TMAX_SLOG_SVR_CORE			"2001" /* TMAX SLOG 코어 발생 */
#define EVENT_TUXEDO_ULOG_SVCTIMEOUT		"2002" /* TUXEDO ULOG 서비스 타임아웃 */
#define EVENT_TUXEDO_ULOG_SVR_DIED			"2003" /* TUXEDO ULOG 서버 DOWN */

/* Agent 내부 로직 에러 */
#define EVENT_AGENT_PTRC_RANGE_ERROR        "2010" /* PTRC 범위 에러 */

/* 스케쥴러 이벤트 */
#define EVENT_SCEDULER_TIMEOUT              "2300" /* 스케쥴러 수행 시간 임계치 초과 */
#define EVENT_SCEDULER_ADD_FAIL             "2301" /* 스케쥴러 등록 정보 오류로 인한 JOB 등록 실패 */
#define EVENT_SCEDULER_NO_FILE              "2302" /* 스케쥴러 에서 수행 할 파일이(shell, binary등) 없음 */
#define EVENT_SCEDULER_REMOVE               "2303" /* 스케쥴러 단발성 Job 수행 완료 후 삭제를 하지 않음 */
#define EVENT_SCEDULER_INFO                 "2390" /* 스케쥴러 정보성 데이터 */

/* 미정의 에러 */
#define EVENT_UNDEFINED_ERROR				"9999" /* 미정의 에러발생 */

#endif /*__tran_event_h__*/
