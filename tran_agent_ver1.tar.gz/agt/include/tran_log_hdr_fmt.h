#ifndef __tran_log_hdr_fmt_h__
#define __tran_log_hdr_fmt_h__

#include "tran_def_len.h"

/* 구간 구분( E2E:0, WEB:1, MCA:2, WAS:3, WAS-DB:4, TP:5, TP-DB:6, EAI:7, 대외(FEP):8, ETC:9 ) */
#define E2E_SECTION	'0'
#define WEB_SECTION	'1'
#define MCA_SECTION	'2'
#define WAS_SECTION	'3'
#define WAS_DB_SECTION '4'
#define TPM_SECTION	'5'
#define TPM_DB_SECTION '6'
#define EAI_SECTION	'7'
#define FEP_SECTION	'8'
#define ETC_SECTION	'9'

#define E2E_SECTION_ID	0
#define WEB_SECTION_ID	1
#define MCA_SECTION_ID	2
#define WAS_SECTION_ID	3
#define WAS_DB_SECTION_ID	4
#define TPM_SECTION_ID	5
#define TPM_DB_SECTION_ID	6
#define EAI_SECTION_ID	7
#define FEP_SECTION_ID	8
#define ETC_SECTION_ID	9


#define DB_SECTION(a) (a == TPM_SECTION)?TPM_DB_SECTION:WAS_DB_SECTION

typedef struct
{
	char log_type[LOG_TYPE_LEN + 1];
	char log_interface[LOG_INTERFACE_LEN + 1];
	char tr_section[TR_SECTION_LEN + 1];
	char gid[GID_LEN + 1];
	char server_id[SERVER_ID_LEN + 1];
	char service_id[SERVICE_ID_LEN + 1];
	char host_name[HOST_NAME_LEN + 1];
	char pid[PID_LEN + 1];
	char tid[TID_LEN + 1];
	char idx[IDX_LEN + 1];
	char pidx[IDX_LEN + 1];
	char log_day[LOG_DAY_LEN + 1];
	char log_time[LOG_TIME_LEN + 1];
} TRAN_LOG_HDR_FMT;

#endif /*__tran_log_hdr_fmt_h__*/
