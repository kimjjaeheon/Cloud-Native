#ifndef __tran_info_bdy_fmt_h__
#define __tran_info_bdy_fmt_h__

#include "tran_def_len.h"

typedef struct
{
	char log_info_str[LOG_INFO_STR_LEN + 1];
} TRAN_INFO_BDY_FMT;

#endif /*__tran_info_bdy_fmt_h__*/
