#ifndef __tran_sql_stmt_bdy_fmt_h__
#define __tran_sql_stmt_bdy_fmt_h__

#include "tran_def_len.h"

typedef struct
{
	char sql_stmt_str[SQL_STMT_STR_LEN + 1];
} TRAN_SQL_STMT_BDY_FMT;

#endif /*__tran_info_bdy_fmt_h__*/
