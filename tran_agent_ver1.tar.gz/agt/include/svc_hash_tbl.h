#ifndef __svc_hash_tbl_h__
#define __svc_hash_tbl_h__

#ifdef _SMALL
        #define SVC_HASH_IDX_SIZE       (128 * 128)
        #define SVC_HASH_ARR_SIZE       5000
#else
        #define SVC_HASH_IDX_SIZE       (256 * 256)
        #define SVC_HASH_ARR_SIZE       10000
#endif

#define SVC_HASH_IDX_MASK       (SVC_HASH_IDX_SIZE - 1)

/*SVC HASH STACK LIST*/
typedef struct
{
	u_int top;
	u_int idx[SVC_HASH_ARR_SIZE];
} SVC_HASH_STK;

/* SERVICE HASH 저장 로그 - XXbytes*/
typedef struct
{
	char	host_name[HOST_NAME_LEN + 1];
	char	server_id[SERVER_ID_LEN + 1];
	char	service_id[SERVICE_ID_LEN + 1];
	int 	call_trc_depth;
	long	call_trc_limit;
	long	dbio_trc_limit;
	long	sql_trc_limit;
	int		limit;
	char	uflag_set;
	char	tflag;
	char	is_sync;
	char	reserved;
} SVC_HASH_ARR;

/* SERVICE HASH 저장 엘리먼트*/
typedef struct
{
	u_int			my_idx;
	int				hash_idx;
	int				pre_idx;
	int				next_idx;
	SVC_HASH_ARR	param;
} SVC_HASH_ARR_LIST;

typedef struct
{
	u_int alloc_cnt;
	int h_idx[SVC_HASH_IDX_SIZE];
	SVC_HASH_ARR_LIST h_arr[SVC_HASH_ARR_SIZE];
	SVC_HASH_STK available;
	SVC_HASH_STK used;
} SVC_HASH_TBL;

#endif /*__svc_hash_tbl_h__*/
