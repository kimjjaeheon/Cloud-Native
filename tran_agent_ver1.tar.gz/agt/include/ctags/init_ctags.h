
#ifndef __INIT_CTGAGS_H__
#define __INIT_CTGAGS_H__

typedef struct {
	char					name[128];
	char					kind;
	char					kindName[64];
	unsigned long lineNumber;
	// long int			filePosition;
	char					sourceFilename[128];
	char					source[256];
} st_tagInfo;

#define MAX_TAG_INFO			1024

extern int tagInfoCount;
extern st_tagInfo	TagInfos[MAX_TAG_INFO];

void init_ctags();
void free_ctags();
void make_ctags(const char* filename);

int get_function_count();
st_tagInfo* get_function_info(int index);


#endif // __INIT_CTGAGS_H__
