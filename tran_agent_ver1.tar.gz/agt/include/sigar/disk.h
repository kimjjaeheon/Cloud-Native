#ifndef __TRAN_SYS_DISK_H__
#define __TRAN_SYS_DISK_H__

#ifndef __TRAN_SYS_COMMON_H__
#include "tran_sys_common.h"
#endif

#include "sigar.h"

int disk_info(sigar_t *t, ST_TRAN_SYS_INFO *sys_info);
int disk_info_static(sigar_t *t, ST_TRAN_SYS_INFO *sys_info, char **disk_dev_name_list, const unsigned int disk_list_cnt);
/*
int disk_info(sigar_t *t, ST_TRAN_SYS_INFO *sys_info, char **disk_dev_name_list);
*/

#endif
