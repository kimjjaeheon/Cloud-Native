#ifndef __TRAN_SYS_NET_CONN_H__
#define __TRAN_SYS_NET_CONN_H__

#ifndef __TRAN_SYS_COMMON_H__
#include "tran_sys_common.h"
#endif

#include "sigar.h"

int net_interface_info(sigar_t *t, ST_TRAN_SYS_INFO *sys_info);
int net_conn_info(sigar_t *t, ST_TRAN_SYS_INFO *sys_info);
int net_interface_stat(sigar_t *t, const char* if_nm, ST_TRAN_NETWORK_USAGE *usage);
/*
int net_interface_stat(sigar_t *t, const char* if_nm);
*/


#endif
