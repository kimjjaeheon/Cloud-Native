#ifndef __SIGAR_REF_UTIL_H__
char *commify(double val, char *buf, int round); 
void ip_swap(int a, char* c);
int string_search(const char* src_, const char** dst_, const int dst_cnt_);
int string_token(char* p_pattern_, const char* p_delimiter, char** buf_);
#endif
