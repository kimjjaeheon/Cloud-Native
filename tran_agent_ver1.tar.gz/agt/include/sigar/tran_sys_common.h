#ifndef __SYS_COMMON_H__
#define __SYS_COMMON_H__

#define OS_NAME_LEN        32
#define OS_VER_LEN         64
#define OS_ARCH_LEN        64
#define OS_MACHINE_LEN     64
#define OS_VENDOR_LEN      32
#define OS_VENDOR_NAME_LEN 32
#define OS_VENDOR_VER_LEN  64

#define DISK_DIR_NAME_LEN      128
#define DISK_DEV_NAME_LEN      128
#define DISK_TYPE_NAME_LEN     128
#define DISK_SYS_TYPE_NAME_LEN 128
#define DISK_OPTION_LEN        128
#define DISK_TOTAL_LEN         32
#define DISK_FREE_LEN          32
#define DISK_USED_LEN          32

#define PROC_NAME_LEN		OS_NAME_LEN * 4
#define PROC_USER_LEN		OS_NAME_LEN
#define PROC_GROUP_LEN		OS_NAME_LEN

/* CPU 정보 수집 구조체 */
typedef struct
{
	int core_cnt;
	double idle;
	double used; 
	double user; 
	double sys; 
	double nice; 
	double wait; 
	double irq; 
	double soft_irq; 
	double stolen; 
}ST_TRAN_CPU_INFO;

/* MEMORY 정보 수집 구조체 */
typedef struct
{
	double  total;
	double   free;
	double   used;
	/*
	unsigned long long int  total;
	unsigned long long int   free;
	unsigned long long int   used;
	*/
}ST_TRAN_MEM_INFO;

/* OS 정보 수집 구조체 */
typedef struct
{                                              /* sample data            */
	char name[OS_NAME_LEN+1];                  /* Linux                  */
	char ver[OS_VER_LEN+1];                    /* 3.10.0-327.el7.x86_64  */
	char arch[OS_ARCH_LEN+1];                  /* x86_64                 */
	char machine[OS_MACHINE_LEN+1];            /* x86_64                 */
	char vendor[OS_VENDOR_LEN+1];              /* CentOS                 */
	char vendor_name[OS_VENDOR_NAME_LEN+1];    /* Linux                  */
	char vendor_ver[OS_VENDOR_VER_LEN+1];      /* 7.2.1511               */
}ST_TRAN_OS_INFO;

/* DISK 정보 수집 구조체 */
typedef struct
{
	float ratio;
	char dir_name[DISK_DIR_NAME_LEN+1];
	char dev_name[DISK_DEV_NAME_LEN+1];
	char type_name[DISK_TYPE_NAME_LEN+1];
	char sys_type_name[DISK_SYS_TYPE_NAME_LEN+1];
	char option[DISK_OPTION_LEN+1];
	/*
	char total[DISK_TOTAL_LEN+1];
	char free[DISK_FREE_LEN+1];
	char used[DISK_USED_LEN+1];
	*/
	unsigned long long total;
	unsigned long long free;
	unsigned long long used;
}ST_TRAN_DISK_INFO;

/* PROCESS 정보 수집 구조체 */
typedef struct
{
	char mgmt_flag;
	char proc_name[PROC_NAME_LEN+1];
	unsigned long pid;
	unsigned long ppid;
	unsigned char state;
	int tty;
	int priority;
	int nice;
	int processor;
	int threads;
	char user[PROC_USER_LEN+1];
	char group[PROC_GROUP_LEN+1];
	unsigned long mem;
	unsigned long mem_res;
	float cpu;
	unsigned long start_tm;
	unsigned long user_tm;
	unsigned long sys_tm;
	unsigned long total_tm;
	long up_tm;

}ST_TRAN_PROC_INFO;

/* NETWORK 사용량 정보 수집 구조체 */
typedef struct
{
	unsigned long long tx_byte;
	unsigned long long tx_packet;
	unsigned long long tx_error;
	unsigned long long tx_dropped;
	unsigned long long tx_overrun;
	unsigned long long tx_collision;
	unsigned long long tx_carrier;

	unsigned long long rx_byte;
	unsigned long long rx_packet;
	unsigned long long rx_error;
	unsigned long long rx_dropped;
	unsigned long long rx_overrun;
	unsigned long long rx_frame;
}ST_TRAN_NETWORK_USAGE;

/* NETWORK INTERFACE 정보 수집 구조체 */
typedef struct
{
	char if_name[PROC_NAME_LEN+1];

	ST_TRAN_NETWORK_USAGE old;
	ST_TRAN_NETWORK_USAGE cur;
}ST_TRAN_INTERFACE_INFO;

/* OS, CPU, MEM, DISK, PROC 정보 수집 구조체 */
typedef struct
{
	int disk_count;
	int core_count;
	int proc_count;
	int if_count;
	ST_TRAN_OS_INFO   os;
	ST_TRAN_CPU_INFO  cpu;
	ST_TRAN_MEM_INFO  mem;
	ST_TRAN_DISK_INFO *disk_list;
	ST_TRAN_PROC_INFO *proc_list;
	ST_TRAN_INTERFACE_INFO *if_list;
}ST_TRAN_SYS_INFO;


#endif

