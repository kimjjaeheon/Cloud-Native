#ifndef __TRAN_SYS_OS_H__
#define __TRAN_SYS_OS_H__

#ifndef __TRAN_SYS_COMMON_H__
#include "tran_sys_common.h"
#endif

#include "sigar.h"

int os_info(sigar_t *t, ST_TRAN_SYS_INFO *sys_info);

#endif
