#ifndef __TRAN_SYS_PROC_H__
#define __TRAN_SYS_PROC_H__

#ifndef __TRAN_SYS_COMMON_H__
#include "tran_sys_common.h"
#endif

#include "sigar.h"

int proc_stat_info(sigar_t *t, ST_TRAN_SYS_INFO *sys_info);
int proc_list_info(sigar_t *t, ST_TRAN_SYS_INFO *sys_info);
int proc_cpu_mem_info(sigar_t *t, pid_t *pid, double *cpu_ratio, unsigned long* mem_rss, int proc_cnt);

#endif
