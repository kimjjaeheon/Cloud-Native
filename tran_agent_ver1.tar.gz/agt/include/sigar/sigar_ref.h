#ifndef __SIGAR_REF_H__
#define __SIGAR_REF_H__

#include <pthread.h>
#include "tran_sys_common.h"
#include "cpu.h"
#include "disk.h"
#include "mem.h"
#include "net.h"
#include "os.h"
#include "proc.h"
#include "util.h"

#ifndef TRAN_OK
#define TRAN_OK 1
#endif

#ifndef TRAN_NOK
#define TRAN_NOK -1
#endif

#define MAX_DISK_LIST 100

#ifdef _MULTI_THREAD
#define SIGAR_MUTEX_INIT(key) { *key=PTHREAD_MUTEX_INITIALIZER; }
#define SIGAR_MUTEX_LOCK(key) { pthread_mutex_lock(&key); }
#define SIGAR_MUTEX_TRY_LOCK(key) { pthread_mutex_lock(&key); }
#define SIGAR_MUTEX_UNLOCK(key) { pthread_mutex_unlock(&key); }
#else
#define SIGAR_MUTEX_INIT(key) { ; }
#define SIGAR_MUTEX_LOCK(key) { ; }
#define SIGAR_MUTEX_TRY_LOCK(key) { ; }
#define SIGAR_MUTEX_UNLOCK(key) { ; }
#endif

#ifdef __cplusplus
extern "C" {
#endif

static pthread_mutex_t sigar_mlock = PTHREAD_MUTEX_INITIALIZER;

typedef struct st_sigar_ref st_sigar;

struct st_sigar_ref
{
    /* Function */
    int        (*getCpuInfo)         (st_sigar* p_this);
    int        (*getMemInfo)         (st_sigar* p_this);
    int        (*getOsInfo)          (st_sigar* p_this);
    int        (*getDiskInfo)        (st_sigar* p_this);
    int        (*getDiskInfoStatic)  (st_sigar* p_this, char **disk_dev_name_list, const unsigned int disk_list_cnt);
	/*
    int        (*getDiskInfo)        (st_sigar* p_this, char* p_);
	*/
    int        (*getConnInfo)        (st_sigar* p_this);
    int        (*getProcInfo)        (st_sigar* p_this);
	int		   (*getProcResourceInfo) (st_sigar* p_this, pid_t* pid, double* cpu_ratio, unsigned long* mem_rss, int cnt);
    int        (*getProcListInfo)    (st_sigar* p_this);
    int        (*getIfInfo)          (st_sigar* p_this);

    /* Variables */

	sigar_t*	t;
	ST_TRAN_SYS_INFO sys_info;
	char *pp_disk_dev_name_list[MAX_DISK_LIST];
};

st_sigar* create_sigar();
void destroy_sigar(st_sigar* p_sigar);
#ifdef __cplusplus
}
#endif


#endif
