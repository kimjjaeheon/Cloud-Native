#ifndef __TRAN_SYS_MEM_H__
#define __TRAN_SYS_MEM_H__

#include "sigar.h"

#ifndef __TRAN_SYS_COMMON_H__
#include "tran_sys_common.h"
#endif


int mem_info(sigar_t *t, ST_TRAN_SYS_INFO *sys_info);

#endif
