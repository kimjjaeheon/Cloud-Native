#ifndef __CHECK_UTIL_H__
#define __CHECK_UTIL_H__

int string_token(char* p_pattern_, const char* p_delimiter, char** buf_);

#endif /* __CHECK_UTIL_H__ */
