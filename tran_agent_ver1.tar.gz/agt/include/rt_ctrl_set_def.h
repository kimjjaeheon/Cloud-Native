#ifndef __rt_ctrl_set_def_h__
#define __rt_ctrl_set_def_h__

/* 플래그SET 정의 */
#define RT_EXCL_FLAG			0
/* RT_EXCL_FLAG 값 의미
   '0': 기본값 : 실시간 통계 대상
   '1': 시작(S)에 거래채널유형에 'SAF','BAT'값이 포함되어 있음
   '2': 종료(F)에만 거래채널유형이 존재하고, 시작엔 값이 없음 */

#define INFO_CONT_FLAG			1
/* 정보성/에러정보성 로그가 긴 경우, 나눠서 데이터 전송하여 DB에 저장되며,
   UI에서 하나의 메시지로 인식하기 위해 FLAG를 두어 제어한다
   '0': 단건 메시지인 경우, 기본값
   '1': 추가 데이터가 있음을 알린다.(데이터 분리 저장 시 사용)
   '2': 추가 데이터가 더 이상 없음 최종 데이터로 '끝'을 알린다.(데이터 분리 저장 시 사용) */

#define CLH_RSPS_END_FLAG		2
/* CLH 응답 강제 종료 처리
   '1':  정상종료메시지 생성 후, CLH 응답 강제 종료플래그 세팅 */

#define RT_IS_CORE_BIZ_FLAG		3
/* RT_IS_CORE_BIZ_FLAG 값 의미
   'Y': 메인업무 해당(상품처리,일괄전송)
   'N': 메인업무 미해당 */

#define RT_SET_L3_BIZ_CD_FLAG	4
/* RT_SET_L3_BIZ_CD_FLAG 값 의미
   '0': L3_BIZ_CD 지정 안됨
   '1': L3_BIZ_CD 지정됨 */

#define TCP_FAIL_LOG_FLAG		5
/* TCP_FAIL_LOG 값 의미
   '0': 실시간 로그
   '1': 전송 실패 로그 */


#endif /*__rt_ctrl_set_def_h__*/
