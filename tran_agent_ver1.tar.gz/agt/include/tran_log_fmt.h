#ifndef __tran_log_fmt_h__
#define __tran_log_fmt_h__

#include "tran_log_hdr_fmt.h"

#include "tran_ifxx_bdy_fmt.h"
#include "tran_info_bdy_fmt.h"
#include "tran_info_ex_bdy_fmt.h"
#include "tran_errinfo_bdy_fmt.h"
#include "tran_sql_stmt_bdy_fmt.h"
#include "tran_evt_bdy_fmt.h"

/* INTERFACE */
#define IF00					0
#define IF01					1
#define IF02					2
#define IF03					3
#define IF04					4
#define IF05					5
#define IF06					6
#define IF07					7
#define IF08					8
#define IF09					9
#define IF10					10
#define IF11					11
#define IF12					12
#define IF13					13
#define IF14					14
#define IF15					15
#define IF16					16
#define IF17					17
#define IF18					18
#define IF19					19
#define IF20					20
#define IF21					21
#define IF22					22
#define IF23					23
#define IF24					24
#define IF25					25
#define IF26					26
#define IF27					27
#define IF28					28
#define IF29					29
#define IF30					30
#define IF31					31
#define IF32					32
#define IF33					33
#define IF34					34
#define IF35					35
#define IF36					36
#define IF37					37
#define IF38					38
#define IF39					39
#define IF40					40
#define IF41					41

/* LOG_TYPE */
#define START_LOG				'1'
#define END_LOG					'2'

#define LOG_TYPE_1				'1'  /* TRAN_START()호출 시 발생 */
#define LOG_TYPE_2				'2'  /* TRAN_END()호출 시 발생 */
#define LOG_TYPE_9				'9'  /* TRAN_ERROR()호출 시 발생 */ 
#define LOG_TYPE_I				'I'  /* TRAN_INFO(), TRAN_CALLINFO_S(), TRAN_CALLINFO_F() 호출 시 발생 */
#define LOG_TYPE_B				'B'  /* TRAN_CALLINFO_S(), TRAN_CALLINFO_F() 호출 시 CALL_FUNC에서 DBIO 발생 */
#define LOG_TYPE_Q				'Q'  /* TRAN_SQL_STMT() 호출 시 SQL문 임시저장 후, 해당 DBIO함수 임계초과시 발생 */
#define LOG_TYPE_C				'C'  /* TRAN_CALLINFO_S(), TRAN_CALLINFO_F() 호출 시 CALL_FUNC에서발생 */
#define LOG_TYPE_E				'E'  /* TRAN_ERRINFO() 호출시 발생 */
#define LOG_TYPE_V				'V'  /* TRAN_EVENT()호출 시 발생 */
#define LOG_TYPE_X				'X'  /* TRAN_INFO_EX()호출 시 발생 */

/* RESULT_FLAG */
#define GENERAL_START			'S'
#define GENERAL_END				'F'
#define NO_START_END			'G'
#define GENERAL_ERROR			'E'
#define NO_START_ERROR			'D'
#define SERVICE_TIME_OVER		'O'
#define GENERAL_INFO			'I'
#define GENERAL_INFO_STR		"I"
#define TRAN_EVENT_V			'V'
#define TRAN_EVENT_N			'N'
#define DBIO_CALL_INFO			'B'
#define SQL_STMT				'Q'
#define CALL_STRACK_TRACE		'C'
#define UNKNOWN_RESULT			'U'
#define INCL_ERROR_END			'R'
#define INFO_EX					'X'

/* LOG FILETER FLAGSET */
#define FLAG_ON					'1'
#define FLAG_OFF				'0'

#define KIBS_FLAGSET_ID			0
#define DUMMY1_FLAGSET_ID		1
#define DUMMY2_FLAGSET_ID		2
#define DUMMY3_FLAGSET_ID		3
#define DUMMY4_FLAGSET_ID		4
#define DUMMY5_FLAGSET_ID		5
#define DUMMY6_FLAGSET_ID		6
#define NORMAL_FLAGSET_ID		7
#define ABNORMAL_FLAGSET_ID		8
#define INFO_FLAGSET_ID			9


/* EXECUTION TIME_NULL STRING */
#define EXE_TIME_NULL_STR	"0000000000"

/* SPACE STRING*/
#define SPACE32_STR		"                                "

typedef struct
{
	TRAN_LOG_HDR_FMT hdr;
	union
	{
		TRAN_IF00_BDY_FMT		if00_log;		/* 상품-상품처리 TP */
		TRAN_IF01_BDY_FMT		if01_log;		/* 상품-일괄전송 TP */
		TRAN_IF02_BDY_FMT		if02_log;		/* 채널-EAI(대내) WAS */
		TRAN_IF03_BDY_FMT		if03_log;		/* 채널-EAI(대외) WAS */
		TRAN_IF04_BDY_FMT		if04_log;		/* 채널-EAI (정보)AP ## 제외 (표준전문없음) */
		TRAN_IF05_BDY_FMT		if05_log;		/* 채널-MCA(대면) WAS */
		TRAN_IF06_BDY_FMT		if06_log;		/* 채널-MCA(비대면) WAS */
		TRAN_IF07_BDY_FMT		if07_log;		/* 채널-MCA(서비스) WAS */
		TRAN_IF08_BDY_FMT		if08_log;		/* 상품-상품팩토리 WAS */
		TRAN_IF09_BDY_FMT		if09_log;		/* 정보-BSA WAS */
		TRAN_IF10_BDY_FMT		if10_log;		/* 정보-운영CRM WAS */
		TRAN_IF11_BDY_FMT		if11_log;		/* 정보-분석CRM WAS */
		TRAN_IF12_BDY_FMT		if12_log;		/* 인터넷-기업CMS PT-WEB */
		TRAN_IF13_BDY_FMT		if13_log;		/* 인터넷-기업CMS PT-WAS */
		TRAN_IF14_BDY_FMT		if14_log;		/* 인터넷-기업뱅킹 PT-WEB */
		TRAN_IF15_BDY_FMT		if15_log;		/* 인터넷-기업뱅킹 PT-WAS */
		TRAN_IF16_BDY_FMT		if16_log;		/* 인터넷-기업프리미엄 PT-WEB */
		TRAN_IF17_BDY_FMT		if17_log;		/* 인터넷-기업프리미엄 PT-WAS */
		TRAN_IF18_BDY_FMT		if18_log;		/* 인터넷-개인뱅킹 PT-WEB */
		TRAN_IF19_BDY_FMT		if19_log;		/* 인터넷-개인뱅킹 PT-WAS */
		TRAN_IF20_BDY_FMT		if20_log;		/* 인터넷-외환포털/글로벌뱅킹 PT-WEB */
		TRAN_IF21_BDY_FMT		if21_log;		/* 인터넷-외환포털/글로벌뱅킹 PT-WAS */
		TRAN_IF22_BDY_FMT		if22_log;		/* 인터넷-BT-WAS */
		TRAN_IF23_BDY_FMT		if23_log;		/* 인터넷-외환포털/글로벌뱅킹 BT-WAS */
		TRAN_IF24_BDY_FMT		if24_log;		/* 인터넷-스마트폰뱅킹 PT-WEB */
		TRAN_IF25_BDY_FMT		if25_log;		/* 인터넷-스마트폰뱅킹 PT-WAS */
		TRAN_IF26_BDY_FMT		if26_log;		/* 단위-자본통합 WAS */
		TRAN_IF27_BDY_FMT		if27_log;		/* 단위-방카슈랑스 WAS */
		TRAN_IF28_BDY_FMT		if28_log;		/* 단위-EDMS WAS */
		TRAN_IF29_BDY_FMT		if29_log;		/* 단위-퇴직연금 PT-WEB */
		TRAN_IF30_BDY_FMT		if30_log;		/* 단위-퇴직연금 PT-WAS */
		TRAN_IF31_BDY_FMT		if31_log;		/* 단위-퇴직연금 BT-WAS */
		TRAN_IF32_BDY_FMT		if32_log;		/* 내부-하나포탈 WAS */
		TRAN_IF33_BDY_FMT		if33_log;		/* 단위-IFRS WAS */
		TRAN_IF34_BDY_FMT		if34_log;		/* 상품-상품팩토리 WEB(WEB+WAS동일장비) */
		TRAN_IF35_BDY_FMT		if35_log;		/* 정보-BSA WEB (WEB+WAS동일장비) */
		TRAN_IF36_BDY_FMT		if36_log;		/* 정보-운영CRM WEB (WEB+WAS동일장비) */
		TRAN_IF37_BDY_FMT		if37_log;		/* 정보-분석CRM WEB (WEB+WAS동일장비) */
		TRAN_IF38_BDY_FMT		if38_log;		/* 단위-IFRS WEB (WEB+WAS동일장비) */
		TRAN_IF39_BDY_FMT		if39_log;		/* 단위-자본통합 WEB (WEB+WAS동일장비) */
		TRAN_IF40_BDY_FMT		if40_log;		/* 단위-EDMS WEB (WEB+WAS동일장비) */
		TRAN_IF41_BDY_FMT		if41_log;		/* 단위-퇴직연금 BT-WEB (WEB+WAS동일장비) */
		TRAN_INFO_BDY_FMT		info_log; 		/* 정보성 */
		TRAN_INFO_EX_BDY_FMT	info_ex_log; 	/* 정보확장 */
		TRAN_ERRINFO_BDY_FMT	errinfo_log; 	/* 에러정보 */
		TRAN_EVENT_BDY_FMT		evt_log; 		/* 이벤트 */
		TRAN_SQL_STMT_BDY_FMT	sql_stmt_log; 	/* SQL문 로그 */
	} bdy;
} TRAN_LOG_FMT;

#endif /*__tran_log_fmt_h__*/
