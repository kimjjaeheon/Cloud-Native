#ifndef __log_hash_trace_h__
#define __log_hash_trace_h__

/* 
 functions 
 */
LOG_HASH_ARR_LIST *set_log_flag(PTRC_HASH_ARR *ptrc, char service_depth, char qnum, int flag_type);

#endif /*__log_hash_trace_h__*/
