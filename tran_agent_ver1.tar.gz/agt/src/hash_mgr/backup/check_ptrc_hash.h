#ifndef __check_ptrc_hash_h__
#define __check_ptrc_hash_h__

/* function */
void check_ptrc_hash(int qnum);

#endif /*__check_ptrc_hash_h__*/
