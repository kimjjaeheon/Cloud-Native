#include "hash_mgr.h"
#include "init.h"
#include "parse_log_que.h"
#include "sync_send_que.h"
#include "noti_send_que.h"
#include "log_hash_stk.h"
#include "check_log_hash.h"
#include "ptrc_hash_trace.h"
#include "rt_ctrl_set_def.h"
#include "log_if_def.h"

extern int clear_time, print_time;
extern char my_hostname[HOST_NAME_LEN + 1];
extern LOG_HASH_TBL  *log_hash_tbl;
extern PTRC_HASH_TBL *ptrc_hash_tbl;
extern TRAN_AGT_SHM    *tran_agt_shm;

extern int  parse_log_que_semid;
extern int  sync_send_que_semid;
extern int  noti_send_que_semid;
extern int  pair_agent_yn;
extern int  clh_rsps_end_chk_sec;

extern LOG_STAT *log_stat;
extern LOG_INTERFACE_NM_INFO log_interface_nm_info[MAX_IF_NUM];

static char *get_tr_cd(TRAN_LOG_FMT *keep_log);
static char get_ctc_char(TRAN_LOG_FMT *keep_log);
static int  get_time_elapsed(struct timespec *tm_st);

#define TMPBUF_SIZE  1024

void check_log_hash(int qnum)
{
	static LOG_HASH_ARR_LIST *check_log;
	static LOG_HASH_STK checked;
	static int ntime;

	static char log_day[LOG_DAY_LEN + 1];
	static char log_time[LOG_TIME_LEN + 1];
	static char tmpbuf[TMPBUF_SIZE + 1];

	TRAN_IF00_BDY_FMT *if00_log;
	TRAN_IF01_BDY_FMT *if01_log;
	TRAN_IF02_BDY_FMT *if02_log;
	TRAN_IF03_BDY_FMT *if03_log;
	TRAN_IF04_BDY_FMT *if04_log;
	TRAN_IF05_BDY_FMT *if05_log;
	TRAN_IF06_BDY_FMT *if06_log;
	TRAN_IF07_BDY_FMT *if07_log;
	TRAN_IF08_BDY_FMT *if08_log;
	TRAN_IF09_BDY_FMT *if09_log;
	TRAN_IF10_BDY_FMT *if10_log;
	TRAN_IF11_BDY_FMT *if11_log;
	TRAN_IF12_BDY_FMT *if12_log;
	TRAN_IF13_BDY_FMT *if13_log;
	TRAN_IF14_BDY_FMT *if14_log;
	TRAN_IF15_BDY_FMT *if15_log;
	TRAN_IF16_BDY_FMT *if16_log;
	TRAN_IF17_BDY_FMT *if17_log;
	TRAN_IF18_BDY_FMT *if18_log;
	TRAN_IF19_BDY_FMT *if19_log;
	TRAN_IF20_BDY_FMT *if20_log;
	TRAN_IF21_BDY_FMT *if21_log;
	TRAN_IF22_BDY_FMT *if22_log;
	TRAN_IF23_BDY_FMT *if23_log;
	TRAN_IF24_BDY_FMT *if24_log;
	TRAN_IF25_BDY_FMT *if25_log;
	TRAN_IF26_BDY_FMT *if26_log;
	TRAN_IF27_BDY_FMT *if27_log;
	TRAN_IF28_BDY_FMT *if28_log;
	TRAN_IF29_BDY_FMT *if29_log;
	TRAN_IF30_BDY_FMT *if30_log;
	TRAN_IF31_BDY_FMT *if31_log;
	TRAN_IF32_BDY_FMT *if32_log;
	TRAN_IF33_BDY_FMT *if33_log;
	TRAN_IF34_BDY_FMT *if34_log;
	TRAN_IF35_BDY_FMT *if35_log;
	TRAN_IF36_BDY_FMT *if36_log;
	TRAN_IF37_BDY_FMT *if37_log;
	TRAN_IF38_BDY_FMT *if38_log;
	TRAN_IF39_BDY_FMT *if39_log;
	TRAN_IF40_BDY_FMT *if40_log;
	TRAN_IF41_BDY_FMT *if41_log;

	LOG_HASH_ARR evt_log;
	LOG_HASH_ARR act_svc_log; /* Active Service Info */

	TRAN_ERRINFO_BDY_FMT *bdy = (TRAN_ERRINFO_BDY_FMT *)&evt_log.keep_log.bdy;

	PTRC_HASH_ARR_LIST *tmout_ptrc;
	ACTIVE_SERVICE_DETAIL act_svc_dtl;

	int i;
	checked.top = 0;

	struct tm ts;

	if ((log_hash_tbl->used.top + log_hash_tbl->available.top) != LOG_HASH_ARR_SIZE)
	{
		/* 해시 데이터 초기화 안되었거나 CRASH 가능성 체크 */
		log_printf("(I) LOG_HASH#%02d 데이터가 비정상입니다..", qnum);
		return ;
	}

	for (i = 0; i < log_hash_tbl->used.top; i++)
	{
		check_log = &log_hash_tbl->h_arr[log_hash_tbl->used.idx[i]];

#if 0
		log_printf("(I) GID |%.*s|, SVC|%.*s|, action_timer.ACTION_TIMER_SVCTIME : %d", 
			GID_UNI_LEN, check_log->param.keep_log.hdr.gid,
			SERVICE_ID_LEN, check_log->param.keep_log.hdr.service_id, 
			check_log->param.action_timer[ACTION_TIMER_SVCTIME]);
#endif

		if (check_log->param.action_timer[ACTION_TIMER_SVCTIME] > 0)
		{
			if (!memcmp(check_log->param.keep_log.hdr.service_id, "CLH", strlen("CLH")))
			{
				if ((check_log->param.result_flag == GENERAL_START) &&
					!(check_log->param.log_flag & CLH_RSPS_ERROR_BIT) &&
					(check_log->param.keep_log.bdy.if00_log.rqst_rsps_dv_cd[0] == RSPS_CHAR))
				{
					check_log->param.log_flag |= CLH_RSPS_ERROR_BIT;
					check_log->param.action_timer[ACTION_TIMER_CLH_RSPS_CHK] = clh_rsps_end_chk_sec;
				}
				else if (check_log->param.log_flag & CLH_RSPS_ERROR_BIT)
				{
					if (check_log->param.action_timer[ACTION_TIMER_CLH_RSPS_CHK] > 0)
					{
						check_log->param.action_timer[ACTION_TIMER_CLH_RSPS_CHK]--;
					}
					else
					{
						log_printf("(I) clh 강제 종료 처리.. GID |%.*s|", GID_UNI_LEN, check_log->param.keep_log.hdr.gid);
						/* CLH 응답인 경우, 일정 시간 이후, 강제 종료 처리한다 */
						check_log->param.result_flag = GENERAL_END;
						check_log->param.keep_log.hdr.log_type[0] = END_TYPE;
						check_log->param.rt_ctrl_set[CLH_RSPS_END_FLAG] = '1'; /* CLH 응답 강제 종료플래그 세팅 */

						/* 응답 시작시각과 동일한 시각으로 설정 */
						memcpy(&check_log->param.exe_time[EXE_TIME_END], &check_log->param.exe_time[EXE_TIME_BEGIN], sizeof(struct timespec));
						memcpy(check_log->param.keep_log.bdy.if00_log.exe_time, EXE_TIME_NULL_STR, EXE_TIME_LEN);
#if 0
						clock_gettime(CLOCK_REALTIME, &check_log->param.exe_time[EXE_TIME_END]);
						localtime_r((time_t*)&check_log->param.exe_time[EXE_TIME_END].tv_sec, &ts);
						strftime(log_day, sizeof(log_day), "%Y%m%d", &ts);
						strftime(log_time, sizeof(log_time), "%H%M%S", &ts);
						snprintf(log_time + US_OFFSET, (US_LEN + 1), "%0*ld", US_LEN, check_log->param.exe_time[EXE_TIME_END].tv_nsec/1000);
	
						/* 임계치를 초과한 현재 일시 설정 */
						memcpy(check_log->param.keep_log.hdr.log_day, log_day, LOG_DAY_LEN);
						memcpy(check_log->param.keep_log.hdr.log_time, log_time, LOG_TIME_LEN);
#endif
						sem_lock(parse_log_que_semid, qnum, SEM_UNDO);
						if (put_parse_log_que(&check_log->param, sizeof(LOG_HASH_ARR)) < 0)
						{
							/* parse_cirque full */
							log_stat->discard_logs++;
						}
						else
						{
							log_stat->F_msgs++;
						}
						sem_unlock(parse_log_que_semid, qnum, SEM_UNDO);

						check_log->param.action_timer[ACTION_TIMER_SVCTIME] = 0;
					}
				}
			}
			else if ((check_log->param.log_flag & SVC_TIMEOUT_START_BIT) || (check_log->param.log_flag & SVC_TIMEOUT_ERROR_BIT))
			{
				if (check_log->param.log_flag & SVC_TIMEOUT_START_BIT)
				{
					/* 에러 로그 생성 */
					check_log->param.result_flag = GENERAL_ERROR;
					check_log->param.keep_log.hdr.log_type[0] = ERR_TYPE;
					check_log->param.keep_log.bdy.if00_log.rslt_cd[0] = RSLT_CD_TIMEOUT; /* TIMEOUT ERROR */

					/* fill exe_time end point */
					clock_gettime(CLOCK_REALTIME, &check_log->param.exe_time[EXE_TIME_END]);

					localtime_r((time_t*)&check_log->param.exe_time[EXE_TIME_END].tv_sec, &ts);

					strftime(log_day, sizeof(log_day), "%Y%m%d", &ts);
					strftime(log_time, sizeof(log_time), "%H%M%S", &ts);
					snprintf(log_time + US_OFFSET, (US_LEN + 1), "%0*ld", US_LEN, check_log->param.exe_time[EXE_TIME_END].tv_nsec/1000);

					/* 임계치를 초과한 현재 일시 설정 */
					memcpy(check_log->param.keep_log.hdr.log_day, log_day, LOG_DAY_LEN);
					memcpy(check_log->param.keep_log.hdr.log_time, log_time, LOG_TIME_LEN);

					sem_lock(parse_log_que_semid, qnum, SEM_UNDO);
					if (put_parse_log_que(&check_log->param, sizeof(LOG_HASH_ARR)) < 0)
					{
						/* parse_cirque full */
						log_stat->discard_logs++;
					}
					else
					{
						log_stat->E_msgs++;
					}
					sem_unlock(parse_log_que_semid, qnum, SEM_UNDO);
				}

				/* 에러 종료 로그 생성 - 타임아웃 에러 */
				check_log->param.result_flag = INCL_ERROR_END;
				check_log->param.keep_log.hdr.log_type[0] = END_TYPE;
				check_log->param.keep_log.bdy.if00_log.rslt_cd[0] = RSLT_CD_TIMEOUT; /* TIMEOUT ERROR */

				/* fill exe_time end point */
				clock_gettime(CLOCK_REALTIME, &check_log->param.exe_time[EXE_TIME_END]);

				localtime_r((time_t*)&check_log->param.exe_time[EXE_TIME_END].tv_sec, &ts);

				strftime(log_day, sizeof(log_day), "%Y%m%d", &ts);
				strftime(log_time, sizeof(log_time), "%H%M%S", &ts);
				snprintf(log_time + US_OFFSET, (US_LEN + 1), "%0*ld", US_LEN, check_log->param.exe_time[EXE_TIME_END].tv_nsec/1000);

				/* 임계치를 초과한 현재 일시 설정 */
				memcpy(check_log->param.keep_log.hdr.log_day, log_day, LOG_DAY_LEN);
				memcpy(check_log->param.keep_log.hdr.log_time, log_time, LOG_TIME_LEN);

				sem_lock(parse_log_que_semid, qnum, SEM_UNDO);
				if (put_parse_log_que(&check_log->param, sizeof(LOG_HASH_ARR)) < 0)
				{
					/* parse_cirque full */
					log_stat->discard_logs++;
				}
				else
				{
					log_stat->R_msgs++;
				}
				sem_unlock(parse_log_que_semid, qnum, SEM_UNDO);

				check_log->param.action_timer[ACTION_TIMER_SVCTIME] = 0;
			}
			else if ((check_log->param.log_flag & PROC_CORE_START_BIT) || (check_log->param.log_flag & PROC_CORE_ERROR_BIT))
			{
				if (check_log->param.log_flag & PROC_CORE_START_BIT)
				{
					/* 에러 로그 생성 */
					check_log->param.result_flag = GENERAL_ERROR;
					check_log->param.keep_log.hdr.log_type[0] = ERR_TYPE;
					check_log->param.keep_log.bdy.if00_log.rslt_cd[0] = RSLT_CD_SYSERR; /* SYS ERROR */

					/* fill exe_time end point */
					clock_gettime(CLOCK_REALTIME, &check_log->param.exe_time[EXE_TIME_END]);

					localtime_r((time_t*)&check_log->param.exe_time[EXE_TIME_END].tv_sec, &ts);

					strftime(log_day, sizeof(log_day), "%Y%m%d", &ts);
					strftime(log_time, sizeof(log_time), "%H%M%S", &ts);
					snprintf(log_time + US_OFFSET, (US_LEN + 1), "%0*ld", US_LEN, check_log->param.exe_time[EXE_TIME_END].tv_nsec/1000);

					/* 임계치를 초과한 현재 일시 설정 */
					memcpy(check_log->param.keep_log.hdr.log_day, log_day, LOG_DAY_LEN);
					memcpy(check_log->param.keep_log.hdr.log_time, log_time, LOG_TIME_LEN);

					sem_lock(parse_log_que_semid, qnum, SEM_UNDO);
					if (put_parse_log_que(&check_log->param, sizeof(LOG_HASH_ARR)) < 0)
					{
						/* parse_cirque full */
						log_stat->discard_logs++;
					}
					else
					{
						log_stat->E_msgs++;
					}
					sem_unlock(parse_log_que_semid, qnum, SEM_UNDO);
				}

				/* 에러 종료 로그 생성 - 시스템 에러 */
				check_log->param.result_flag = INCL_ERROR_END;
				check_log->param.keep_log.hdr.log_type[0] = END_TYPE;
				check_log->param.keep_log.bdy.if00_log.rslt_cd[0] = RSLT_CD_SYSERR; /* SYS ERROR */

				/* fill exe_time end point */
				clock_gettime(CLOCK_REALTIME, &check_log->param.exe_time[EXE_TIME_END]);

				localtime_r((time_t*)&check_log->param.exe_time[EXE_TIME_END].tv_sec, &ts);

				strftime(log_day, sizeof(log_day), "%Y%m%d", &ts);
				strftime(log_time, sizeof(log_time), "%H%M%S", &ts);
				snprintf(log_time + US_OFFSET, (US_LEN + 1), "%0*ld", US_LEN, check_log->param.exe_time[EXE_TIME_END].tv_nsec/1000);

				/* 임계치를 초과한 현재 일시 설정 */
				memcpy(check_log->param.keep_log.hdr.log_day, log_day, LOG_DAY_LEN);
				memcpy(check_log->param.keep_log.hdr.log_time, log_time, LOG_TIME_LEN);

				sem_lock(parse_log_que_semid, qnum, SEM_UNDO);
				if (put_parse_log_que(&check_log->param, sizeof(LOG_HASH_ARR)) < 0)
				{
					/* parse_cirque full */
					log_stat->discard_logs++;
				}
				else
				{
					log_stat->R_msgs++;
				}
				sem_unlock(parse_log_que_semid, qnum, SEM_UNDO);

				check_log->param.action_timer[ACTION_TIMER_SVCTIME] = 0;
			}

			if (check_log->param.action_timer[ACTION_TIMER_SVCTIME] > 0)
			{
				check_log->param.action_timer[ACTION_TIMER_SVCTIME]--;
				struct timeval	f_tm;
				gettimeofday(&f_tm, NULL);

#ifdef _LOGBIT
				log_printf("--> SVC.LIMIT (%d, left %d) [ GID |%-*.*s|, LOG_BIT - S:%d, F:%d, E:%d, C:%d, N:%d, D:%d]", 
					check_log->param.keep_svc.limit,
					check_log->param.action_timer[ACTION_TIMER_SVCTIME],
					GID_LEN, GID_LEN,
					check_log->param.keep_log.hdr.gid,
					(check_log->param.log_flag & TRAN_START_BIT) ? 1 : 0, 
					(check_log->param.log_flag & TRAN_END_BIT) ? 1 : 0,
					(check_log->param.log_flag & TRAN_ERROR_BIT) ? 1 : 0,
					(check_log->param.log_flag & TRAN_CORRECT_BIT) ? 1 : 0,
					(check_log->param.log_flag & TRAN_NEXTLOG_BIT) ? 1 : 0,
					(check_log->param.log_flag & TRAN_START_SND_BIT) ? 1 : 0);
#endif
				if (!check_log->param.action_timer[ACTION_TIMER_SVCTIME]
					&& !(check_log->param.log_flag & TRAN_END_BIT)
					&& (check_log->param.log_flag  & TRAN_START_BIT))
				{
					int dummy = 0;
					/* 임계치 초과 데이터로 분류 */
					check_log->param.result_flag = SERVICE_TIME_OVER;

					/* fill exe_time end point */
					clock_gettime(CLOCK_REALTIME, &check_log->param.exe_time[EXE_TIME_END]);

					localtime_r((time_t*)&check_log->param.exe_time[EXE_TIME_END].tv_sec, &ts);

					strftime(log_day, sizeof(log_day), "%Y%m%d", &ts);
					strftime(log_time, sizeof(log_time), "%H%M%S", &ts);
					snprintf(log_time + US_OFFSET, (US_LEN + 1), "%0*ld", US_LEN, check_log->param.exe_time[EXE_TIME_END].tv_nsec/1000);

					/* 임계치를 초과한 현재 일시 설정 */
					memcpy(check_log->param.keep_log.hdr.log_day, log_day, LOG_DAY_LEN);
					memcpy(check_log->param.keep_log.hdr.log_time, log_time, LOG_TIME_LEN);

					/* 임계치 초과 시 DBIO 수행 시간 보정하게 되는 데
					 * ptrc_hash 의 db_exe_usec 값 + 현재 걸려있는 동적함수가 DBIO인 경우, 
					 * 동적함수 시작시간에서 경과한 지금 시간까지의 시간을 합산한다. */

					switch (IFID(check_log->param.keep_log.hdr.log_interface))
					{
						case IF00 : /* 상품처리 AP */
						case IF01 : /* 일괄전송 */
						case IF08 : /* 상품팩토리 AP */
						case IF09 : /* BSA AP */
						case IF10 : /* CRM 운영 AP */
						case IF11 : /* CRM 분석 AP */
						case IF13 : /* 기업CMS WAS */
						case IF15 : /* 기업뱅킹 WAS */
						case IF17 : /* 기업프리미엄 WAS */
						case IF19 : /* 개인뱅킹/오픈뱅킹 WAS */
						case IF21 : /* 외환포털/글로벌맞춤뱅킹 WAS */
						case IF22 : /* BT WAS */
						case IF23 : /* BT 외환포털/글로벌맞춤뱅킹 WAS */
						case IF25 : /* 스마트폰뱅킹 WAS */
						case IF26 : /* 자본통합 AP */
						case IF27 : /* 방카슈랑스 AP */
						case IF28 : /* EDMS WAS */
						case IF30 : /* 퇴직연금 AP_PT */
						case IF31 : /* 퇴직연금 AP_BT */
						case IF32 : /* 하나포탈 AP */
						case IF33 : /* IFRS AP */
							/* 타임아웃 시 DB 구간 측정함 */
							tmout_ptrc = get_ptrc_hash(check_log->param.keep_log.hdr.pid, check_log->param.keep_log.hdr.tid, check_log->param.keep_log.hdr.gid, check_log->param.keep_log.hdr.service_id);

							if (tmout_ptrc)
							{
								log_printf("(I) 타임아웃 발생한 ptrc 정보 가져오기 성공!, pid : %s, tid : %s, gid : %s, service_id : %s, db_exe_usec : %ld\n", 
									check_log->param.keep_log.hdr.pid, 
									check_log->param.keep_log.hdr.tid,
									check_log->param.keep_log.hdr.gid,
									check_log->param.keep_log.hdr.service_id,
									tmout_ptrc->param.db_exe_usec);

								if (tmout_ptrc->param.in_depth > 0)
								{
									CALL_TRC_DEPTH *tmp = &tmout_ptrc->param.call_trc_depth_list[tmout_ptrc->param.in_depth - 1];

									if (tmp->log_type == DBIO_TYPE)
									{
										/* dbio 함수가 시작한 시간부터 현재까지 응답시간을 계산하고 db_exe_time 와 합산한다 */
										long tmout_exe_usec = ((f_tm.tv_sec * 1000000) + (f_tm.tv_usec)) - ((tmp->s_tm.tv_sec * 1000000) + (tmp->s_tm.tv_usec));
										snprintf(check_log->param.keep_log.bdy.if00_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, tmout_ptrc->param.db_exe_usec + tmout_exe_usec);
										log_printf("(I) 미종료 DBIO 함수에 대한 응답시간 추가 + %ld", tmout_exe_usec);
									}
									else
									{
										/* DBIO 누적 시간만 전달한다 */
										snprintf(check_log->param.keep_log.bdy.if00_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, tmout_ptrc->param.db_exe_usec);
									}
								}
							}
							else
							{
								log_printf("<!> 타임아웃 발생한 ptrc 정보 가져오기 실패!, pid : %s, tid : %s, gid : %s, service_id : %s\n", 
										check_log->param.keep_log.hdr.pid, 
										check_log->param.keep_log.hdr.tid,
										check_log->param.keep_log.hdr.gid, 
										check_log->param.keep_log.hdr.service_id);
							}
							break;

						case IF02 : /* EAI (대내)AP */
						case IF03 : /* EAI (대외)AP */
						case IF04 : /* EAI (정보)AP */
						case IF05 : /* MCA (대면)AP */
						case IF06 : /* MCA (비대면)AP */
						case IF07 : /* MCA (서비스)AP */
						case IF12 : /* 기업CMS WEB */
						case IF14 : /* 기업뱅킹 WEB */
						case IF16 : /* 기업프리미엄 WEB */
						case IF18 : /* 개인뱅킹/오픈뱅킹 WEB */
						case IF20 : /* 외환포털/글로벌맞춤뱅킹 WEB */
						case IF24 : /* 스마트폰뱅킹 WEB */
						case IF29 : /* 퇴직연금 WEB */
						case IF34 : /* 상품팩토리 AP_WEB (WEB+WAS동일장비) */
						case IF35 : /* BSA AP_WEB (WEB+WAS동일장비) */
						case IF36 : /* CRM 운영 AP_WEB (WEB+WAS동일장비) */
						case IF37 : /* CRM 분석 AP_WEB (WEB+WAS동일장비) */
						case IF38 : /* IFRS AP_WEB (WEB+WAS동일장비) */
						case IF39 : /* 자본통합 AP_WEB (WEB+WAS동일장비) */
						case IF40 : /* EDMS WAS_WEB (WEB+WAS동일장비) */
						case IF41 : /* 퇴직연금 AP_BT WEB (WEB+WAS동일장비) */
							/* 타임아웃 시 DB 구간 측정하지 않음 */
							break;
					}

					sem_lock(parse_log_que_semid, qnum, SEM_UNDO);
					if (put_parse_log_que(&check_log->param, sizeof(LOG_HASH_ARR)) < 0)
					{
						/* parse_cirque full */
						log_stat->discard_logs++;
					}
					else
					{
						log_stat->O_msgs++;
					}
					sem_unlock(parse_log_que_semid, qnum, SEM_UNDO);

#ifdef _EVENT
					if (check_log->param.keep_svc.tflag)
					{
						/* Generate TRAN_EVENT_N */
						evt_log.result_flag = TRAN_EVENT_N;
		
						/* fill keep_log  - 헤더, 서비스정보 */
						memcpy(&evt_log.keep_log, &check_log->param.keep_log, sizeof(TRAN_LOG_HDR_FMT));
						/* fill service info. */
						memcpy(&evt_log.keep_svc, &check_log->param.keep_svc, sizeof(SVC_HASH_ARR));

						/* set time over event id */
						memcpy(bdy->err_id, EVENT_SERVICE_TIMEOUT, ERR_ID_LEN);
						memcpy(bdy->err_tr_cd, get_tr_cd(&check_log->param.keep_log), TR_CD_LEN);
						bdy->err_info_fld[0] = get_ctc_char(&check_log->param.keep_log);

						switch (IFID(check_log->param.keep_log.hdr.log_interface))
						{
							case IF00 : /* 상품처리 AP */
								if00_log = (TRAN_IF00_BDY_FMT *)&check_log->param.keep_log.bdy;
								if (!memcmp(evt_log.keep_svc.service_id, "CLH", strlen("CLH")) && (if00_log->rqst_rsps_dv_cd[0] == RQST_CHAR))
								{
									snprintf(tmpbuf, (TMPBUF_SIZE + 1), "%s clh 처리시간 임계치(%d sec) 초과, 요청전문을 송신하지 않았습니다.",
													log_interface_nm_info[IFID(check_log->param.keep_log.hdr.log_interface)].log_interface_nm,
													check_log->param.keep_svc.limit);
								}
								else
								{
									snprintf(tmpbuf, (TMPBUF_SIZE + 1), "%s 서비스(%s) 처리시간 임계치(%d sec) 초과 거래가 발생하였습니다.",
													log_interface_nm_info[IFID(check_log->param.keep_log.hdr.log_interface)].log_interface_nm,
													evt_log.keep_svc.service_id,
													check_log->param.keep_svc.limit);
								}
								break;
							case IF01 : /* 일괄전송 AP */
								if01_log = (TRAN_IF01_BDY_FMT *)&check_log->param.keep_log.bdy;
								if (!memcmp(evt_log.keep_svc.service_id, "CLH", strlen("CLH")) && (if00_log->rqst_rsps_dv_cd[0] == RQST_CHAR))
								{
									snprintf(tmpbuf, (TMPBUF_SIZE + 1), "%s clh 처리시간 임계치(%d sec) 초과, 요청전문을 송신하지 않았습니다.",
													log_interface_nm_info[IFID(check_log->param.keep_log.hdr.log_interface)].log_interface_nm,
													check_log->param.keep_svc.limit);
								}
								else
								{
									snprintf(tmpbuf, (TMPBUF_SIZE + 1), "%s 서비스(%s) 처리시간 임계치(%d sec) 초과 거래가 발생하였습니다.",
													log_interface_nm_info[IFID(check_log->param.keep_log.hdr.log_interface)].log_interface_nm,
													evt_log.keep_svc.service_id,
													check_log->param.keep_svc.limit);
								}
								break;
							case IF02 : /* EAI (대내)AP */
								if02_log = (TRAN_IF02_BDY_FMT *)&check_log->param.keep_log.bdy;
								if (if02_log->rqst_rsps_dv_cd[0] == RQST_CHAR)
								{                                                                                                          
									snprintf(tmpbuf, (TMPBUF_SIZE + 1), "%s 인터페이스(%s) 처리시간 임계치(%d sec) 초과, EAI서버가 요청시스템에게 요청전문을 송신하지 않았습니다.",
													log_interface_nm_info[IFID(check_log->param.keep_log.hdr.log_interface)].log_interface_nm,
													evt_log.keep_svc.service_id,
													check_log->param.keep_svc.limit);
								}
								else if (if02_log->rqst_rsps_dv_cd[0] == RSPS_CHAR)
								{
									snprintf(tmpbuf, (TMPBUF_SIZE + 1), "%s 인터페이스(%s) 처리시간 임계치(%d sec) 초과, EAI서버가 응답시스템에게 응답전문을 송신하지 않았습니다.",
													log_interface_nm_info[IFID(check_log->param.keep_log.hdr.log_interface)].log_interface_nm,
													evt_log.keep_svc.service_id,
													check_log->param.keep_svc.limit);
								}
								else
								{
									snprintf(tmpbuf, (TMPBUF_SIZE + 1), "%s 인터페이스(%s) 처리시간 임계치(%d sec) 초과 거래가 발생하였습니다.",
													log_interface_nm_info[IFID(check_log->param.keep_log.hdr.log_interface)].log_interface_nm,
													evt_log.keep_svc.service_id,
													check_log->param.keep_svc.limit);
								}
								break;
							case IF03 : /* EAI (대외)AP */
								if03_log = (TRAN_IF03_BDY_FMT *)&check_log->param.keep_log.bdy;
								if (if03_log->rqst_rsps_dv_cd[0] == RQST_CHAR)
								{                                                                                                          
									snprintf(tmpbuf, (TMPBUF_SIZE + 1), "%s 인터페이스(%s) 처리시간 임계치(%d sec) 초과, EAI서버가 요청시스템에게 요청전문을 송신하지 않았습니다.",
													log_interface_nm_info[IFID(check_log->param.keep_log.hdr.log_interface)].log_interface_nm,
													evt_log.keep_svc.service_id,
													check_log->param.keep_svc.limit);
								}
								else if (if03_log->rqst_rsps_dv_cd[0] == RSPS_CHAR)
								{
									snprintf(tmpbuf, (TMPBUF_SIZE + 1), "%s 인터페이스(%s) 처리시간 임계치(%d sec) 초과, EAI서버가 응답시스템에게 응답전문을 송신하지 않았습니다.",
													log_interface_nm_info[IFID(check_log->param.keep_log.hdr.log_interface)].log_interface_nm,
													evt_log.keep_svc.service_id,
													check_log->param.keep_svc.limit);
								}
								else
								{
									snprintf(tmpbuf, (TMPBUF_SIZE + 1), "%s 인터페이스(%s) 처리시간 임계치(%d sec) 초과 거래가 발생하였습니다.",
													log_interface_nm_info[IFID(check_log->param.keep_log.hdr.log_interface)].log_interface_nm,
													evt_log.keep_svc.service_id,
													check_log->param.keep_svc.limit);
								}
								break;
							case IF04 : /* EAI (정보)AP */
								if04_log = (TRAN_IF04_BDY_FMT *)&check_log->param.keep_log.bdy;
								if (if04_log->rqst_rsps_dv_cd[0] == RQST_CHAR)
								{                                                                                                          
									snprintf(tmpbuf, (TMPBUF_SIZE + 1), "%s 인터페이스(%s) 처리시간 임계치(%d sec) 초과, EAI서버가 요청시스템에게 요청전문을 송신하지 않았습니다.",
													log_interface_nm_info[IFID(check_log->param.keep_log.hdr.log_interface)].log_interface_nm,
													evt_log.keep_svc.service_id,
													check_log->param.keep_svc.limit);
								}
								else if (if04_log->rqst_rsps_dv_cd[0] == RSPS_CHAR)
								{
									snprintf(tmpbuf, (TMPBUF_SIZE + 1), "%s 인터페이스(%s) 처리시간 임계치(%d sec) 초과, EAI서버가 응답시스템에게 응답전문을 송신하지 않았습니다.",
													log_interface_nm_info[IFID(check_log->param.keep_log.hdr.log_interface)].log_interface_nm,
													evt_log.keep_svc.service_id,
													check_log->param.keep_svc.limit);
								}
								else
								{
									snprintf(tmpbuf, (TMPBUF_SIZE + 1), "%s 인터페이스(%s) 처리시간 임계치(%d sec) 초과 거래가 발생하였습니다.",
													log_interface_nm_info[IFID(check_log->param.keep_log.hdr.log_interface)].log_interface_nm,
													evt_log.keep_svc.service_id,
													check_log->param.keep_svc.limit);
								}
								break;
							case IF05 : /* MCA (대면)AP */
							case IF06 : /* MCA (비대면)AP */
							case IF07 : /* MCA (서비스)AP */
							case IF08 : /* 상품팩토리 AP */
							case IF09 : /* BSA AP */
							case IF10 : /* CRM 운영 AP */
							case IF11 : /* CRM 분석 AP */
							case IF12 : /* 기업CMS WEB */
							case IF13 : /* 기업CMS WAS */
							case IF14 : /* 기업뱅킹 WEB */
							case IF15 : /* 기업뱅킹 WAS */
							case IF16 : /* 기업프리미엄 WEB */
							case IF17 : /* 기업프리미엄 WAS */
							case IF18 : /* 개인뱅킹/오픈뱅킹 WEB */
							case IF19 : /* 개인뱅킹/오픈뱅킹 WAS */
							case IF20 : /* 외환포털/글로벌맞춤뱅킹 WEB */
							case IF21 : /* 외환포털/글로벌맞춤뱅킹 WAS */
							case IF22 : /* BT WAS */
							case IF23 : /* BT 외환포털/글로벌맞춤뱅킹 WAS */
							case IF24 : /* 스마트폰뱅킹 WEB */
							case IF25 : /* 스마트폰뱅킹 WAS */
							case IF26 : /* 자본통합 AP */
							case IF27 : /* 방카슈랑스 AP */
							case IF28 : /* EDMS WAS */
							case IF29 : /* 퇴직연금 WEB */
							case IF30 : /* 퇴직연금 AP_PT */
							case IF31 : /* 퇴직연금 AP_BT */
							case IF32 : /* 하나포탈 AP */
							case IF33 : /* IFRS AP */
							case IF34 : /* 상품팩토리 AP_WEB (WEB+WAS동일장비) */
							case IF35 : /* BSA AP_WEB (WEB+WAS동일장비) */
							case IF36 : /* CRM 운영 AP_WEB (WEB+WAS동일장비) */
							case IF37 : /* CRM 분석 AP_WEB (WEB+WAS동일장비) */
							case IF38 : /* IFRS AP_WEB (WEB+WAS동일장비) */
							case IF39 : /* 자본통합 AP_WEB (WEB+WAS동일장비) */
							case IF40 : /* EDMS WAS_WEB (WEB+WAS동일장비) */
							case IF41 : /* 퇴직연금 AP_BT WEB (WEB+WAS동일장비) */
									snprintf(tmpbuf, (TMPBUF_SIZE + 1), "%s 서비스(%s) 처리시간 임계치(%d sec) 초과 거래가 발생하였습니다.",
													log_interface_nm_info[IFID(check_log->param.keep_log.hdr.log_interface)].log_interface_nm,
													evt_log.keep_svc.service_id,
													check_log->param.keep_svc.limit);
								break;

							default : /* Unknown IF */
								snprintf(tmpbuf, (TMPBUF_SIZE + 1), "Unknown-IF 서비스(%s) 처리시간 임계치(%d sec) 초과 거래가 발생하였습니다.",
												evt_log.keep_svc.service_id, 
												check_log->param.keep_svc.limit - CORRECT_LIMIT);
						}

						if (strlen(tmpbuf) > 0)
						{
							snprintf(bdy->err_info_str, (ERR_INFO_STR_LEN + 1), "%-*.*s", ERR_INFO_STR_LEN, ERR_INFO_STR_LEN, tmpbuf);

							sem_lock(parse_log_que_semid, qnum, SEM_UNDO);
							if (put_parse_log_que(&evt_log, sizeof(LOG_HASH_ARR)) < 0)
							{
								/* parse_log_que full */
								log_stat->discard_logs++;
							}
							else
							{
								log_stat->N_msgs++;
							}
							sem_unlock(parse_log_que_semid, qnum, SEM_UNDO);
						}
					}
#endif
				}
				else if ((check_log->param.action_timer[ACTION_TIMER_SVCTIME] > 0)
							&& !(check_log->param.log_flag & TRAN_END_BIT)
							&& (check_log->param.log_flag  & TRAN_START_BIT))
				{
					int pidx  = atoi(check_log->param.keep_log.hdr.pidx);
					if ((tran_agt_shm->act_svc_limit[IFID(check_log->param.keep_log.hdr.log_interface)] < get_time_elapsed(check_log->param.exe_time)) &&
						(tran_agt_shm->act_svc_limit[IFID(check_log->param.keep_log.hdr.log_interface)] > 0) &&
						ptrc_hash_tbl->h_arr[pidx].param.cur_call_trc_depth)
					{
						int cur_call_trc_depth = ptrc_hash_tbl->h_arr[pidx].param.cur_call_trc_depth;
						int in_depth = ptrc_hash_tbl->h_arr[pidx].param.in_depth;
						int call_seq = ptrc_hash_tbl->h_arr[pidx].param.call_seq;
						CALL_TRC_DEPTH *call_trc_depth = &ptrc_hash_tbl->h_arr[pidx].param.call_trc_depth_list[in_depth - 1];
						char *keep_sql_id = ptrc_hash_tbl->h_arr[pidx].param.keep_sql_id;
						memset(&act_svc_dtl, 0x00, sizeof(ACTIVE_SERVICE_DETAIL));

						/* LOG_HASH 정보 */  
						memcpy(act_svc_dtl.tr_cd, get_tr_cd(&check_log->param.keep_log), TR_CD_LEN);
						memcpy(act_svc_dtl.host_name, check_log->param.keep_log.hdr.host_name, HOST_NAME_LEN);
						memcpy(act_svc_dtl.service_id, check_log->param.keep_log.hdr.service_id, SERVICE_ID_LEN);
						memcpy(act_svc_dtl.tr_section, check_log->param.keep_log.hdr.tr_section, TR_SECTION_LEN);
						memcpy(act_svc_dtl.gid, check_log->param.keep_log.hdr.gid, GID_LEN);
						memcpy(act_svc_dtl.pid, check_log->param.keep_log.hdr.pid, PID_LEN);
						memcpy(act_svc_dtl.tid, check_log->param.keep_log.hdr.tid, TID_LEN);
						memcpy(act_svc_dtl.svc_logdt, check_log->param.keep_log.hdr.log_time, LOG_TIME_LEN);
						snprintf(act_svc_dtl.svc_elapsed_time, (ELAPSED_TIME_LEN + 1), "%d", get_time_elapsed(check_log->param.exe_time));

						/* 함수시작 시각 및 경과시간 */
						if (cur_call_trc_depth > 0)
						{                       
							struct tm  t;               
							localtime_r(&call_trc_depth->s_tm.tv_sec, &t);
							snprintf(act_svc_dtl.func_logdt, (LOG_TIME_LEN + 1), "%02d%02d%02d%06ld", t.tm_hour,t.tm_min,t.tm_sec, call_trc_depth->s_tm.tv_usec);
							snprintf(act_svc_dtl.func_elapsed_time, (ELAPSED_TIME_LEN + 1), "%d", get_time_elapsed1(&call_trc_depth->s_tm));
						}

						if (!memcmp(check_log->param.keep_log.hdr.gid, ptrc_hash_tbl->h_arr[pidx].param.gid, GID_LEN))
#if 0
						if (!memcmp(check_log->param.keep_log.hdr.gid, ptrc_hash_tbl->h_arr[pidx].param.gid, GID_LEN) && 
								(ptrc_hash_tbl->h_arr[pidx].param._tid > 0))
#endif
						{
							if (strlen(ptrc_hash_tbl->h_arr[pidx].param.cont_nm) > 0)
							{                           
								memcpy(act_svc_dtl.proc_nm, ptrc_hash_tbl->h_arr[pidx].param.cont_nm, CONT_NM_LEN);
							}                           
							else                        
							{                           
								memcpy(act_svc_dtl.proc_nm, ptrc_hash_tbl->h_arr[pidx].param.proc_nm, PROC_NM_LEN);
							}

							/* PTRC_HASH 정보 */
							if (cur_call_trc_depth > 0)
							{
								if (call_trc_depth->log_type == DBIO_TYPE)
								{
									act_svc_dtl.tr_section[0] = DB_SECTION(check_log->param.keep_log.hdr.tr_section[0]);
									memcpy(act_svc_dtl.call_sql_id, keep_sql_id, MAX_SQL_ID_LEN);
								}
								snprintf(act_svc_dtl.call_trc_depth, (CALL_TRC_DEPTH_LEN + 1), "%-.*d", CALL_TRC_DEPTH_LEN,  cur_call_trc_depth);
								snprintf(act_svc_dtl.call_seq, (CALL_SEQ_LEN + 1), "%-.*d", CALL_SEQ_LEN, call_seq);
								memcpy(act_svc_dtl.call_func1, call_trc_depth->file_name /* Package */, MAX_FILE_STR_LEN);
								memcpy(act_svc_dtl.call_func2, call_trc_depth->called_func /* Method */, MAX_FUNC_STR_LEN);
							}
						}
						else
						{
							/* GID가 동일하고, Thread ID가 0보다 큰 경우.. */
						}
#ifdef _DEBUG 
						log_printf("Active Service 모니터링 기준(%d ms) 초과, 거래 정보 <<",
									tran_agt_shm->act_svc_limit[IFID(check_log->param.keep_log.hdr.log_interface)]);
						log_printf("=> 거래코드      : %s", act_svc_dtl.tr_cd);
						log_printf("=> 호스트명      : %s", act_svc_dtl.host_name);
						log_printf("=> 서비스ID      : %s", act_svc_dtl.service_id);
						log_printf("=> 구간구분      : %s", act_svc_dtl.tr_section);
						log_printf("=> GID           : %s", act_svc_dtl.gid);
						log_printf("=> PID           : %s", act_svc_dtl.pid);
						log_printf("=> TID           : %s", act_svc_dtl.tid);
						log_printf("\t=> 프로세스명    : %s", act_svc_dtl.proc_nm);
						log_printf("\t=> Call Depth    : %s", act_svc_dtl.call_trc_depth);
						log_printf("\t=> Call Sequence : %s", act_svc_dtl.call_seq);
						log_printf("\t=> Call Function1: %s", act_svc_dtl.call_func1);
						log_printf("\t=> Call Function2: %s", act_svc_dtl.call_func2);
						log_printf("\t=> Call SqlId    : %s", act_svc_dtl.call_sql_id);
						log_printf("=> 서비스 시작시각 : %s", act_svc_dtl.svc_logdt);
						log_printf("=> 서비스 경과시간 : %s", act_svc_dtl.svc_elapsed_time);
						log_printf("=> 함수 시작시각   : %s", act_svc_dtl.func_logdt);
						log_printf("=> 함수 경과시간   : %s", act_svc_dtl.func_elapsed_time);
#endif
						sem_lock(noti_send_que_semid, 0, SEM_UNDO);
						if (put_noti_send_que(&act_svc_dtl, sizeof(ACTIVE_SERVICE_DETAIL)) < 0)
						{
							/* noti_send_que full */
							log_stat->discard_logs++;
						}
						else
						{
							log_stat->A_msgs++;
						}
						sem_unlock(noti_send_que_semid, 0, SEM_UNDO);
					}
				}
			}
		}

		if (check_log->param.action_timer[ACTION_TIMER_KEEP_STATE] > 0)
		{
#ifdef _LOGBIT
			log_printf("--> KEEP_STATE_SEC (%d) [ %c - GID |%-*.*s|, LOG_BIT - S:%d, F:%d, E:%d, Corr:%d, Next:%d, Send:%d]", 
				check_log->param.action_timer[ACTION_TIMER_KEEP_STATE],
				check_log->param.result_flag,
				GID_LEN, GID_LEN,
				check_log->param.keep_log.hdr.gid,
				(check_log->param.log_flag & TRAN_START_BIT) ? 1 : 0, 
				(check_log->param.log_flag & TRAN_END_BIT) ? 1 : 0,
				(check_log->param.log_flag & TRAN_ERROR_BIT) ? 1 : 0,
				(check_log->param.log_flag & TRAN_CORRECT_BIT) ? 1 : 0,
				(check_log->param.log_flag & TRAN_NEXTLOG_BIT) ? 1 : 0,
				(check_log->param.log_flag & TRAN_START_SND_BIT) ? 1 : 0);
#endif
			check_log->param.action_timer[ACTION_TIMER_KEEP_STATE]--;

			if (!check_log->param.action_timer[ACTION_TIMER_KEEP_STATE])
			{
				/* EAI 데이터인 경우, NO_START_END 발생시 PAIR가 되는 호스트로 데이터를 전송한다. 
				 * 1호기에서 거래가 시작해서 2호기에서 거래가 끝나는 경우, 처리함 - 2011.03.16 수협은행에서 추가함
				 * 호스트명을 검색하여 tr_sync로 받은데이터를 걸러낸다 */
				if (((IFID(check_log->param.keep_log.hdr.log_interface) == IF02) ||
					(IFID(check_log->param.keep_log.hdr.log_interface) == IF03) ||
					(IFID(check_log->param.keep_log.hdr.log_interface) == IF04)) &&
					!strncmp(check_log->param.keep_log.hdr.host_name, my_hostname, HOST_NAME_LEN) && 
					((check_log->param.result_flag == NO_START_END) || (check_log->param.result_flag == NO_START_ERROR)) && 
					pair_agent_yn)
				{
					log_printf(">> put_sync_send_que --> ( result_flag :|%c|, gid : |%-*.*s|, svc_id : |%-*.*s| )", 
						check_log->param.result_flag,
						GID_LEN, GID_LEN, check_log->param.keep_log.hdr.gid,
						SERVICE_ID_LEN, SERVICE_ID_LEN, check_log->param.keep_log.hdr.service_id);

					/* tr_sync로 데이터 전송 */
					sem_lock(sync_send_que_semid, 0/* 0으로 고정 */, SEM_UNDO);
					if (put_sync_send_que(&check_log->param.keep_log, sizeof(TRAN_LOG_FMT)) < 0)
					{
						/* sync_send_que full */
						log_stat->discard_logs++;
					}
					else
					{
						log_stat->Y_msgs++;
					}
					sem_unlock(sync_send_que_semid, 0/* 0으로 고정 */, SEM_UNDO);
				}
				/* G에서 F로 바뀐 경우, S가 먼저 전송되어 진 후에 F를 전송할 수 있다.*/
				else if ((check_log->param.result_flag != GENERAL_END) ||
						 ((check_log->param.result_flag == GENERAL_END) && 
						 ((check_log->param.log_flag & TRAN_START_BIT) && 
						  (check_log->param.log_flag & TRAN_START_SND_BIT))))
				{
#ifdef _DEBUG
					log_printf("check_log->param.log_flag : 0x%08x, 0x%08x", 
							check_log->param.log_flag, (TRAN_START_BIT | TRAN_START_SND_BIT));
#endif
					sem_lock(parse_log_que_semid, qnum, SEM_UNDO);
					if (put_parse_log_que(&check_log->param, sizeof(LOG_HASH_ARR)) < 0)
					{
						/* parse_cirque full */
						log_stat->discard_logs++;
					}
					else
					{
						if (check_log->param.result_flag == NO_START_END)
						{
							log_stat->G_msgs++;
						}
						else if (check_log->param.result_flag == NO_START_ERROR)
						{
							log_stat->D_msgs++;
						}
						else if (check_log->param.result_flag == GENERAL_END)
						{
							log_stat->F_msgs++;
						}
						else
						{
							log_printf("<!> log_stat update error! result_flag : '%c'", check_log->param.result_flag);
						}
					}
					sem_unlock(parse_log_que_semid, qnum, SEM_UNDO);
				}
#if 0
				else
				{
					check_log->param.action_timer[ACTION_TIMER_KEEP_STATE]++;
					log_printf("<!> 시작로그가 아직 미전송되어서 종료로그를 전송하지 않음. GID:|%-*.*s|, LOG_BIT:0x%08x",
							GID_LEN, GID_LEN, check_log->param.keep_log.hdr.gid, check_log->param.log_flag);
				}
#endif
			}
		}

		if ((check_log->param.action_timer[ACTION_TIMER_SVCTIME] <= 0) && 
		    (check_log->param.action_timer[ACTION_TIMER_KEEP_STATE] <= 0))
		{
			int exe_time = get_mili_time_delay(check_log->param.exe_time);
#ifdef _DEBUG
			log_printf("이용한 데이터 삭제... array_idx : %d\n", check_log->my_idx);
			log_printf("---> 결과플래그 : |%c|, 경과시간 : %ld (ms)", check_log->param.result_flag, exe_time);
#endif

			/* 공유메모리에서 반환 */
			if (check_log->pre_idx == NULL_IDX)
			{
				log_hash_tbl->h_idx[check_log->hash_idx] = check_log->next_idx;

				if (check_log->next_idx != NULL_IDX)
				{
					log_hash_tbl->h_arr[check_log->next_idx].pre_idx = NULL_IDX;
				}
			}
			else
			{
				log_hash_tbl->h_arr[check_log->pre_idx].next_idx = check_log->next_idx;

				if (check_log->next_idx != NULL_IDX)
				{
					log_hash_tbl->h_arr[check_log->next_idx].pre_idx = check_log->pre_idx;
				}
			}

			log_hash_push(&log_hash_tbl->available, check_log->my_idx);
			log_hash_tbl->alloc_cnt--;
		}
		else 
		{
			log_hash_push(&checked, check_log->my_idx);
		}
	}
	memcpy(&log_hash_tbl->used, &checked, sizeof(LOG_HASH_STK));

	if (print_time > 0)
	{
		log_printf("> LOG HASH  Usage [ Total: %d, (%d/%d) used ], SyncSendQueueing (%d), NotiSendQueuing (%d), A_Msgs (%d)",
			log_hash_tbl->alloc_cnt, 
			log_hash_tbl->used.top,
			log_hash_tbl->available.top,
			get_sync_send_queueing(),
			get_noti_send_queueing(),
			log_stat->A_msgs);
	}

	if (!log_hash_tbl->alloc_cnt)
	{
		if (++ntime == clear_time)
		{
			ntime = 0;
		}
	}

	return;
}


static char *get_tr_cd(TRAN_LOG_FMT *keep_log)
{
	switch (IFID(keep_log->hdr.log_interface))
	{
		case IF00 : /* 상품처리 AP */
		case IF01 : /* 일괄전송 */
		case IF02 : /* EAI (대내)AP */
		case IF03 : /* EAI (대외)AP */
		case IF04 : /* EAI (정보)AP */
		case IF05 : /* MCA (대면)AP */
		case IF06 : /* MCA (비대면)AP */
		case IF07 : /* MCA (서비스)AP */
		case IF08 : /* 상품팩토리 AP */
		case IF09 : /* BSA AP */
		case IF10 : /* CRM 운영 AP */
		case IF11 : /* CRM 분석 AP */
		case IF12 : /* 기업CMS WEB */
		case IF13 : /* 기업CMS WAS */
		case IF14 : /* 기업뱅킹 WEB */
		case IF15 : /* 기업뱅킹 WAS */
		case IF16 : /* 기업프리미엄 WEB */
		case IF17 : /* 기업프리미엄 WAS */
		case IF18 : /* 개인뱅킹/오픈뱅킹 WEB */
		case IF19 : /* 개인뱅킹/오픈뱅킹 WAS */
		case IF20 : /* 외환포털/글로벌맞춤뱅킹 WEB */
		case IF21 : /* 외환포털/글로벌맞춤뱅킹 WAS */
		case IF22 : /* BT WAS */
		case IF23 : /* BT 외환포털/글로벌맞춤뱅킹 WAS */
		case IF24 : /* 스마트폰뱅킹 WEB */
		case IF25 : /* 스마트폰뱅킹 WAS */
		case IF26 : /* 자본통합 AP */
		case IF27 : /* 방카슈랑스 AP */
		case IF28 : /* EDMS WAS */
		case IF29 : /* 퇴직연금 WEB */
		case IF30 : /* 퇴직연금 AP_PT */
		case IF31 : /* 퇴직연금 AP_BT */
		case IF32 : /* 하나포탈 AP */
		case IF33 : /* IFRS AP */
		case IF34 : /* 상품팩토리 AP_WEB (WEB+WAS동일장비) */
		case IF35 : /* BSA AP_WEB (WEB+WAS동일장비) */
		case IF36 : /* CRM 운영 AP_WEB (WEB+WAS동일장비) */
		case IF37 : /* CRM 분석 AP_WEB (WEB+WAS동일장비) */
		case IF38 : /* IFRS AP_WEB (WEB+WAS동일장비) */
		case IF39 : /* 자본통합 AP_WEB (WEB+WAS동일장비) */
		case IF40 : /* EDMS WAS_WEB (WEB+WAS동일장비) */
		case IF41 : /* 퇴직연금 AP_BT WEB (WEB+WAS동일장비) */
			return keep_log->bdy.if00_log.tr_cd;
		default:
			return BLANK20_STRING;
	}
}


static int get_time_elapsed(struct timespec *tm_st)
{
	/* 현재 시간 구하기 */
	struct tm t;
	struct timeval  now;
	long   diff_ms;

	gettimeofday(&now, NULL);
	localtime_r(&now.tv_sec, &t);
	tm_st[EXE_TIME_END].tv_sec = mktime(&t);
	tm_st[EXE_TIME_END].tv_nsec = now.tv_usec * 1000;

	/* 현재 시간 - 로그 시작 시간 */
	diff_ms = get_mili_time_delay(tm_st);
	return (int)diff_ms;
}


static char get_ctc_char(TRAN_LOG_FMT *keep_log)
{
	switch (IFID(keep_log->hdr.log_interface))
	{
		case IF00 : /* 상품처리 AP */
		case IF01 : /* 일괄전송 */
		case IF02 : /* EAI (대내)AP */
		case IF03 : /* EAI (대외)AP */
		case IF04 : /* EAI (정보)AP */
		case IF05 : /* MCA (대면)AP */
		case IF06 : /* MCA (비대면)AP */
		case IF07 : /* MCA (서비스)AP */
		case IF08 : /* 상품팩토리 AP */
		case IF09 : /* BSA AP */
		case IF10 : /* CRM 운영 AP */
		case IF11 : /* CRM 분석 AP */
		case IF22 : /* BT WAS */
		case IF23 : /* BT 외환포털/글로벌맞춤뱅킹 WAS */
		case IF26 : /* 자본통합 AP */
		case IF27 : /* 방카슈랑스 AP */
		case IF28 : /* EDMS WAS */
		case IF30 : /* 퇴직연금 AP_PT */
		case IF31 : /* 퇴직연금 AP_BT */
		case IF32 : /* 하나포탈 AP */
		case IF33 : /* IFRS AP */
			/* 채널유형구분코드가 "ICT"면 센터컷거래 */
			return !memcmp(keep_log->bdy.if00_log.meth_cd, "ICT", METH_CD_LEN) ? 'C':'O';
		default :
			return ' ';
	}
}


int get_time_elapsed1(struct timeval *s_tm)
{
	/* 현재 시간 구하기 */
	struct tm t;
	struct timeval  now;
	long   diff_ms;

	struct timespec tm_st[2];
	tm_st[EXE_TIME_BEGIN].tv_sec = s_tm->tv_sec;
	tm_st[EXE_TIME_BEGIN].tv_nsec = s_tm->tv_usec * 1000;

	gettimeofday(&now, NULL);
	localtime_r(&now.tv_sec, &t);
	tm_st[EXE_TIME_END].tv_sec = mktime(&t);
	tm_st[EXE_TIME_END].tv_nsec = now.tv_usec * 1000;

	/* 현재 시간 - 로그 시작 시간 */
	diff_ms = get_mili_time_delay(tm_st);

	return (int)diff_ms;
}
