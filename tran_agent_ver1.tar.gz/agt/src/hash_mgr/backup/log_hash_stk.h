#ifndef __log_hash_stk_h__
#define __log_hash_stk_h__

/*
 functions
 */
int log_hash_push(LOG_HASH_STK *st, int val);
int log_hash_pop(LOG_HASH_STK *st);
void log_hash_show(LOG_HASH_STK *st);

#endif /*__log_hash_stk_h__*/
