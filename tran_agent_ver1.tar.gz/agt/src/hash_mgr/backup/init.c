#include "hash_mgr.h"
#include "parse_log_que.h"
#include "sync_send_que.h"
#include "noti_send_que.h"
#include "ptrc_hash_stk.h"
#include "log_if_def.h"
#include "init.h"

/* 
 global variables
 */
PROCESS_INFO	*proc_info;

LOG_HASH_TBLS	*log_hash_tbls;
LOG_HASH_TBL	*log_hash_tbl;
SVC_HASH_TBL	*svc_hash_tbl;
PTRC_HASH_TBL	*ptrc_hash_tbl;
TRAN_AGT_SHM	*tran_agt_shm;
LOG_STAT		*log_stat;

char log_home_dir[512];
char my_hostname[HOST_NAME_LEN + 1];
char log_interface[LOG_INTERFACE_LEN + 1];
char tr_section[TR_SECTION_LEN + 1];

int  parse_log_que_shmid, parse_log_que_shmkey;
int  parse_log_que_semid, parse_log_que_semkey;
int  sync_send_que_shmid, sync_send_que_shmkey;
int  sync_send_que_semid, sync_send_que_semkey;
int  noti_send_que_shmid, noti_send_que_shmkey;
int  noti_send_que_semid, noti_send_que_semkey;
int  log_hash_tbl_shmid, log_hash_tbl_shmkey;
int  log_hash_tbl_semid, log_hash_tbl_semkey;
int  svc_hash_tbl_shmid, svc_hash_tbl_shmkey;
int  svc_hash_tbl_semid, svc_hash_tbl_semkey;
int  ptrc_hash_tbl_shmid, ptrc_hash_tbl_shmkey;
int  ptrc_hash_tbl_semid, ptrc_hash_tbl_semkey;
int  tran_agt_shmid, tran_agt_shmkey;
int  tran_agt_semid, tran_agt_semkey;

int  default_timeout_sec;
int  clh_rsps_end_chk_sec;

/* sync pair agent flag */
int  pair_agent_yn;

/* ptrc hash timout(sec) */
int  tmout_pid_not_exist;
int  tmout_tran_done_trc_sts;
int  tmout_tran_start_trc_sts;
int  tmout_tran_evt_send_trc_sts;

int  log_interface_num;
int  cont_nm_num;

LOG_INTERFACE_NM_INFO log_interface_nm_info[MAX_IF_NUM];
CONT_NM_INFO cont_nm_info[MAX_CONT_NM];

static int comp_cont_nm(const void *a, const void* b)
{
	const CONT_NM_INFO *cont1 = (const CONT_NM_INFO *)a;
	const CONT_NM_INFO *cont2 = (const CONT_NM_INFO *)b;

	return strcmp(cont1->cont_nm, cont2->cont_nm);
}

bool init(int qnum)
{
	proc_info = NULL;

	if (!check_env_var()) return false;
	if (!init_config(qnum)) return false;
	if (!create_tran_agt_sem()) return false;
	if (!create_tran_agt_shm(qnum)) return false;
	if (!create_que(qnum)) return false;
	if (!create_log_hash_tbl(qnum)) return false;
	if (!create_svc_hash_tbl()) return false;
	if (!create_ptrc_hash_tbl()) return false;

	/* ACTIVE SERVICE LIST 이벤트 발생 임계치 지정 */
	update_active_service_limit();

	return true;
}


bool update_active_service_limit(void)
{
	char ret_str[128], ifxx[16];
	int i;

	if (tran_agt_shm == NULL) return false;

	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "ACTIVE_SERVICE_EVENT", "ACTIVE_LIMIT", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		for (i = 0; i < MAX_IF_NUM; i++)
		{
			tran_agt_shm->act_svc_limit[i] = strtol(ret_str, NULL, 10);
		}

		log_printf("(I) update active service limit ( %d ms)", strtol(ret_str, NULL, 10));
	}

	return true;
}


bool check_env_var(void)
{
	if (!getenv("TRAN_AGT_HOME"))
	{
		printf("<!> please, check environment-variable (TRAN_AGT_HOME)\n");
		return false;
	}
	else
	{
		printf("ok, get environment-variable (TRAN_AGT_HOME : %s)\n", getenv("TRAN_AGT_HOME"));
	}

	if (!getenv ("TRAN_AGT_CFG_FILE"))
	{
		printf("<!> please, check environment-variable (TRAN_AGT_CFG_FILE)\n");
		return false;
	}
	else
	{
		printf("ok, get environment-variable (TRAN_AGT_CFG_FILE : %s)\n", getenv ("TRAN_AGT_CFG_FILE"));
	}

	return true;
}


bool init_config(int qnum)
{
	int i;
	char ret_str[128], log_dir[128], log_file[128];

	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "COMMON", "LOG_HOME", 1, ret_str) < 0) 
	{
		return false;
	}
	else
	{
		if (ret_str[0] == '/')
		{
			strcpy(log_home_dir, ret_str);
		}
		else
		{
			snprintf(log_home_dir, sizeof(log_home_dir), "%s/%s", getenv("TRAN_AGT_HOME"), ret_str);
		}

		/* 프로세스 로그 */
		snprintf(log_dir, sizeof(log_dir), "%s/proc/%s", log_home_dir, MY_PROCESS_NAME);
		snprintf(log_file, sizeof(log_file), "%s_%02d", MY_PROCESS_NAME, qnum);
		open_log(log_dir, log_file, true);
	}

	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "IPC_SHARED_MEMORY", "PARSE_LOG_QUE_SHMKEY", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		parse_log_que_shmkey = strtol(ret_str, NULL, 10);
	}

	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "IPC_SHARED_MEMORY", "SYNC_SEND_QUE_SHMKEY", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		sync_send_que_shmkey = strtol(ret_str, NULL, 10);
	}

	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "IPC_SHARED_MEMORY", "NOTI_SEND_QUE_SHMKEY", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		noti_send_que_shmkey = strtol(ret_str, NULL, 10);
	}

	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "IPC_SHARED_MEMORY", "LOG_HASH_TBL_SHMKEY", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		log_hash_tbl_shmkey = strtol(ret_str, NULL, 10);
	}

	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "IPC_SHARED_MEMORY", "SVC_HASH_TBL_SHMKEY", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		svc_hash_tbl_shmkey = strtol(ret_str, NULL, 10);
	}

	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "IPC_SEMAPHORE", "PARSE_LOG_QUE_SEMKEY", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		parse_log_que_semkey = strtol(ret_str, NULL, 10);
	}

	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "IPC_SEMAPHORE", "SYNC_SEND_QUE_SEMKEY", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		sync_send_que_semkey = strtol(ret_str, NULL, 10);
	}

	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "IPC_SEMAPHORE", "NOTI_SEND_QUE_SEMKEY", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		noti_send_que_semkey = strtol(ret_str, NULL, 10);
	}

	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "IPC_SEMAPHORE", "LOG_HASH_TBL_SEMKEY", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		log_hash_tbl_semkey = strtol(ret_str, NULL, 10);
	}

	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "IPC_SEMAPHORE", "SVC_HASH_TBL_SEMKEY", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		svc_hash_tbl_semkey = strtol(ret_str, NULL, 10);
	}

	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "IPC_SHARED_MEMORY", "PTRC_HASH_TBL_SHMKEY", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		ptrc_hash_tbl_shmkey = strtol(ret_str, NULL, 10);
	}

	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "IPC_SEMAPHORE", "PTRC_HASH_TBL_SEMKEY", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		ptrc_hash_tbl_semkey = strtol(ret_str, NULL, 10);
	}

	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "PAIR_AGENT", "IP_ADDRESS", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		if (!strcmp(ret_str, "NONE"))
		{
			pair_agent_yn = 0;
		}
		else
		{
			pair_agent_yn = 1;
		}
	}

	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "TRAN_LOGF", "LOG_INTERFACE", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		strcpy(log_interface, ret_str);
	}

	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "TRAN_LOGF", "TR_SECTION", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		strcpy(tr_section, ret_str);
	}


#define SRCH_KEY_LEN    64

	/* LOG_INTERFACE 명칭 */
	memset(log_interface_nm_info, 0, sizeof(LOG_INTERFACE_NM_INFO) * MAX_IF_NUM);
	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "TRAN_LOGF", "LOG_INTERFACE_NUM", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		log_interface_num = strtol(ret_str, NULL, 10);
	}

	for (i = 0; i < log_interface_num; i++)
	{
		char srch_key[SRCH_KEY_LEN + 1];
		snprintf(srch_key, (SRCH_KEY_LEN + 1), "LOG_INTERFACE_NM_%02d", i);

		if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "TRAN_LOGF", srch_key, 1, ret_str) < 0)
		{
			return false;
		}
		else
		{
			replace_char(ret_str, '_', ' ');
			strncpy(log_interface_nm_info[i].log_interface_nm, ret_str, IF_NM_LEN);
		}
	}

	/* Container별 LOG_INTERFACE 설정 */
	memset(cont_nm_info, 0, sizeof(CONT_NM_INFO) * MAX_CONT_NM);
	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "TRAN_LOGF", "CONTAINER_NUM", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		cont_nm_num = strtol(ret_str, NULL, 10);
	}

	for (i = 0; i < cont_nm_num; i++)
	{
		char srch_key[SRCH_KEY_LEN + 1];
		snprintf(srch_key, (SRCH_KEY_LEN + 1), "CONTAINER_%02d", i);

		/* LOG_INTERFACE */
		if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "TRAN_LOGF", srch_key, 1, ret_str) < 0)
		{
			return false;
		}
		else
		{
			strncpy(cont_nm_info[i].log_interface, ret_str, LOG_INTERFACE_LEN);
		}

		/* TR_SECTION */
		if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "TRAN_LOGF", srch_key, 2, ret_str) < 0)
		{
			return false;
		}
		else
		{
			strncpy(cont_nm_info[i].tr_section, ret_str, TR_SECTION_LEN);
		}

		/* CONTAINER LIST */
		if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "TRAN_LOGF", srch_key, 3, ret_str) < 0)
		{
			return false;
		}
		else
		{
			strncpy(cont_nm_info[i].cont_nm, ret_str, CONT_NM_LEN);
		}
	}

	qsort(cont_nm_info, cont_nm_num, sizeof(CONT_NM_INFO), comp_cont_nm);


	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "PTRC_HASH", "PID_NOT_EXIST", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		tmout_pid_not_exist = strtol(ret_str, NULL, 10);
	}

	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "PTRC_HASH", "TRAN_DONE_TRC_STS", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		tmout_tran_done_trc_sts = strtol(ret_str, NULL, 10);
	}

	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "PTRC_HASH", "TRAN_START_TRC_STS", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		tmout_tran_start_trc_sts = strtol(ret_str, NULL, 10);
	}

	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "PTRC_HASH", "TRAN_EVT_SEND_TRC_STS", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		tmout_tran_evt_send_trc_sts = strtol(ret_str, NULL, 10);
	}


	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "SERVICE_HASH", "DEFAULT_TIMEOUT_SEC", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		default_timeout_sec = strtol(ret_str, NULL, 10);
	}


	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "ACTION_TIMER", "CLH_RSPS_END_CHK_SEC", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		clh_rsps_end_chk_sec = strtol(ret_str, NULL, 10);
	}


	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "IPC_SHARED_MEMORY", "TRAN_AGT_SHMKEY", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		tran_agt_shmkey = strtol(ret_str, NULL, 10);
	}


	if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "IPC_SEMAPHORE", "TRAN_AGT_SEMKEY", 1, ret_str) < 0)
	{
		return false;
	}
	else
	{
		tran_agt_semkey = strtol(ret_str, NULL, 10);
	}

	gethostname(ret_str, HOST_NAME_LEN);
	snprintf(my_hostname, (HOST_NAME_LEN + 1), "%-*.*s ", HOST_NAME_LEN, HOST_NAME_LEN, ret_str);

	log_printf("(i) config-file(%s) read complete. ( pair_agent_yn : %d, default_timeout_sec : %d, clh_rsps_end_chk_sec : %d )", getenv("TRAN_AGT_CFG_FILE"), pair_agent_yn, default_timeout_sec, clh_rsps_end_chk_sec);

	return true;
}


bool create_tran_agt_sem(void)
{
	/* 세마포어 초기화 */
	if ((tran_agt_semid = create_sem(tran_agt_semkey, MAX_AGT_CRITICAL_SECTIONS)) < 0)
	{
		log_printf("<!> tran agent semaphore create error.[key:0x%x]", tran_agt_semkey);
		return false;
	}
	else
	{
		log_printf("(i) tran agent semaphore create complete.[key:0x%x]", tran_agt_semkey);
		return true;
	}
}


bool create_tran_agt_shm(int qnum)
{
	int q_eexist;

	sem_lock(tran_agt_semid, SEM_TRAN_AGT_SHM, SEM_UNDO);

	/* 공유 메모리 초기화 */
	if ((tran_agt_shmid = create_shm(tran_agt_shmkey, sizeof(TRAN_AGT_SHM), &q_eexist)) < 0)
	{
		log_printf("<!> tran_agt_shm create error.[key:0x%x]", tran_agt_shmkey);
		return false;
	}
	else
	{
		tran_agt_shm = (TRAN_AGT_SHM *)attach_shm(tran_agt_shmid);
		log_stat = &tran_agt_shm->log_stat[qnum];
		proc_info = tran_agt_shm->proc_info;

		if (q_eexist)
		{
			log_printf("(i) tran_agt_shm open complete.[key:0x%x]", tran_agt_shmkey);
		}
		else
		{
			log_printf("(i) tran_agt_shm create complete.[key:0x%x]", tran_agt_shmkey);
		}
	}

	sem_unlock(tran_agt_semid, SEM_TRAN_AGT_SHM, SEM_UNDO);

	return true;
}


bool create_que(int qnum)
{
	int q_eexist;
	
	/* 데이터 큐 초기화 */
	if ((parse_log_que_shmid = create_parse_log_que(parse_log_que_shmkey, qnum, &q_eexist)) < 0)
	{
		log_printf("<!> parse_log_que create error.[key:0x%x]", parse_log_que_shmkey);
		return false;
	}
	else
	{
		if (q_eexist)
		{
			log_printf("(i) parse_log_que open complete.[key:0x%x]", parse_log_que_shmkey);
		}
		else
		{
			log_printf("(i) parse_log_que create complete.[key:0x%x]", parse_log_que_shmkey);
		}
	}

	if ((sync_send_que_shmid = create_sync_send_que(sync_send_que_shmkey, 0/*단일 큐*/, &q_eexist)) < 0)
	{
		log_printf("<!> sync_send_que create error.[key:0x%x]", sync_send_que_shmkey);
		return false;
	}
	else
	{
		if (q_eexist)
		{
			log_printf("(i) sync_send_que open complete.[key:0x%x]", sync_send_que_shmkey);
		}
		else
		{
			log_printf("(i) sync_send_que create complete.[key:0x%x]", sync_send_que_shmkey);
		}
	}

	if ((noti_send_que_shmid = create_noti_send_que(noti_send_que_shmkey, 0/*단일 큐*/, &q_eexist)) < 0)
	{
		log_printf("<!> noti_send_que create error.[key:0x%x]", noti_send_que_shmkey);
		return false;
	}
	else
	{
		if (q_eexist)
		{
			log_printf("(i) noti_send_que open complete.[key:0x%x]", noti_send_que_shmkey);
		}
		else
		{
			log_printf("(i) noti_send_que create complete.[key:0x%x]", noti_send_que_shmkey);
		}
	}

	/* 세마포어 초기화 */
	if ((parse_log_que_semid = create_sem(parse_log_que_semkey, MAX_PARSE_LOG_QUE_COUNT)) < 0)
	{
		log_printf("<!> parse_log_que semaphore create error.[key:0x%x]", parse_log_que_semkey);
		return false;
	}
	else
	{
		log_printf("(i) parse_log_que semaphore create complete.[key:0x%x]", parse_log_que_semkey);
	}

	if ((sync_send_que_semid = create_sem(sync_send_que_semkey, MAX_SYNC_SEND_QUE_COUNT)) < 0)
	{
		log_printf("<!> sync_send_que semaphore create error.[key:0x%x]", sync_send_que_semkey);
		return false;
	}
	else
	{
		log_printf("(i) sync_send_que semaphore create complete.[key:0x%x]", sync_send_que_semkey);
	}

	if ((noti_send_que_semid = create_sem(noti_send_que_semkey, MAX_NOTI_SEND_QUE_COUNT)) < 0)
	{
		log_printf("<!> noti_send_que semaphore create error.[key:0x%x]", noti_send_que_semkey);
		return false;
	}
	else
	{
		log_printf("(i) noti_send_que semaphore create complete.[key:0x%x]", noti_send_que_semkey);
	}

	return true;
}


bool create_log_hash_tbl(int qnum)
{
	int q_eexist;

	/* 세마포어 초기화 */
	if ((log_hash_tbl_semid = create_sem(log_hash_tbl_semkey, MAX_LOG_HASH_TBL)) < 0)
	{
		log_printf("<!> log_hash_tbl semaphore create error.[key:0x%x]", log_hash_tbl_semkey);
		return false;
	}
	else
	{
		log_printf("(i) log_hash_tbl semaphore create complete.[key:0x%x]", log_hash_tbl_semkey);
	}

	/* 공유 메모리 초기화 */
	if ((log_hash_tbl_shmid = create_shm(log_hash_tbl_shmkey, sizeof(LOG_HASH_TBLS), &q_eexist)) < 0)
	{
		log_printf("<!> log_hash_tbl create error.[key:0x%x]", log_hash_tbl_shmkey);
		return false;
	}
	else
	{
		log_hash_tbls = (LOG_HASH_TBLS *)attach_shm(log_hash_tbl_shmid);
		log_hash_tbl = &log_hash_tbls->log_hash_tbl[qnum];

		if (q_eexist)
		{
			log_printf("(i) log_hash_tbl open complete.[key:0x%x]", log_hash_tbl_shmkey);
		}
		else
		{
			log_printf("(i) log_hash_tbl create complete.[key:0x%x]", log_hash_tbl_shmkey);
		}
	}

	return true;
}


bool create_svc_hash_tbl(void)
{
	int q_eexist;

	/* 세마포어 초기화 */
	if ((svc_hash_tbl_semid = create_sem(svc_hash_tbl_semkey, 1)) < 0)
	{
		log_printf("<!> svc_hash_tbl semaphore create error.[key:0x%x]", svc_hash_tbl_semkey);
		return false;
	}
	else
	{
		log_printf("(i) svc_hash_tbl semaphore create complete.[key:0x%x]", log_hash_tbl_semkey);
	}

	/* 공유 메모리 초기화 */
	if ((svc_hash_tbl_shmid = create_shm(svc_hash_tbl_shmkey, sizeof(SVC_HASH_TBL), &q_eexist)) < 0)
	{
		log_printf("<!> svc_hash_tbl create error.[key:0x%x]", svc_hash_tbl_shmkey);
		return false;
	}
	else
	{
		svc_hash_tbl = (SVC_HASH_TBL *)attach_shm(svc_hash_tbl_shmid);

		if (q_eexist)
		{
			log_printf("(i) svc_hash_tbl open complete.[key:0x%x]", svc_hash_tbl_shmkey);
		}
		else
		{
			log_printf("(i) svc_hash_tbl create complete.[key:0x%x]", svc_hash_tbl_shmkey);
		}
	}

	return true;
}


bool create_ptrc_hash_tbl(void)
{
	int q_eexist;

	/* 세마포어 초기화 */
	if ((ptrc_hash_tbl_semid = create_sem(ptrc_hash_tbl_semkey, 1)) < 0)
	{
		log_printf("<!> ptrc_hash_tbl semaphore create error.[key:0x%x]", ptrc_hash_tbl_semkey);
		return false;
	}
	else
	{
		log_printf("(i) ptrc_hash_tbl semaphore create complete.[key:0x%x]", ptrc_hash_tbl_semkey);
	}

	/* 공유 메모리 초기화 */
	if ((ptrc_hash_tbl_shmid = create_shm(ptrc_hash_tbl_shmkey, sizeof(PTRC_HASH_TBL), &q_eexist)) < 0)
	{
		log_printf("<!> ptrc_hash_tbl create error.[key:0x%x]", ptrc_hash_tbl_shmkey);
		return false;
	}
	else
	{
		ptrc_hash_tbl = (PTRC_HASH_TBL *)attach_shm(ptrc_hash_tbl_shmid);

		if (q_eexist)
		{
			log_printf("(i) ptrc_hash_tbl open complete.[key:0x%x]", ptrc_hash_tbl_shmkey);
		}
		else
		{
			if (ptrc_hash_tbl_shmid > 0)
			{
				sem_lock(ptrc_hash_tbl_semid, 0, SEM_UNDO);
				init_ptrc_hash_tbl();
				sem_unlock(ptrc_hash_tbl_semid, 0, SEM_UNDO);
				log_printf("(i) ptrc_hash_tbl create complete.[key:0x%x]", ptrc_hash_tbl_shmkey);
			}
		}
	}

	return true;
}


bool init_ptrc_hash_tbl(void)
{
	int i;

	log_printf("(i) initializing.. ptrc_hash_tbl.");

	ptrc_hash_tbl->alloc_cnt = 0;

	/*해시 인덱스 초기화*/
	for (i = 0; i < PTRC_HASH_IDX_SIZE; i++)
	{
		ptrc_hash_tbl->h_idx[i] = NULL_IDX;
	}

	memset(ptrc_hash_tbl->h_arr, 0, sizeof(PTRC_HASH_ARR_LIST) * PTRC_HASH_ARR_SIZE);

	/*스택 초기화*/
	ptrc_hash_tbl->available.top = 0;
	ptrc_hash_tbl->used.top = 0;

	for (i = 0; i < PTRC_HASH_ARR_SIZE; i++)
	{
		ptrc_hash_push(&ptrc_hash_tbl->available, i);
	}

	return true;
}

