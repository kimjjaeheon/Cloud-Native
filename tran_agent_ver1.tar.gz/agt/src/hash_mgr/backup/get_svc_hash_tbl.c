#include "hash_mgr.h"
#include "get_svc_hash_tbl.h"

SVC_HASH_ARR_LIST *get_svc_hash_tbl(char *service_id)
{
	int i;
	int h_arr_idx;
	u_int hash_idx;
	int next_svc;

	int *p_hidx = svc_hash_tbl->h_idx;

	SVC_HASH_ARR_LIST *p_harr = svc_hash_tbl->h_arr;
	SVC_HASH_ARR_LIST *new_svc = NULL, *tmp_svc = NULL;

	if (!svc_hash_tbl->alloc_cnt) return NULL;

	hash_idx = get_hidx((u_char *)service_id, SERVICE_ID_LEN, SVC_HASH_IDX_MASK);
	next_svc = p_hidx[hash_idx];

	for (i = 0; next_svc != NULL_IDX; next_svc = p_harr[next_svc].next_idx, i++)
	{
		tmp_svc = &p_harr[next_svc];

		if (!memcmp(tmp_svc->param.service_id, service_id, SERVICE_ID_LEN))
		{
			/*서비스 조회 성공*/
			return tmp_svc;
		}
	}

	return NULL;
}
