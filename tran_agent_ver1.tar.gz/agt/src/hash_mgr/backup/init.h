#ifndef __init_h__
#define __init_h__

/* 
 * functions 
 */

bool create_que(int qnum);
bool create_log_hash_tbl(int qnum);
bool create_svc_hash_tbl(void);
bool create_ptrc_hash_tbl(void);
bool create_tran_agt_sem(void);
bool create_tran_agt_shm(int qnum);

bool init(int qnum);
bool init_config(int qnum);
bool init_ptrc_hash_tbl(void);
bool check_env_var(void);
bool update_active_service_limit(void);

#endif /*__init_h__*/
