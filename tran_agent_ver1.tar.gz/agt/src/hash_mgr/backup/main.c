#include "hash_mgr.h"
#include "parse_log_que.h"
#include "check_log_hash.h"
#include "check_ptrc_hash.h"
#include "init.h"
#include "main.h"

extern int  log_hash_tbl_semid;
extern int  ptrc_hash_tbl_semid;
extern PROCESS_INFO *proc_info;
extern int  default_timeout_sec;

/* functions */
void update_cfg_file(void);
void alarm_job(void);

/* static functions */
static void start(void);
static void end(void);
static void sig_term(int signo);
static void *thread_alarm(void *arg);

/* static variables */
static pthread_t th;
static int qnum;

int process_idx;
int clear_time, print_time;

static void help(char *execute_file)
{
	printf("usage: %s [-hvdq:c:p:]\n", execute_file);
	printf("\t -h: help\n");
	printf("\t -v: version information\n");
	printf("\t -d: make daemon\n");
	printf("\t -q: XXth que\n");
	printf("\t -c: status log value clear second(s)\n");
	printf("\t -p: status log print second(s), disable(0)\n");
	printf("\t -i: process_info idx.(ref. agt.cfg)\n");
	exit(0);
}


static void version(void)
{
	printf("hash_mgr v2.0- 2013.3.26\n");
	exit(0);
}


static int make_daemon(void)
{
	int fd;
	pid_t pid;

	signal(SIGTTIN, SIG_IGN);
	signal(SIGTTOU, SIG_IGN);
	signal(SIGTSTP, SIG_IGN);

	if ((pid = fork()) < 0) exit(1);
	else if (pid > 0) exit(0);

	signal (SIGHUP, SIG_IGN);

	if (setpgrp() < 0) exit(1);

	for (fd = 0; fd < NOFILE; fd++) close(fd);

	fd = open( "/dev/null", O_RDWR ); /* stdin자리(0) open */
	dup(fd); /* stdin, stdout, stderr로 가는 모든 입출력이 /dev/null로.. */
	dup(fd);

	umask(0);

	signal(SIGTERM, sig_term);
	signal(SIGSEGV, sig_term);

	return 1;
}


void alarm_job(void)
{
	if (pthread_create(&th, NULL, &thread_alarm, (void *)NULL))
	{
		log_printf("pthread_create error");
	}

	return;
}


static void *thread_alarm(void *arg)
{
	while (running)
	{
		/* check modification of a config file */
		update_cfg_file();
		sleep(1);
	}

	pthread_exit(0);
}


void update_cfg_file(void)
{
	/* config 파일 변경 체크 */
	struct stat file_stat;

	if ((stat(getenv("TRAN_AGT_CFG_FILE"), &file_stat)) != 0) /* load struct */
	{
		log_printf("<!> Can't get file_stat.(%s)", getenv("TRAN_AGT_CFG_FILE"));
	}
	else
	{
		static time_t mtime;
		if (mtime == 0)
		{
			mtime = file_stat.st_mtime;
		}
		else  if (mtime != file_stat.st_mtime)
		{
			log_printf("(I) modified file(%s) mtime (%d -> %d)",
				getenv("TRAN_AGT_CFG_FILE"), mtime, file_stat.st_mtime);
			mtime = file_stat.st_mtime;

			/* agt.cfg 파일 수정 후, 반영해야 할 정보 업데이트 */
			char ret_str[128];
			if (get_nth_token_in_file_section(getenv("TRAN_AGT_CFG_FILE"), "SERVICE_HASH", "DEFAULT_TIMEOUT_SEC", 1, ret_str) < 0)
			{
				log_printf("<!> update error config[SERVICE_HASH][DEFAULT_TIMEOUT_SEC].");
			}
			else
			{
				log_printf("(I) update config[SERVICE_HASH][DEFAULT_TIMEOUT_SEC] default_timeout_sec (%d)->(%d)",
					default_timeout_sec, strtol(ret_str, NULL, 10));
				default_timeout_sec = strtol(ret_str, NULL, 10);
			}
		}
	}
	return;
}

int main(int argc, char* argv[])
{
	int opt;
	bool daemon = false;
	running = true;

	qnum = -1;
	clear_time = 0, print_time = 0;
	process_idx = -1;

	while ((opt = getopt(argc, argv, "hvdq:c:p:i:")) != -1)
	{
		switch (opt)
		{
			case 'h' : /*도움말*/
				help (argv[0]);
				break;
			case 'v' : /*버전*/
				version();
				break;
			case 'd' : /*데몬으로 구동안함*/
				daemon = true;
				break;
			case 'q' : /*XXth TCP_SEND CIRCULAR QUEUE*/
				qnum = atoi(optarg);
				break;
			case 'c' : /*status log clear time(sec)*/
				clear_time = atoi(optarg);
				break;
			case 'p' : /* status-print periodic seconds */
				print_time = atoi(optarg);
				break;
			case 'i' : /* process idx */
				process_idx = atoi(optarg);
				break;
			case '?' : /*알수 없는 옵션 설정*/
				help(argv[0]);
				break;
			default :
				help(argv[0]);
				break;
		}
	}

	if (qnum == -1)
	{
		printf("<!> option error, -q option omitted\n");
		help(argv[0]);
	}

	if (daemon)
	{
		make_daemon();
	}
	else
	{
		signal(SIGTERM, sig_term);
		signal(SIGSEGV, sig_term);
		signal(SIGINT, sig_term);
	}

	if (init(qnum) == false)
	{
		exit(1);
	}

	alarm_job();

	start();
	end();

	return 0;
}


static void end(void)
{
	log_printf("[ %s ] end.. resource clear.", MY_PROCESS_NAME);

	detach_parse_log_que();

	/* process cur_sts setting */
	if ((process_idx >= 0) && (proc_info))
	{
		if (proc_info[process_idx].proc_pid == getpid())
		{
			proc_info[process_idx].cur_sts = PROCESS_DEACT;
			log_printf("(I) pid : %d,  cur_sts set PROCESS_DEACT... ok", getpid());
		}
		else
		{
			log_printf("<!> proc_info pid mismatch (%d <> %d)", proc_info[process_idx].proc_pid, getpid());
		}
	}

	log_printf("[ %s ] end.. complete.", MY_PROCESS_NAME);

	close_log();
	return;
}


static void start(void)
{
	log_printf("%s start... running : %d", MY_PROCESS_NAME, running);

	while (running)
	{
		clock_gettime(CLOCK_REALTIME, &check_clock[FULL_CHECK_START]);

		sem_lock(log_hash_tbl_semid, qnum, SEM_UNDO);
		/* 시작,종료 로그 체크 */
		clock_gettime(CLOCK_REALTIME, &check_clock[LOG_HASH_CHECK_START]);
		check_log_hash(qnum);
		clock_gettime(CLOCK_REALTIME, &check_clock[LOG_HASH_CHECK_END]);
		sem_unlock(log_hash_tbl_semid, qnum, SEM_UNDO);

		/* 함수호출 Stack 체크 */
		if (qnum == 0)
		{
			clock_gettime(CLOCK_REALTIME, &check_clock[PTRC_HASH_CHECK_START]);
			sem_lock(ptrc_hash_tbl_semid, qnum, SEM_UNDO);
			check_ptrc_hash(qnum);
			sem_unlock(ptrc_hash_tbl_semid, qnum, SEM_UNDO);
			clock_gettime(CLOCK_REALTIME, &check_clock[PTRC_HASH_CHECK_END]);
		}

		clock_gettime(CLOCK_REALTIME, &check_clock[FULL_CHECK_END]);

#ifdef _DEBUG
		if (print_time > 0)
		{
			log_printf(">> Searching Time -> FULL %10ld [nsec], LOG %10ld [nsec], PTRC %10ld [nsec]\n", \
				get_time_delay(&check_clock[FULL_CHECK_START]),
				get_time_delay(&check_clock[LOG_HASH_CHECK_START]),
				get_time_delay(&check_clock[PTRC_HASH_CHECK_START]));
		}
#endif
		set_idle(1,0);
	}

	return;
}


static void sig_term(int signo)
{
	switch(signo)
	{
		case SIGTERM:
			log_printf(">> received SIGTERM signal to terminate!");
			break;
		case SIGSEGV:
			/*
			log_printf(">> received SIGSEGV signal to terminate!");
			*/
			exit(-1);
		case SIGHUP:
			log_printf(">> received SIGHUP signal to terminate!");
			break;
		case SIGTSTP:
			log_printf(">> received SIGTSTP signal to terminate!");
			break;
		case SIGINT:
			log_printf(">> received SIGINT signal to terminate!");
			break;
		default:
			break;
	}

	log_printf("<!> termination start");

	running = false;
	return;
}
