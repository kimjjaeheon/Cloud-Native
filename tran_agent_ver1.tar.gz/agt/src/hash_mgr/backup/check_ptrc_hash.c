#include "hash_mgr.h"
#include "init.h"
#include "parse_log_que.h"
#include "ptrc_hash_stk.h"
#include "check_ptrc_hash.h"
#include "get_svc_hash_tbl.h"
#include "log_hash_trace.h"
#include "rt_ctrl_set_def.h"
#include "set_cont_nm_info.h"

extern int  clear_time, print_time;
extern char my_hostname[HOST_NAME_LEN + 1];
extern char log_interface[LOG_INTERFACE_LEN + 1];
extern char tr_section[TR_SECTION_LEN + 1];

extern int  tmout_pid_not_exist;
extern int  tmout_tran_done_trc_sts;
extern int  tmout_tran_start_trc_sts;
extern int  tmout_tran_evt_send_trc_sts;

extern PTRC_HASH_TBL *ptrc_hash_tbl;
extern int  parse_log_que_semid;
extern int  default_timeout_sec;
extern int  log_hash_tbl_semid;

extern LOG_STAT *log_stat;

static int  get_sts_tmout_sec(PTRC_HASH_ARR_LIST *check_ptrc);

#define TMPBUF_SIZE  1024
#define MSGBUF_SIZE  16384
#define STATBUF_SIZE 16

#define GET_LOGTIME(a) {  \
		struct tm  t; \
		struct timeval  now; \
		gettimeofday(&now, NULL); \
		localtime_r(&now.tv_sec, &t);  \
		snprintf(a, (LOG_TIME_LEN + 2), "%02d%02d%02d%06ld ", t.tm_hour,t.tm_min,t.tm_sec, now.tv_usec); }

void check_ptrc_hash(int qnum)
{
	static PTRC_HASH_ARR_LIST *check_ptrc;
	static PTRC_HASH_STK checked;
	static int ntime;

	static char log_day[LOG_DAY_LEN + 1];
	static char log_time[LOG_TIME_LEN + 1];
	static char tmpbuf[TMPBUF_SIZE + 1];
	static char msgbuf[MSGBUF_SIZE + 1];
	static char statbuf[STATBUF_SIZE + 1];

	static SVC_HASH_ARR_LIST *get_svc; 

	/* 코어발생 TR 조회 로그 */
	LOG_HASH_ARR_LIST *ret_log;

	/* ERROR_INFO 메시지 생성 */
	LOG_HASH_ARR evt_log;

	CALL_TRC_DEPTH *tmp;

	int i, j;
	int access_gap_sec = 0;
	int sts_tmout_sec = 0;
	int svc_tmout_sec = 0;
	int isalive = -1;

	struct tm ts;
	struct timeval curr;

	gettimeofday(&curr, NULL);
	localtime_r((time_t*)&curr.tv_sec, &ts);

	strftime(log_day, sizeof(log_day), "%Y%m%d", &ts);
	strftime(log_time, sizeof(log_time), "%H%M%S000000", &ts);

	checked.top = 0;

	if ((ptrc_hash_tbl->used.top > PTRC_HASH_ARR_SIZE) ||
		(ptrc_hash_tbl->used.top < 0))
	{
		return;
	}

	for (i = 0; i < ptrc_hash_tbl->used.top; i++)
	{
		check_ptrc = &ptrc_hash_tbl->h_arr[ptrc_hash_tbl->used.idx[i]];
		access_gap_sec = time(NULL) - check_ptrc->param.lasted_access;
		isalive = check_ptrc->param.isalive;

#ifdef _DEBUG
		log_printf(">>1 trc_sts : %d, in_depth : %d, access_gap_sec : %d , isalive : %d, evt_flag : %d", check_ptrc->param.trc_sts, check_ptrc->param.in_depth, access_gap_sec, isalive, check_ptrc->param.evt_flag);
#endif

		if (check_ptrc->param.rsv_fld[RSV_FLD_4_SVCTIMEOUT_FLAG] == 1)
		{
			log_printf("############################################");
			log_printf("  tpsvctimeout flag on -> trc_sts : %d, in_depth : %d, service_depth : %d, access_gap_sec : %d , isalive : %d, evt_flag : %d", check_ptrc->param.trc_sts, check_ptrc->param.in_depth, check_ptrc->param.service_depth, access_gap_sec, isalive, check_ptrc->param.evt_flag);
			log_printf("############################################");

			/* 서비스 타임아웃 확인 완료 */
			check_ptrc->param.rsv_fld[RSV_FLD_4_SVCTIMEOUT_FLAG] = 2;

			/* log_flag 설정 */
			if ((check_ptrc->param.write_qidx >= 0) && (check_ptrc->param.write_qidx < MAX_LOG_HASH_TBL))
			{
				sem_lock(log_hash_tbl_semid, check_ptrc->param.write_qidx, SEM_UNDO);
				/* 서비스 타임아웃 감지에 의한 강제 서비스 에러 종료 메시지를 생성할 수 있도록 log_flag설정 */
				for (j = 0; j < check_ptrc->param.service_depth; j++)
				{
					set_log_flag(&check_ptrc->param, j + 1 /* min : 1 depth */, check_ptrc->param.write_qidx, SVC_TIMEOUT);
				}
				sem_unlock(log_hash_tbl_semid, check_ptrc->param.write_qidx, SEM_UNDO);
			}
		}

#ifdef _DEBUG
		if (check_ptrc->param.rsv_fld[RSV_FLD_4_SVCTIMEOUT_FLAG] > 0)
		{
			log_printf(">> tpsvctimeout flag on -> trc_sts : %d, in_depth : %d, access_gap_sec : %d , isalive : %d, evt_flag : %d", check_ptrc->param.trc_sts, check_ptrc->param.in_depth, access_gap_sec, isalive, check_ptrc->param.evt_flag);
		}
#endif
		if (((check_ptrc->param.trc_sts == TRAN_START_TRC_STS) || (check_ptrc->param.trc_sts == TRAN_DONE_TRC_STS)) && 
			(check_ptrc->param.in_depth > 0) && 
			((access_gap_sec >= tmout_tran_start_trc_sts) || (check_ptrc->param.rsv_fld[RSV_FLD_4_SVCTIMEOUT_FLAG] == 2) || (isalive == 0)))
		{
			if (get_svc = get_svc_hash_tbl(check_ptrc->param.service_id))
			{
				/* 서비스명이 있는 경우, SVCTIMEOUT 시간 설정 */
				svc_tmout_sec = get_svc->param.limit + CORRECT_LIMIT;
			}
			else
			{
				/* 서비스명이 없는 경우, config항목 DEFAULT_TIMEOUT_SEC 설정 */
				svc_tmout_sec = default_timeout_sec + CORRECT_LIMIT;
			}
#ifdef _DEBUG
			log_printf(">>2 access_gap_sec : %d , svc_tmout_sec : %d, isalive : %d, evt_flag : %d", access_gap_sec, svc_tmout_sec, isalive, check_ptrc->param.evt_flag);
#endif
			if ((access_gap_sec >= svc_tmout_sec) || (isalive == 0) || (check_ptrc->param.rsv_fld[RSV_FLD_4_SVCTIMEOUT_FLAG] == 2))
			{
				if (check_ptrc->param.evt_flag == 0)
				{
					/* 사후거래 분석 조회용 에러 정보성 메시지 생성 */
					memset(&evt_log, ' ', sizeof(LOG_HASH_ARR));
					TRAN_ERRINFO_BDY_FMT *bdy = (TRAN_ERRINFO_BDY_FMT *)&evt_log.keep_log.bdy;
					evt_log.result_flag = ERROR_INFO;
					evt_log.keep_log.hdr.log_type[0] = ERRINFO_TYPE;
					memcpy(evt_log.keep_log.hdr.gid, check_ptrc->param.gid, GID_LEN);

					/* container에 의한 log_interface, tr_section 설정 */
					if (set_info_by_cont_nm(evt_log.keep_log.hdr.log_interface, evt_log.keep_log.hdr.tr_section, (strlen(check_ptrc->param.cont_nm) > 0)?check_ptrc->param.cont_nm:check_ptrc->param.proc_nm, (strlen(check_ptrc->param.cont_nm) > 0)?CONT_NM_LEN:PROC_NM_LEN) == NULL)
					{
						/* 기본 값 설정 */
						memcpy(evt_log.keep_log.hdr.log_interface, log_interface, LOG_INTERFACE_LEN);
						memcpy(evt_log.keep_log.hdr.tr_section, tr_section, TR_SECTION_LEN);
					}

					memcpy(evt_log.keep_log.hdr.host_name, my_hostname, HOST_NAME_LEN);
					memcpy(evt_log.keep_log.hdr.pid, check_ptrc->param.pid, PID_LEN);
					memcpy(evt_log.keep_log.hdr.tid, check_ptrc->param.tid, TID_LEN);
					memcpy(evt_log.keep_log.hdr.pidx, check_ptrc->param.idx, IDX_LEN);

					if (strlen(check_ptrc->param.cont_nm) > 0)
					{
						snprintf(evt_log.keep_log.hdr.server_id, (SERVER_ID_LEN + 1), "%-*.*s", SERVER_ID_LEN, SERVER_ID_LEN, check_ptrc->param.cont_nm);
					}
					else if (strlen(check_ptrc->param.proc_nm) > 0)
					{
						snprintf(evt_log.keep_log.hdr.server_id, (SERVER_ID_LEN + 1), "%-*.*s", SERVER_ID_LEN, SERVER_ID_LEN, check_ptrc->param.proc_nm);
					}

					memcpy(evt_log.keep_log.hdr.service_id, check_ptrc->param.service_id, SERVICE_ID_LEN);
					memcpy(evt_log.keep_log.hdr.log_day, log_day, LOG_DAY_LEN);
					memcpy(evt_log.keep_log.hdr.log_time, log_time, LOG_TIME_LEN);

					for (j = 0; j < ptrc_hash_tbl->h_arr[ptrc_hash_tbl->used.idx[i]].param.in_depth; j++)
					{
						tmp = &ptrc_hash_tbl->h_arr[ptrc_hash_tbl->used.idx[i]].param.call_trc_depth_list[j];
						localtime_r(&tmp->s_tm.tv_sec, &ts);

						if (j == 0)
						{
							if (check_ptrc->param.rsv_fld[RSV_FLD_4_SVCTIMEOUT_FLAG] == 2)
							{
								/* 프로세스 동작 중 Time Out 감지 */
								snprintf(msgbuf, (MSGBUF_SIZE + 1), "서비스 타임아웃 발생시점에 비즈니스 동적모듈(함수) 미종료가 감지되었습니다,Call-Tree:[#%d-%c%d] %s at %s (%s::%05d)[%02d:%02d:%02d.%06ld]",
										j + 1, tmp->log_type, tmp->call_seq,
										tmp->called_func, tmp->my_func, tmp->file_name, tmp->line,
										ts.tm_hour, ts.tm_min, ts.tm_sec, tmp->s_tm.tv_usec);
							}
							else if ((check_ptrc->param.trc_sts == TRAN_START_TRC_STS) && (isalive == 1))
							{
								/* 프로세스 동작 중 처리시간 임계치 초과 */
								snprintf(msgbuf, (MSGBUF_SIZE + 1), "서비스 처리시간 임계치 초과시점에 비즈니스 동적모듈(함수) 미종료가 감지되었습니다,Call-Tree:[#%d-%c%d] %s at %s (%s::%05d)[%02d:%02d:%02d.%06ld]",
										j + 1, tmp->log_type, tmp->call_seq,
										tmp->called_func, tmp->my_func, tmp->file_name, tmp->line,
										ts.tm_hour, ts.tm_min, ts.tm_sec, tmp->s_tm.tv_usec);
							}
							else if ((check_ptrc->param.trc_sts == TRAN_DONE_TRC_STS) && (isalive == 0))
							{
								/* 정상종료 */
								snprintf(msgbuf, (MSGBUF_SIZE + 1), "업무프로세스 종료로 인한 비즈니스 동적모듈(함수) 미종료가 감지되었습니다,Call-Tree:[#%d-%c%d] %s at %s (%s::%05d)[%02d:%02d:%02d.%06ld]",
										j + 1, tmp->log_type, tmp->call_seq,
										tmp->called_func, tmp->my_func, tmp->file_name, tmp->line,
										ts.tm_hour, ts.tm_min, ts.tm_sec, tmp->s_tm.tv_usec);
							}
							else if ((check_ptrc->param.trc_sts == TRAN_START_TRC_STS) && (isalive == 0))
							{
								/* 비정상종료 */
								snprintf(msgbuf, (MSGBUF_SIZE + 1), "업무프로세스 비정상 종료로 인한 비즈니스 동적모듈(함수) 미종료가 감지되었습니다,Call-Tree:[#%d-%c%d] %s at %s (%s::%05d)[%02d:%02d:%02d.%06ld]",
										j + 1, tmp->log_type, tmp->call_seq,
										tmp->called_func, tmp->my_func, tmp->file_name, tmp->line,
										ts.tm_hour, ts.tm_min, ts.tm_sec, tmp->s_tm.tv_usec);
							}
							else
							{
								/* 기타 */
								snprintf(msgbuf, (MSGBUF_SIZE + 1), "비즈니스 동적모듈(함수) 미종료가 감지되었습니다,Call-Tree:[#%d-%c%d] %s at %s (%s::%05d)[%02d:%02d:%02d.%06ld]",
										j + 1, tmp->log_type, tmp->call_seq,
										tmp->called_func, tmp->my_func, tmp->file_name, tmp->line,
										ts.tm_hour, ts.tm_min, ts.tm_sec, tmp->s_tm.tv_usec);
							}
						}
						else
						{
							if ((tmp->log_type == DBIO_TYPE) && (check_ptrc->param.rsv_fld[RSV_FLD_5_DBIO_STS_FLAG] >= 0))
							{
								snprintf(statbuf, (STATBUF_SIZE + 1), ", stat(%d)", check_ptrc->param.rsv_fld[RSV_FLD_5_DBIO_STS_FLAG]);
							}
							else
							{
								statbuf[0] = 0;
							}

							snprintf(tmpbuf, (TMPBUF_SIZE + 1), "->[#%d-%c%d] %s at %s (%s::%05d)[%02d:%02d:%02d.%06ld]%s",
									j + 1, tmp->log_type, tmp->call_seq,
									tmp->called_func, tmp->my_func, tmp->file_name, tmp->line,
									ts.tm_hour, ts.tm_min, ts.tm_sec, tmp->s_tm.tv_usec,
									statbuf);

							if ((strlen(msgbuf) + strlen(tmpbuf)) < MSGBUF_SIZE)
							{
								strcat(msgbuf, tmpbuf);
							}
						}
					}

					char *sndbuf = msgbuf;

					/* CallDepth 데이터가 큰경우 여러번 나눠서 보낸다. */
					for (;;)
					{
						/* MICRO SECOND 단위로 시각을 기록하여 순서 정렬에 사용함 */
						GET_LOGTIME(evt_log.keep_log.hdr.log_time);
						snprintf(bdy->err_info_str, (ERR_INFO_STR_LEN + 1), "%-*.*s", ERR_INFO_STR_LEN, ERR_INFO_STR_LEN, sndbuf);

						if (strlen(sndbuf) > ERR_INFO_STR_LEN)
						{
							sndbuf += ERR_INFO_STR_LEN;
							evt_log.rt_ctrl_set[INFO_CONT_FLAG] = '1';
						}
						else 
						{
							if (evt_log.rt_ctrl_set[INFO_CONT_FLAG] == '1')
							{
								evt_log.rt_ctrl_set[INFO_CONT_FLAG] = '2';
							}
							else
							{
								evt_log.rt_ctrl_set[INFO_CONT_FLAG] = '0';
							}
						}

						sem_lock(parse_log_que_semid, qnum, SEM_UNDO);
						if (put_parse_log_que(&evt_log, sizeof(LOG_HASH_ARR)) < 0)
						{
							/* parse_log_que full */
							log_stat->discard_logs++;
						}
						else
						{
							log_stat->J_msgs++;
						}
						sem_unlock(parse_log_que_semid, qnum, SEM_UNDO);

						if (evt_log.rt_ctrl_set[INFO_CONT_FLAG] == '2') break;
						if (evt_log.rt_ctrl_set[INFO_CONT_FLAG] == '0') break;
					}

					/* 이벤트 브라우저 표시내용 - Generate TRAN_EVENT_N */
					memset(&evt_log, ' ', sizeof(LOG_HASH_ARR));
					/* 상태 플래그 */
					evt_log.result_flag = TRAN_EVENT_N;
					/* 로그 타입 */
					evt_log.keep_log.hdr.log_type[0] = ERRINFO_TYPE;
					/* 이벤트 ID */
					memcpy(bdy->err_id, EVENT_SERVICE_TIMEOUT_CALLSTACK, ERR_ID_LEN);

					/* container에 의한 log_interface, tr_section 설정 */
					if (set_info_by_cont_nm(evt_log.keep_log.hdr.log_interface, evt_log.keep_log.hdr.tr_section, (strlen(check_ptrc->param.cont_nm) > 0)?check_ptrc->param.cont_nm:check_ptrc->param.proc_nm, (strlen(check_ptrc->param.cont_nm) > 0)?CONT_NM_LEN:PROC_NM_LEN) == NULL)
					{
						/* 로그 발생 인터페이스 */
						memcpy(evt_log.keep_log.hdr.log_interface, log_interface, LOG_INTERFACE_LEN);
						/* 구간 구분 */
						memcpy(evt_log.keep_log.hdr.tr_section, tr_section, TR_SECTION_LEN);
					}

					/* 호스트 */
					memcpy(evt_log.keep_log.hdr.host_name, my_hostname, HOST_NAME_LEN);

					/* 서버 ID */
					if (strlen(check_ptrc->param.cont_nm) > 0)
					{
						snprintf(evt_log.keep_log.hdr.server_id, (SERVER_ID_LEN + 1), "%-*.*s", SERVER_ID_LEN, SERVER_ID_LEN, check_ptrc->param.cont_nm);
					}
					else if (strlen(check_ptrc->param.proc_nm) > 0)
					{
						snprintf(evt_log.keep_log.hdr.server_id, (SERVER_ID_LEN + 1),"%-*.*s", SERVER_ID_LEN, SERVER_ID_LEN, check_ptrc->param.proc_nm);
					}

					/* 서비스 ID */
					memcpy(evt_log.keep_log.hdr.service_id, check_ptrc->param.service_id, SERVICE_ID_LEN);

					/* 프로세스 ID */
					memcpy(evt_log.keep_log.hdr.pid, check_ptrc->param.pid, PID_LEN);
					/* Thread ID */
					memcpy(evt_log.keep_log.hdr.tid, check_ptrc->param.tid, TID_LEN);
					/* PTRC Index ID */
					memcpy(evt_log.keep_log.hdr.pidx, check_ptrc->param.idx, IDX_LEN);
					/* GID */
					memcpy(evt_log.keep_log.hdr.gid, check_ptrc->param.gid, GID_LEN);
					/* 로그일자 */
					memcpy(evt_log.keep_log.hdr.log_day, log_day, LOG_DAY_LEN);
					/* 로그시간 */
					memcpy(evt_log.keep_log.hdr.log_time, log_time, LOG_TIME_LEN);

					/* 거래코드(입력전문ID) */
					memcpy(bdy->err_tr_cd, check_ptrc->param.tr_cd, TR_CD_LEN);
					/* 온라인('O')/센터컷('C') 거래 구분자 입력 */
					bdy->err_info_fld[0] = check_ptrc->param.rsv_fld[RSV_FLD_0_CTC_FLAG];

					if (check_ptrc->param.rsv_fld[RSV_FLD_4_SVCTIMEOUT_FLAG] == 2)
					{
						/* 프로세스 동작 중 Time Out 감지 */
						snprintf(tmpbuf, (TMPBUF_SIZE + 1), "서비스 타임아웃 발생시점에 비즈니스 동적모듈(함수) 미종료가 감지되었습니다.(경과시간 : %ld sec) [%s][#%d-%c%d] %s at %s (%s::%05d)[%02d:%02d:%02d.%06ld]%s",
										time(NULL) - tmp->s_tm.tv_sec,
										ptrc_hash_tbl->h_arr[ptrc_hash_tbl->used.idx[i]].param.service_id,
										ptrc_hash_tbl->h_arr[ptrc_hash_tbl->used.idx[i]].param.in_depth, 
										tmp->log_type, tmp->call_seq,
										tmp->called_func, tmp->my_func, tmp->file_name, tmp->line,
										ts.tm_hour, ts.tm_min, ts.tm_sec, tmp->s_tm.tv_usec,
										statbuf);
					}
					else if ((check_ptrc->param.trc_sts == TRAN_START_TRC_STS) && (isalive == 1))
					{
						/* 프로세스 동작 중 처리시간 임계치 초과 */
						snprintf(tmpbuf, (TMPBUF_SIZE + 1), "서비스 처리시간 임계치 초과시점에 비즈니스 동적모듈(함수) 미종료가 감지되었습니다.(경과시간 : %ld sec) [%s][#%d-%c%d] %s at %s (%s::%05d)[%02d:%02d:%02d.%06ld]%s",
										time(NULL) - tmp->s_tm.tv_sec,
										ptrc_hash_tbl->h_arr[ptrc_hash_tbl->used.idx[i]].param.service_id,
										ptrc_hash_tbl->h_arr[ptrc_hash_tbl->used.idx[i]].param.in_depth, 
										tmp->log_type, tmp->call_seq,
										tmp->called_func, tmp->my_func, tmp->file_name, tmp->line,
										ts.tm_hour, ts.tm_min, ts.tm_sec, tmp->s_tm.tv_usec,
										statbuf);
					}
					else if ((check_ptrc->param.trc_sts == TRAN_DONE_TRC_STS) && (isalive == 0))
					{
						/* 정상종료 */
						snprintf(tmpbuf, (TMPBUF_SIZE + 1), "업무프로세스 종료로 인한 비즈니스 동적모듈(함수) 미종료가 감지되었습니다.(경과시간 : %ld sec) [%s][#%d-%c%d] %s at %s (%s::%05d)[%02d:%02d:%02d.%06ld]%s",
										time(NULL) - tmp->s_tm.tv_sec,
										ptrc_hash_tbl->h_arr[ptrc_hash_tbl->used.idx[i]].param.service_id,
										ptrc_hash_tbl->h_arr[ptrc_hash_tbl->used.idx[i]].param.in_depth, 
										tmp->log_type, tmp->call_seq,
										tmp->called_func, tmp->my_func, tmp->file_name, tmp->line,
										ts.tm_hour, ts.tm_min, ts.tm_sec, tmp->s_tm.tv_usec,
										statbuf);
					}
					else if ((check_ptrc->param.trc_sts == TRAN_START_TRC_STS) && (isalive == 0))
					{
						/* 비정상종료 */
						snprintf(tmpbuf, (TMPBUF_SIZE + 1), "업무프로세스 비정상 종료로 인한 비즈니스 동적모듈(함수) 미종료가 감지되었습니다.(경과시간 : %ld sec) [%s][#%d-%c%d] %s at %s (%s::%05d)[%02d:%02d:%02d.%06ld]%s",
										time(NULL) - tmp->s_tm.tv_sec,
										ptrc_hash_tbl->h_arr[ptrc_hash_tbl->used.idx[i]].param.service_id,
										ptrc_hash_tbl->h_arr[ptrc_hash_tbl->used.idx[i]].param.in_depth, 
										tmp->log_type, tmp->call_seq,
										tmp->called_func, tmp->my_func, tmp->file_name, tmp->line,
										ts.tm_hour, ts.tm_min, ts.tm_sec, tmp->s_tm.tv_usec,
										statbuf);
					}
					else
					{
						/* 기타 */
						snprintf(tmpbuf, (TMPBUF_SIZE + 1), "비즈니스 동적모듈(함수) 미종료가 감지되었습니다.(경과시간 : %ld sec) [%s][#%d-%c%d] %s at %s (%s::%05d)[%02d:%02d:%02d.%06ld]%s",
										time(NULL) - tmp->s_tm.tv_sec,
										ptrc_hash_tbl->h_arr[ptrc_hash_tbl->used.idx[i]].param.service_id,
										ptrc_hash_tbl->h_arr[ptrc_hash_tbl->used.idx[i]].param.in_depth, 
										tmp->log_type, tmp->call_seq,
										tmp->called_func, tmp->my_func, tmp->file_name, tmp->line,
										ts.tm_hour, ts.tm_min, ts.tm_sec, tmp->s_tm.tv_usec,
										statbuf);
					}

					snprintf(bdy->err_info_str, (ERR_INFO_STR_LEN + 1), "%-*.*s", ERR_INFO_STR_LEN, ERR_INFO_STR_LEN, tmpbuf);

					sem_lock(parse_log_que_semid, qnum, SEM_UNDO);

					if (put_parse_log_que(&evt_log, sizeof(LOG_HASH_ARR)) < 0)
					{
						/* parse_log_que full */
						log_stat->discard_logs++;
					}
					else
					{
						log_stat->N_msgs++;
					}

					sem_unlock(parse_log_que_semid, qnum, SEM_UNDO);

					check_ptrc->param.evt_flag = 1;
				}
			}
			else
			{
				check_ptrc->param.evt_flag = 0;
			}
		}

		if (isalive == 0) /* Down */
		{
			if (check_ptrc->param.evt_flag != 2)
			{
				/* Generate TRAN_EVENT_N(-> Process Down) */
				memset(&evt_log, ' ', sizeof(LOG_HASH_ARR));
				TRAN_ERRINFO_BDY_FMT *bdy = (TRAN_ERRINFO_BDY_FMT *)&evt_log.keep_log.bdy;

				memset(&evt_log, ' ', sizeof(LOG_HASH_ARR));
				/* 상태 플래그 */
				evt_log.result_flag = TRAN_EVENT_N;
				/* 로그 타입 */
				evt_log.keep_log.hdr.log_type[0] = ERRINFO_TYPE;
				/* 이벤트 ID */
				memcpy(bdy->err_id, EVENT_PROCESS_DOWN, ERR_ID_LEN);
				/* container에 의한 log_interface, tr_section 설정 */
				if (set_info_by_cont_nm(evt_log.keep_log.hdr.log_interface, evt_log.keep_log.hdr.tr_section, (strlen(check_ptrc->param.cont_nm) > 0)?check_ptrc->param.cont_nm:check_ptrc->param.proc_nm, (strlen(check_ptrc->param.cont_nm) > 0)?CONT_NM_LEN:PROC_NM_LEN) == NULL)
				{
					/* 로그 발생 인터페이스 */
					memcpy(evt_log.keep_log.hdr.log_interface, log_interface, LOG_INTERFACE_LEN);
					/* 구간 구분 */
					memcpy(evt_log.keep_log.hdr.tr_section, tr_section, TR_SECTION_LEN);
				}
				/* 호스트 */
				memcpy(evt_log.keep_log.hdr.host_name, my_hostname, HOST_NAME_LEN);

				/* 서버ID */
				if (strlen(check_ptrc->param.cont_nm) > 0)
				{
					snprintf(evt_log.keep_log.hdr.server_id, (SERVER_ID_LEN + 1), "%-*.*s", SERVER_ID_LEN, SERVER_ID_LEN, check_ptrc->param.cont_nm);
				}
				else if (strlen(check_ptrc->param.proc_nm) > 0)
				{
					snprintf(evt_log.keep_log.hdr.server_id, (SERVER_ID_LEN + 1), "%-*.*s", SERVER_ID_LEN, SERVER_ID_LEN, check_ptrc->param.proc_nm);
				}

				/* 프로세스 ID */
				memcpy(evt_log.keep_log.hdr.pid, check_ptrc->param.pid, PID_LEN);
				/* Thread ID */
				memcpy(evt_log.keep_log.hdr.tid, check_ptrc->param.tid, TID_LEN);
				/* Index Id */
				memcpy(evt_log.keep_log.hdr.pidx, check_ptrc->param.idx, IDX_LEN);

				/* 로그일자 */
				memcpy(evt_log.keep_log.hdr.log_day, log_day, LOG_DAY_LEN);
				/* 로그시간 */
				memcpy(evt_log.keep_log.hdr.log_time, log_time, LOG_TIME_LEN);

				/* 거래코드 */
				if (check_ptrc->param.trc_sts == TRAN_START_TRC_STS)
				{
					/* GID - 거래시작 후, 종료가 되지 않는 상태에서 다운되었다면 해당 GID를 복사한다.*/
					snprintf(evt_log.keep_log.hdr.gid, (GID_LEN + 1), "%-*.*s", GID_LEN, GID_LEN, check_ptrc->param.gid);
					/* 서비스ID */
					memcpy(evt_log.keep_log.hdr.service_id, check_ptrc->param.service_id, SERVICE_ID_LEN);
					/* 거래코드 */
					memcpy(bdy->err_tr_cd, check_ptrc->param.tr_cd, TR_CD_LEN);
					/* 온라인('O')/센터컷('C') 거래 구분자 입력 */
					bdy->err_info_fld[0] = check_ptrc->param.rsv_fld[RSV_FLD_0_CTC_FLAG];
				}
				else
				{
					memset(evt_log.keep_log.hdr.gid, ' ', GID_LEN);
					memset(evt_log.keep_log.hdr.service_id, ' ', SERVICE_ID_LEN);
					memset(bdy->err_tr_cd, ' ', TR_CD_LEN);
					memset(bdy->err_info_fld, ' ', ERR_INFO_FLD_LEN);
				}

				if (!memcmp(check_ptrc->param.proc_nm, "java", strlen("java")) && strlen(check_ptrc->param.cont_nm))
				{
					snprintf(tmpbuf, (TMPBUF_SIZE + 1), "거래추적 대상 WAS컨테이너(%s)가 종료되었습니다.", check_ptrc->param.cont_nm);
				}
				else if (!memcmp(check_ptrc->param.proc_nm, "agtchkd", strlen("agtchkd")) ||
						 !memcmp(check_ptrc->param.proc_nm, "log_collector", strlen("log_collector")))
				{
					strcpy(tmpbuf, "");
				}
				else
				{
					snprintf(tmpbuf, (TMPBUF_SIZE + 1), "거래추적 대상 프로세스(%s)가 종료되었습니다.", check_ptrc->param.proc_nm);
				}

				snprintf(bdy->err_info_str, (ERR_INFO_STR_LEN + 1), "%-*.*s", ERR_INFO_STR_LEN, ERR_INFO_STR_LEN, tmpbuf);

				if (!memcmp(check_ptrc->param.tid, "000000000000000", TID_LEN) && strlen(tmpbuf))
				{
					sem_lock(parse_log_que_semid, qnum, SEM_UNDO);

					if (put_parse_log_que(&evt_log, sizeof(LOG_HASH_ARR)) < 0)
					{
						/* parse_log_que full */
						log_stat->discard_logs++;
					}
					else
					{
						log_stat->N_msgs++;
					}

					sem_unlock(parse_log_que_semid, qnum, SEM_UNDO);
				}

				/*
				log_printf ("check_ptrc->param.trc_sts = %d\n", check_ptrc->param.trc_sts);
				*/

				if ((check_ptrc->param.rsv_fld[RSV_FLD_2_START_END_PAIR_FLAG] != '0') &&
					(check_ptrc->param.trc_sts == TRAN_START_TRC_STS))
				{
					/* 메인화면에 이벤트 생성 */
					char *sndbuf = msgbuf;
					TRAN_ERRINFO_BDY_FMT *bdy = (TRAN_ERRINFO_BDY_FMT *)&evt_log.keep_log.bdy;
					memset(&evt_log, ' ', sizeof(LOG_HASH_ARR));
					evt_log.result_flag = TRAN_EVENT_N;

					snprintf(evt_log.keep_log.hdr.gid, (GID_LEN + 1), "%-*.*s", GID_LEN, GID_LEN, check_ptrc->param.gid);

					/* container에 의한 log_interface, tr_section 설정 */
					if (set_info_by_cont_nm(evt_log.keep_log.hdr.log_interface, evt_log.keep_log.hdr.tr_section, (strlen(check_ptrc->param.cont_nm) > 0)?check_ptrc->param.cont_nm:check_ptrc->param.proc_nm, (strlen(check_ptrc->param.cont_nm) > 0)?CONT_NM_LEN:PROC_NM_LEN) == NULL)
					{
						memcpy(evt_log.keep_log.hdr.log_interface, log_interface, LOG_INTERFACE_LEN);
						memcpy(evt_log.keep_log.hdr.tr_section, tr_section, TR_SECTION_LEN);
					}

					memcpy(evt_log.keep_log.hdr.host_name, my_hostname, HOST_NAME_LEN);
					memcpy(evt_log.keep_log.hdr.pid, check_ptrc->param.pid, PID_LEN);
					memcpy(evt_log.keep_log.hdr.tid, check_ptrc->param.tid, TID_LEN);
					memcpy(evt_log.keep_log.hdr.pidx, check_ptrc->param.idx, IDX_LEN);

					memcpy(evt_log.keep_log.hdr.service_id, check_ptrc->param.service_id, SERVICE_ID_LEN);
					memcpy(evt_log.keep_log.hdr.log_day, log_day, LOG_DAY_LEN);
					memcpy(evt_log.keep_log.hdr.log_time, log_time, LOG_TIME_LEN);

					SVC_HASH_ARR_LIST *get_svc;
					if (get_svc = get_svc_hash_tbl(check_ptrc->param.service_id))
					{
						memcpy(&evt_log.keep_svc, &get_svc->param, sizeof(SVC_HASH_ARR));
					}
					else
					{
						memcpy(evt_log.keep_svc.service_id, check_ptrc->param.service_id, SERVICE_ID_LEN);
					}

					memcpy(bdy->err_id, EVENT_PROCESS_COREDUMP, ERR_ID_LEN);
					memcpy(bdy->err_tr_cd, check_ptrc->param.tr_cd, TR_CD_LEN);
					/* 온라인('O')/센터컷('C') 거래 구분자 입력 */
					bdy->err_info_fld[0] = check_ptrc->param.rsv_fld[RSV_FLD_0_CTC_FLAG];

					if (strlen(check_ptrc->param.cont_nm))
					{
						if (check_ptrc->param.in_depth > 0) 
						{
							snprintf(msgbuf, (MSGBUF_SIZE + 1), "거래 처리중 거래추적 대상 WAS컨테이너(%s)가 비정상 종료되었습니다.", check_ptrc->param.cont_nm);
						}
						else
						{
							snprintf(msgbuf, (MSGBUF_SIZE + 1), "거래 처리중 거래추적 대상 WAS컨테이너(%s)가 종료되었습니다.", check_ptrc->param.cont_nm);
						}
					}
					else
					{
						if (check_ptrc->param.in_depth > 0) 
						{
							snprintf(msgbuf, (MSGBUF_SIZE + 1), "거래 처리중 거래추적 대상 프로세스(%s)가 비정상 종료되었습니다.", check_ptrc->param.proc_nm);
						}
						else
						{
							snprintf(msgbuf, (MSGBUF_SIZE + 1), "거래 처리중 거래추적 대상 프로세스(%s)가 종료되었습니다.", check_ptrc->param.proc_nm);
						}
					}

					/* 큐 전송 */
					snprintf(bdy->err_info_str, (ERR_INFO_STR_LEN + 1), "%-*.*s", ERR_INFO_STR_LEN, ERR_INFO_STR_LEN, sndbuf);

					sem_lock(parse_log_que_semid, qnum, SEM_UNDO);

					if (put_parse_log_que(&evt_log, sizeof(LOG_HASH_ARR)) < 0)
					{
						/* parse_log_que full */
						log_stat->discard_logs++;
					}
					else
					{
						log_stat->N_msgs++;
					}

					sem_unlock(parse_log_que_semid, qnum, SEM_UNDO);

					/* 사후거래 분석 상세화면에 Process Down 정보 출력 */
					evt_log.result_flag = ERROR_INFO;
					evt_log.keep_log.hdr.log_type[0] = ERRINFO_TYPE;

					sem_lock(parse_log_que_semid, qnum, SEM_UNDO);

					if (put_parse_log_que(&evt_log, sizeof(LOG_HASH_ARR)) < 0)
					{
						/* parse_log_que full */
						log_stat->discard_logs++;
					}
					else
					{
						log_stat->J_msgs++;
					}
					sem_unlock(parse_log_que_semid, qnum, SEM_UNDO);

					if ((check_ptrc->param.write_qidx >= 0) && (check_ptrc->param.write_qidx < MAX_LOG_HASH_TBL))
					{
						sem_lock(log_hash_tbl_semid, check_ptrc->param.write_qidx, SEM_UNDO);
						/* 비정상 종료 프로세스 감지에 의한 강제 서비스 에러 종료 메시지를 생성할 수 있도록 log_flag설정 */
						for (j = 0; j < check_ptrc->param.service_depth; j++)
						{
							set_log_flag(&check_ptrc->param, j + 1 /* min : 1 depth */, check_ptrc->param.write_qidx, PROC_CORE);
						}
						sem_unlock(log_hash_tbl_semid, check_ptrc->param.write_qidx, SEM_UNDO);
					}
				}
			}

			/* 프로세스 종료상태 확인 - 정상 종료인 경우, TRAN_DONE_TRC_STS 상태로 유지 */
			if (check_ptrc->param.trc_sts != TRAN_DONE_TRC_STS)
			{
				check_ptrc->param.trc_sts = PID_NOT_EXIST;
			}
			check_ptrc->param.evt_flag = 2;
		}
		else if (isalive == 3) /* Hash Clear */
		{
			/* 해시메모리 Clear */
			check_ptrc->param.trc_sts = HASH_CLEAR_TRC_STS;
		}

		/* 삭제 대상 trc_sts에 대하여 sts_tmout_sec를 조회한다 */
		sts_tmout_sec = get_sts_tmout_sec(check_ptrc);

		if ((sts_tmout_sec >= 0) && (access_gap_sec >= sts_tmout_sec))
		{
			log_printf("(I) CHECK_PTRC HASH 데이터 삭제... array_idx : %d, trc_sts : %d, access_gap_sec : %d\n", 
					check_ptrc->my_idx, check_ptrc->param.trc_sts, access_gap_sec);

			/* 공유메모리에서 반환 */
			if (check_ptrc->pre_idx == NULL_IDX)
			{
				ptrc_hash_tbl->h_idx[check_ptrc->hash_idx] = check_ptrc->next_idx;

				if (check_ptrc->next_idx != NULL_IDX)
				{
					ptrc_hash_tbl->h_arr[check_ptrc->next_idx].pre_idx = NULL_IDX;
				}
			}
			else
			{
				ptrc_hash_tbl->h_arr[check_ptrc->pre_idx].next_idx = check_ptrc->next_idx;

				if (check_ptrc->next_idx != NULL_IDX)
				{
					ptrc_hash_tbl->h_arr[check_ptrc->next_idx].pre_idx = check_ptrc->pre_idx;
				}
			}

			ptrc_hash_push(&ptrc_hash_tbl->available, check_ptrc->my_idx);
			ptrc_hash_tbl->alloc_cnt--;
		}
		else 
		{
			ptrc_hash_push(&checked, check_ptrc->my_idx);
		}
	}

	memcpy(&ptrc_hash_tbl->used, &checked, sizeof(PTRC_HASH_STK));

	if (print_time > 0)
	{
		log_printf("> PTRC HASH -> total : %d, (%d/%d)used, J_msgs (%d), N_msgs (%d), discard_logs (%d)",
			ptrc_hash_tbl->alloc_cnt, 
			ptrc_hash_tbl->used.top,
			ptrc_hash_tbl->available.top,
			log_stat->J_msgs,
			log_stat->N_msgs,
			log_stat->discard_logs);
	}

	if (!ptrc_hash_tbl->alloc_cnt)
	{
		if (++ntime == clear_time)
		{
			/*
			ntime = J_msgs = N_msgs = discard_logs = 0;
			*/
		}
	}

	return;
}


static int  get_sts_tmout_sec(PTRC_HASH_ARR_LIST *check_ptrc)
{
	/* TRAN_DONE_TRC_STS 상태에서 서비스 타임아웃 시간 리턴 */
	SVC_HASH_ARR_LIST *get_svc; 
	int svc_tmout_sec = 0;

	/* 삭제 대상 trc_sts에 대하여 값을 가져온다 */
	switch (check_ptrc->param.trc_sts)
	{
		case PID_NOT_EXIST :
			return tmout_pid_not_exist;
		case HASH_CLEAR_TRC_STS :
			return 0;
		case TRAN_DONE_TRC_STS :
			if ((check_ptrc->param.rsv_fld[RSV_FLD_1_TRC_STS_FLAG] == TRAN_END_TRC_STS) || 
				(check_ptrc->param.rsv_fld[RSV_FLD_1_TRC_STS_FLAG] == HASH_ALLOC_TRC_STS))
			{
				/* 바로 삭제 */
				return 0;
			}
			else
			{
				if (get_svc = get_svc_hash_tbl(check_ptrc->param.service_id))
				{
					/* 서비스명이 있는 경우, SVCTIMEOUT 시간 설정 */
					svc_tmout_sec = get_svc->param.limit + CORRECT_LIMIT;
				}
				else
				{
					/* 서비스명이 없는 경우, config항목 DEFAULT_TIMEOUT_SEC 설정 */
					svc_tmout_sec = default_timeout_sec + CORRECT_LIMIT;
				}
			}
			return svc_tmout_sec;
#if 0 /* 프로세스가 살아 있는 한 PTRC_HASH는 계속 존재해야 한다 */
		case TRAN_EVT_SEND_TRC_STS :
			return tmout_tran_evt_send_trc_sts;
#endif
		default :
			return -1;
	}
}


static char *get_exe_time_str(struct timespec *clock)
{
	static char exe_time_str[EXE_TIME_LEN + 1];
	snprintf(exe_time_str, (EXE_TIME_LEN + 1), "%010ld", get_micro_time_delay(clock));
	return exe_time_str;
}
