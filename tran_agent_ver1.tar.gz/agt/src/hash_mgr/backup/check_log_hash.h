#ifndef __check_log_hash_h__
#define __check_log_hash_h__

/* function */
void check_log_hash(int qnum);

#endif /*__check_log_hash_h__*/
