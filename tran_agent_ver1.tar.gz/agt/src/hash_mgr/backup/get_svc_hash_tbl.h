#ifndef __get_svc_hash_tbl_h__
#define __get_svc_hash_tbl_h__

/*
 global variables
 */
SVC_HASH_TBL *svc_hash_tbl;

/* 
 functions
 */
SVC_HASH_ARR_LIST *get_svc_hash_tbl(char *service_id);

#endif /*__get_svc_hash_tbl_h__*/
