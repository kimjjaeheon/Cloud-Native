#include "hash_mgr.h"
#include "init.h"
#include "log_hash_trace.h"

extern LOG_HASH_TBLS   *log_hash_tbls;

LOG_HASH_ARR_LIST *set_log_flag(PTRC_HASH_ARR *ptrc, char service_depth, char qnum, int flag_type)
{
	int i;
	int h_arr_idx;
	u_int hash_idx;
	int next_log, last_log = NULL_IDX;
	char hidxbuf[1024] = {0,};
	int  offset = 0;

	LOG_HASH_TBL *log_hash_tbl = &log_hash_tbls->log_hash_tbl[qnum];

	int *p_hidx = log_hash_tbl->h_idx;
	LOG_HASH_ARR_LIST *p_harr = log_hash_tbl->h_arr;
	LOG_HASH_ARR_LIST *tmp_log = NULL;

	TRAN_LOG_FMT *keep_log;
	SVC_HASH_ARR *keep_svc;

	/* IF별 Hash 인덱스 지정 필요 */
	memcpy(hidxbuf + offset, ptrc->ptrc_var[service_depth - 1].gid, GID_UNI_LEN);
	offset += GID_UNI_LEN;

	memcpy(hidxbuf + offset, ptrc->ptrc_var[service_depth - 1].service_id, SERVICE_ID_LEN);
	offset += SERVICE_ID_LEN;

	hash_idx = get_hidx((u_char *)hidxbuf, offset, LOG_HASH_IDX_MASK);
	next_log = p_hidx[hash_idx];

	log_printf("(I) log_flag설정 TR 탐색 중.. >> HASH_INDEX : %d { GLOBAL_ID : %-*.*s,  SERVICE_ID : %-*.*s ( DEPTH : %d ), CALL_SEQ : %d, IN_DEPTH : %d }, 추가정보 - PID : %-*.*s, log_flag type : %d, next_log : %d, qnum : %d",
				hash_idx,
				GID_LEN, GID_LEN, ptrc->ptrc_var[service_depth - 1].gid,
				SERVICE_ID_LEN, SERVICE_ID_LEN, ptrc->ptrc_var[service_depth - 1].service_id,
				service_depth,
				ptrc->call_seq,
				ptrc->in_depth,
				PID_LEN, PID_LEN, ptrc->pid,
				flag_type,
				next_log,
				qnum);

	for (i = 0; next_log != NULL_IDX; next_log = p_harr[next_log].next_idx, i++)
	{
		last_log = next_log;
		tmp_log = &p_harr[next_log];
		keep_log = &tmp_log->param.keep_log;
		keep_svc = &tmp_log->param.keep_svc;

		if (!memcmp(keep_log->hdr.gid, ptrc->ptrc_var[service_depth - 1].gid, GID_UNI_LEN)
			&& !memcmp(keep_log->hdr.service_id, ptrc->ptrc_var[service_depth - 1].service_id, SERVICE_ID_LEN)
			&& !memcmp(keep_log->hdr.pid, ptrc->pid, PID_LEN))
		{
			switch (IFID(keep_log->hdr.log_interface))
			{
				case IF00 : /* 상품처리 AP */
				case IF01 : /* 일괄전송 */
				case IF08 : /* 상품팩토리 AP */
				case IF09 : /* BSA AP */
				case IF10 : /* CRM 운영 AP */
				case IF11 : /* CRM 분석 AP */
				case IF13 : /* 기업CMS WAS */
				case IF15 : /* 기업뱅킹 WAS */
				case IF17 : /* 기업프리미엄 WAS */
				case IF19 : /* 개인뱅킹/오픈뱅킹 WAS */
				case IF21 : /* 외환포털/글로벌맞춤뱅킹 WAS */
				case IF22 : /* BT WAS */
				case IF23 : /* BT 외환포털/글로벌맞춤뱅킹 WAS */
				case IF25 : /* 스마트폰뱅킹 WAS */
				case IF26 : /* 자본통합 AP */
				case IF27 : /* 방카슈랑스 AP */
				case IF28 : /* EDMS WAS */
				case IF30 : /* 퇴직연금 AP_PT */
				case IF31 : /* 퇴직연금 AP_BT */
				case IF32 : /* 하나포탈 AP */
				case IF33 : /* IFRS AP */
					/* Core 발생 시 DB 구간 측정함 */
					if ((ptrc->in_depth > 0) && (service_depth == 1))
					{
						CALL_TRC_DEPTH *tmp = &ptrc->call_trc_depth_list[ptrc->in_depth - 1];

						if (tmp->log_type == DBIO_TYPE)
						{
							struct timeval  f_tm;
							gettimeofday(&f_tm, NULL);

							/* dbio 함수가 시작한 시간부터 현재까지 응답시간을 계산하고 db_exe_time 와 합산한다 */
							long tmout_exe_usec = ((f_tm.tv_sec * 1000000) + (f_tm.tv_usec)) - ((tmp->s_tm.tv_sec * 1000000) + (tmp->s_tm.tv_usec));

							switch (IFID(keep_log->hdr.log_interface))
							{
								case IF00 : /* 상품처리 AP */
									snprintf(keep_log->bdy.if00_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
								case IF01 : /* 일괄전송 */
									snprintf(keep_log->bdy.if01_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
								case IF08 : /* 상품팩토리 AP */
									snprintf(keep_log->bdy.if09_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
								case IF09 : /* BSA AP */
									snprintf(keep_log->bdy.if09_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
								case IF10 : /* CRM 운영 AP */
									snprintf(keep_log->bdy.if10_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
								case IF11 : /* CRM 분석 AP */
									snprintf(keep_log->bdy.if11_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
								case IF13 : /* 기업CMS WAS */
									snprintf(keep_log->bdy.if13_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
								case IF15 : /* 기업뱅킹 WAS */
									snprintf(keep_log->bdy.if15_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
								case IF17 : /* 기업프리미엄 WAS */
									snprintf(keep_log->bdy.if17_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
								case IF19 : /* 개인뱅킹/오픈뱅킹 WAS */
									snprintf(keep_log->bdy.if19_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
								case IF21 : /* 외환포털/글로벌맞춤뱅킹 WAS */
									snprintf(keep_log->bdy.if21_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
								case IF22 : /* BT WAS */
									snprintf(keep_log->bdy.if22_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
								case IF23 : /* BT 외환포털/글로벌맞춤뱅킹 WAS */
									snprintf(keep_log->bdy.if23_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
								case IF25 : /* 스마트폰뱅킹 WAS */
									snprintf(keep_log->bdy.if25_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
								case IF26 : /* 자본통합 AP */
									snprintf(keep_log->bdy.if26_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
								case IF27 : /* 방카슈랑스 AP */
									snprintf(keep_log->bdy.if27_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
								case IF28 : /* EDMS WAS */
									snprintf(keep_log->bdy.if28_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
								case IF30 : /* 퇴직연금 AP_PT */
									snprintf(keep_log->bdy.if30_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
								case IF31 : /* 퇴직연금 AP_BT */
									snprintf(keep_log->bdy.if31_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
								case IF32 : /* 하나포탈 AP */
									snprintf(keep_log->bdy.if32_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
								case IF33 : /* IFRS AP */
									snprintf(keep_log->bdy.if33_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec + tmout_exe_usec);
									break;
							}
							log_printf("(I) 미종료 DBIO 함수에 대한 응답시간 추가 + %ld", tmout_exe_usec);
						}
						else
						{
							/* DBIO 누적 시간만 전달한다 */
							switch (IFID(keep_log->hdr.log_interface))
							{
								case IF00 : /* 상품처리 AP */
									snprintf(keep_log->bdy.if00_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
								case IF01 : /* 일괄전송 */
									snprintf(keep_log->bdy.if01_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
								case IF08 : /* 상품팩토리 AP */
									snprintf(keep_log->bdy.if08_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
								case IF09 : /* BSA AP */
									snprintf(keep_log->bdy.if09_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
								case IF10 : /* CRM 운영 AP */
									snprintf(keep_log->bdy.if10_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
								case IF11 : /* CRM 분석 AP */
									snprintf(keep_log->bdy.if11_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
								case IF13 : /* 기업CMS WAS */
									snprintf(keep_log->bdy.if13_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
								case IF15 : /* 기업뱅킹 WAS */
									snprintf(keep_log->bdy.if15_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
								case IF17 : /* 기업프리미엄 WAS */
									snprintf(keep_log->bdy.if17_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
								case IF19 : /* 개인뱅킹/오픈뱅킹 WAS */
									snprintf(keep_log->bdy.if19_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
								case IF21 : /* 외환포털/글로벌맞춤뱅킹 WAS */
									snprintf(keep_log->bdy.if21_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
								case IF22 : /* BT WAS */
									snprintf(keep_log->bdy.if22_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
								case IF23 : /* BT 외환포털/글로벌맞춤뱅킹 WAS */
									snprintf(keep_log->bdy.if23_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
								case IF25 : /* 스마트폰뱅킹 WAS */
									snprintf(keep_log->bdy.if25_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
								case IF26 : /* 자본통합 AP */
									snprintf(keep_log->bdy.if26_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
								case IF27 : /* 방카슈랑스 AP */
									snprintf(keep_log->bdy.if27_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
								case IF28 : /* EDMS WAS */
									snprintf(keep_log->bdy.if28_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
								case IF30 : /* 퇴직연금 AP_PT */
									snprintf(keep_log->bdy.if30_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
								case IF31 : /* 퇴직연금 AP_BT */
									snprintf(keep_log->bdy.if31_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
								case IF32 : /* 하나포탈 AP */
									snprintf(keep_log->bdy.if32_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
								case IF33 : /* IFRS AP */
									snprintf(keep_log->bdy.if33_log.db_exe_time, (EXE_TIME_LEN + 1), "%0*ld", EXE_TIME_LEN, ptrc->db_exe_usec);
									break;
							}
						}
					}
					break;

				default:
					/* 코어덤프 발생 시 DB 구간 측정하지 않음 */
					break;
			}

			if (tmp_log->param.result_flag == GENERAL_START)
			{
				log_printf("> log_flag설정 TR 탐색 완료, 현재 result_flag 상태 -> GENERAL_START. (svctime_left : %d sec)", tmp_log->param.action_timer[ACTION_TIMER_SVCTIME]);

				(flag_type == 0)?(tmp_log->param.log_flag |= PROC_CORE_START_BIT):(tmp_log->param.log_flag |= SVC_TIMEOUT_START_BIT);
				return tmp_log;
			}
			else if (tmp_log->param.result_flag == GENERAL_END)
			{
				log_printf("> log_flag설정 TR 탐색 완료, 현재 result_flag 상태 -> GENERAL_END. (svctime_left : %d sec)", tmp_log->param.action_timer[ACTION_TIMER_SVCTIME]);
				return tmp_log;
			}
			else if (tmp_log->param.result_flag == GENERAL_ERROR)
			{
				log_printf("> log_flag설정 TR 탐색 완료, 현재 result_flag 상태 -> GENERAL_ERROR. (svctime_left : %d sec)", tmp_log->param.action_timer[ACTION_TIMER_SVCTIME]);
				(flag_type == 0)?(tmp_log->param.log_flag |= PROC_CORE_ERROR_BIT):(tmp_log->param.log_flag |= SVC_TIMEOUT_ERROR_BIT);
				return tmp_log;
			}
			else if (tmp_log->param.result_flag == INCL_ERROR_END)
			{
				log_printf("> log_flag설정 TR 탐색 완료, 현재 result_flag 상태 -> INCL_ERROR_END. (svctime_left : %d sec)", tmp_log->param.action_timer[ACTION_TIMER_SVCTIME]);
				return tmp_log;
			}
			else
			{
				log_printf("> log_flag설정 TR 탐색 완료, 현재 result_flag 상태 -> UNKNOWN RESULT_FLAG (%c) (svctime_left : %d sec)", tmp_log->param.result_flag, tmp_log->param.action_timer[ACTION_TIMER_SVCTIME]);
				return tmp_log;
			}
		}
	}

	log_printf("<!> log_flag설정 TR 탐색 실패");

	return NULL;
}
