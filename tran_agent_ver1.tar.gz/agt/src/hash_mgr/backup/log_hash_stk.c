#include "hash_mgr.h"
#include "log_hash_stk.h"

int log_hash_push(LOG_HASH_STK *st, int val)
{
	if (st->top >= LOG_HASH_ARR_SIZE)
	{
		/* stk full */
		return -1;
	}

	st->idx[(st->top)++] = val;
	return st->top;
}


int log_hash_pop(LOG_HASH_STK *st)
{
	if (st->top <= 0)
	{
		/* stk empty */
		return -1;
	}
	return st->idx[--(st->top)];
}


void log_hash_show(LOG_HASH_STK *st)
{
	int i;

	log_printf("(i) total : %d\n", st->top);

	for (i = 0; i < st->top; i++)
	{
		log_printf("[%d] array_idx#%d\n", i, st->idx[i]);
	}
}
