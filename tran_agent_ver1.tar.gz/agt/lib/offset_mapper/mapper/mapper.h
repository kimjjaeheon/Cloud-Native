#ifndef __TRAN_OFFSET_MAPPER_H__
#define __TRAN_OFFSET_MAPPER_H__

struct _st_common_offset
{
    int krx_snd_start_offset;
    int krx_rcv_start_offset;
    int tr_offset;
    int tr_len;
};

struct _st_krx_offset
{
    char  type[5+1];
    char  tr_cd[11+1];

    int br_offset;
    int br_len;

    int or_offset;
    int or_len;

    int j_offset;
    int j_len;
};

int get_offset_string(const char* type, const char* ap_type, const char* data, int data_len, char* key);
int offset_mapper_create(const char* type, const char* path);
int offset_mapper_destroy();

int mapper_error_code(void);
char* mapper_error_str(void);

#endif
