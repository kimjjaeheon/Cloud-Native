#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#include "li_common_errcd.h"
#include "string_loader.h"
#include "checksum.h"
#include "crc_map.h"

/*
#define FEP_START_BIT 0x02
*/
#define FEP_START_BIT '^'
#define COMMON_OFFSET "COMMON_OFFS"

#define RCV_OFFSET_IDX 2
#define SND_OFFSET_IDX 3

enum eCOMMON_OFFSET_IDX
{
	eCOMM_TYPE_IDX    = 0,  /* Type Index           */
	eCOMM_NAME_IDX    ,     /* Name Index           */
	eCOMM_RECV_IDX    ,     /* Receive offset Index */
	eCOMM_SEND_IDX    ,     /* Send offset Index    */
	eCOMM_TRCD_IDX    ,     /* Trcd Offset Index   */
	eCOMM_TRLN_IDX          /* Trcd Offset Len     */
};

enum eOFFSET_IDX
{
	eTYPE_IDX   = eCOMM_TYPE_IDX,
	eTRCD_IDX   = eCOMM_NAME_IDX
};

struct _st_common_offset
{
	int krx_snd_start_offset;
	int krx_rcv_start_offset;
	int tr_offset;
	int tr_len;
};

struct _st_krx_offset
{
	char  type[5+1];
	char  tr_cd[11+1];

	int br_offset;
	int br_len;

	int or_offset;
	int or_len;

	int j_offset;
	int j_len;
};

static char err_str[20];

static struct _st_common_offset st_common_offset;
int g_krx_offset =-1;

int cfg_load(const char* path)
{
    int ret=0;

    const char* file = path;

	if ( !path )
	{
		mapper_errcd = ERR_OMAPPER_NULL_PATH;
		return -1;
	}

    ret=tran_create_token(file);

    fprintf(stdout, "<GET-START> Line count : %d\n", tran_get_string_line_count());
	tran_string_print_all();

    return ret;
}

int find_common_offset(const char* type)
{
	int i = 0;

	if ( !type )
	{
		mapper_errcd = ERR_OMAPPER_NULL_TYPE;
		return -1;
	}

	memset(&st_common_offset, -1, sizeof(struct _st_common_offset));

	for ( i=0; i<tran_get_string_array_size(); i++ )
	{
		if ( strcmp(type, tran_get_token_string(i, eCOMM_TYPE_IDX))  )
		{
			continue;
		}
		if ( strcmp(tran_get_token_string(i, eCOMM_NAME_IDX), COMMON_OFFSET) )
		{
			continue;
		}
		st_common_offset.krx_snd_start_offset = atoi(tran_get_token_string(i, eCOMM_SEND_IDX));
		st_common_offset.krx_rcv_start_offset = atoi(tran_get_token_string(i, eCOMM_RECV_IDX));
		st_common_offset.tr_offset = atoi(tran_get_token_string(i, eCOMM_TRCD_IDX));
		st_common_offset.tr_len    = atoi(tran_get_token_string(i, eCOMM_TRLN_IDX));
		break;
	}

	if ( st_common_offset.krx_snd_start_offset == -1 )
	{
		mapper_errcd = ERR_OMAPPER_NO_START_OFFSET;
		return -1;
	}

	return OMAPPER_RET_SUCCESS;
}

int get_send_common_offset(void)
{
	return st_common_offset.krx_snd_start_offset;
}

int get_recv_common_offset(void)
{
	return st_common_offset.krx_rcv_start_offset;
}

int insert_crc(const char* type)
{
	int i=0;
	int x=0;
	unsigned int long crc;

	struct _st_krx_offset st_krx_offset;

	if ( !type )
	{
		mapper_errcd = ERR_OMAPPER_NULL_TYPE;
		return -1;
	}

	crc_map_create_array(CRC8_MAX);

	for ( i=0; i<tran_get_string_array_size(); i++ )
	{
		if ( strcmp(tran_get_token_string(i, eTYPE_IDX), type) 
			|| !strcmp(tran_get_token_string(i, eTRCD_IDX), COMMON_OFFSET) )
		{
			continue;
		}

		x = 0;
		memset(&st_krx_offset, 0x00, sizeof(struct _st_krx_offset));

		snprintf(st_krx_offset.type, sizeof(st_krx_offset.type), "%s", tran_get_token_string(i, x++));
		

		snprintf(st_krx_offset.tr_cd, sizeof(st_krx_offset.tr_cd), "%s", tran_get_token_string(i, x++));
/*
		st_krx_offset.krx_offset = atoi(tran_get_token_string(i, x++));
		if ( g_krx_offset == -1 )
		{
			g_krx_offset = st_krx_offset.krx_offset;
		}

		st_krx_offset.tr_offset = atoi(tran_get_token_string(i, x++));
		st_krx_offset.tr_len = atoi(tran_get_token_string(i, x++));
*/
		st_krx_offset.br_offset = atoi(tran_get_token_string(i, x++));
		st_krx_offset.br_len = atoi(tran_get_token_string(i, x++));

		st_krx_offset.or_offset = atoi(tran_get_token_string(i, x++));
		st_krx_offset.or_len = atoi(tran_get_token_string(i, x++));

		st_krx_offset.j_offset = atoi(tran_get_token_string(i, x++));
		st_krx_offset.j_len = atoi(tran_get_token_string(i, x++));

		crc = crc_8(st_krx_offset.tr_cd, 11);
		crc_map_push_array(crc, st_krx_offset.tr_cd, &st_krx_offset, sizeof(struct _st_krx_offset));
	}

	crc_map_print_all();
	return OMAPPER_RET_SUCCESS;
}

int get_offset_string(const char* type, const char* ap_type, const char* data, int data_len, char* key)
{
#define KRX_AP_TYPE_LEN 6   /* 0번지 'A' & 'C' 가 KRX */
#define KRX_TR_CD_LEN   11  /* 거래코드 */
#define KRX_BR_NO       5   /* 지점코드 */
#define KRX_OR_NO       10  /* 주문번호 */
#define KRX_J_CODE      12  /* 종목코드 */

#define KRX_AP_TYPE_OFFSET 5

#define KRX_KEY_PADDING_COUNT  5 /* ' ' 5개 */
#define KRX_KEY_PADDING_STRING "     " /* ' ' 5개 */

#define IF_TYPE_IMS     1
#define IF_TYPE_UCS_FEP 2

#define IF_TYPE_IMS_LEN 3

    int ret    = 0;
    int offset = 0;
    int common_offset = 0;
	int if_type= IF_TYPE_IMS;

    char *p_data = 0x00;
    char *p_key = 0x00;

    char tr_cd[KRX_TR_CD_LEN+1] = {0x00,};
	char br_no[KRX_BR_NO    +1] = {0x00,};
	char or_no[KRX_OR_NO    +1] = {0x00,};
	char j_code[KRX_J_CODE  +1] = {0x00,};

	const char *p_ap_type = NULL;

    struct _st_krx_offset *pst=0x00;

	if ( !type )   { mapper_errcd=ERR_OMAPPER_NULL_TYPE   ; return -1; }
	if ( !ap_type ){ mapper_errcd=ERR_OMAPPER_NULL_AP_TYPE; return -1; }
	if ( !data )   { mapper_errcd=ERR_OMAPPER_NULL_DATA   ; return -1; }
	if ( !key )    { mapper_errcd=ERR_OMAPPER_NULL_KEY    ; return -1; }

    if ( (common_offset=get_send_common_offset()) < 0 )
    {
		printf("<Err> %s get common offset fail\n", __FUNCTION__);
		mapper_errcd = ERR_OMAPPER_NO_COMMON_OFFSET;
        return -1;
    }

	if ( data_len <= common_offset+KRX_TR_CD_LEN )
	{
		printf("<Err> common_offset+KRX_TR_CD_LEN=%d, data_len:%d\n", common_offset+KRX_TR_CD_LEN, data_len);
		mapper_errcd = ERR_OMAPPER_DATA_LEN_ERROR;
		return -1;
	}

    /* 전문 */
    p_data = (char*)data;
    p_data += common_offset;

    /* key buffer */
    p_key = key;


    /* KRX 거래 유무 확인 
     * ap_type의 0번지가 'A'와 'C'가 KRX 거래 */
	if ( ap_type[0] != 'A' && ap_type[0] != 'C' )
	{
		/*
		log_printf("<!> ap_type is not KRX. [ap_type:%s]\n", ap_type);
		*/
		printf("<Err> ap_type is not KRX. [ap_type:%s]\n", ap_type);
		mapper_errcd = ERR_OMAPPER_NOT_SUPPORT_AP_TYPE;
		return -1;
	}


/*
	if ( if_type == IF_TYPE_UCS_FEP ) { p_data += 100; };
*/
    memcpy(tr_cd, p_data+KRX_TR_CD_LEN, KRX_TR_CD_LEN);

    pst = crc_map_search_data(tr_cd, KRX_TR_CD_LEN);

    if ( !pst )
    {
		/*
        log_printf("<Err> CRC not exist. [tr_cd:%s, errno:%d]", tr_cd, mapper_errcd);
		*/
		snprintf(err_str, KRX_TR_CD_LEN+1, "%s", tr_cd);
        return -1;
    }

/*
    memcpy(p_key+offset , p_data+pst->br_offset, pst->br_len); offset += pst->br_len;
    memcpy(p_key+offset , p_data+pst->or_offset, pst->or_len); offset += pst->or_len;
    memcpy(p_key+offset , p_data+pst->j_offset,  pst->j_len); offset += pst->j_len;
*/

	if ( data_len < (pst->j_offset + pst->j_len) )
	{
		mapper_errcd = ERR_OMAPPER_DATA_LEN_ERROR;
		return -1;
	}
    memcpy(br_no , p_data+pst->br_offset, pst->br_len); offset += pst->br_len;
    memcpy(or_no , p_data+pst->or_offset, pst->or_len); offset += pst->or_len;
    memcpy(j_code, p_data+pst->j_offset,  pst->j_len);  offset += pst->j_len;

	snprintf(key, KRX_BR_NO+KRX_OR_NO+KRX_J_CODE+KRX_KEY_PADDING_COUNT+1
			, "%*.*s%*.*s%*.*s%*.*s"
			, KRX_BR_NO, KRX_BR_NO, br_no
			, KRX_OR_NO, KRX_OR_NO, or_no
			, KRX_J_CODE, KRX_J_CODE, j_code
			, KRX_KEY_PADDING_COUNT, KRX_KEY_PADDING_COUNT, KRX_KEY_PADDING_STRING);

	key[29] = 'O';

	return 1;

	/*
    log_printf("<DEV> ===>KEY [%p][tr_cd:%s]-[%s]\n", p_key, tr_cd, p_key);
	*/
}

int offset_mapper_create(const char* type, const char* path)
{
	if ( !type )
	{
		mapper_errcd = ERR_OMAPPER_NULL_TYPE;
		return -1;
	}
	if ( !path )
	{
		mapper_errcd = ERR_OMAPPER_NULL_PATH;
		return -1;
	}

	/* config 로딩 (lib string loader) */
	if ( tran_create_token(path) < 0 )
	{
		fprintf(stderr, "<Err> cfg_load fail. [err_cd:%d]\n", mapper_errcd);
		return -1;
	}
	
	if ( find_common_offset(type) < 0 )
	{
		fprintf(stderr, "<Err> common_offset not exist. [err_cd:%d]\n", mapper_errcd);
		return -1;
	}

	/* crc map에 insert */
	insert_crc(type);

	return 0;
}

int offset_mapper_destroy()
{
	/* config 로딩 정보 자원 해제 */
	tran_destroy_token();

	/* crc map 자원 해제 */
	crc_map_destroy_array();
}

int mapper_error_code(void)
{
	return mapper_errcd;
}

char* mapper_error_str(void)
{
	return err_str;
}
