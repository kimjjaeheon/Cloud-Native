#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>
#include <stdint.h>

#include "crc_smap.h"
#include "imeco_smap.h"
#include "tranm_thread.h"

#define GET_TM(stm) { \
        struct tm tm; \
        struct timeval now; \
        gettimeofday(&now, NULL); \
        localtime_r((const time_t*)&now.tv_sec, &tm); \
        sprintf(stm, "%02d-%02d %02d:%02d:%02d.%06d", tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec, now.tv_usec); \
}

pthread_mutex_t mlock = PTHREAD_MUTEX_INITIALIZER;

pthread_t smap_th;

unsigned int smap_using_count = 0;

#if 0
struct _st_data
{
	char gid[30+1];
	time_t tm;
};

struct _st_data map[(USHRT_MAX+1)*10];
#endif

struct _st_map
{
	unsigned int using_count;
	struct _st_data map[(USHRT_MAX+1)*10];
};

struct _st_map map;

int smap_test();
int map_test();

static void *thread_smap_checker(void* arg);


void smap_checker(void)
{
    if (pthread_create(&smap_th, NULL, &thread_smap_checker, (void *)NULL))
    {
        log_printf("smap_checker pthread_create error");
    }
    else
    {
        log_printf("smap_checker pthread_create success");
    }

    return;
}


static void *thread_smap_checker(void* arg)
{
    uint32_t count = 0;
	char stm[32] = {0x00,};
    while( 1 )
    {
		TRANM_MUTEX_LOCK(mlock);
		GET_TM(stm);
        if ( (count=smap_timeout_check()) > 0 )
        {
            fprintf(stdout, "[%s] <i>SMAP timeout checker -> smap using: %u/%u -> %u/%u,  clear_count: %u\n"
					, stm, *p_using_count, crc_smap_get_size()*MAX_SUB_ARRAY
					, *p_using_count-count, crc_smap_get_size()*MAX_SUB_ARRAY
					, count);
			*p_using_count -= count;
        }
		else
		{
            fprintf(stdout, "[%s] <i>SMAP timeout checker -> smap using: %u/%u,  clear_count: 0\n"
					, stm, *p_using_count, crc_smap_get_size());
		}
		TRANM_MUTEX_UNLOCK(mlock);
		fflush(stdout);
        sleep(10);
    }
}


int main(int argc, char** argv)
{

	void *p = NULL;

	memset(&map, 0x00, sizeof(map));

	p = &map;

	p_using_count = &(map.using_count);
	smap = p+sizeof(unsigned int);

	smap_checker();

	smap_test();


	sleep(3600);

	return 0;
}

int smap_test()
{
	int i=0, x=0;
	//struct _st_data data[100000];
	struct _st_data data;

	fprintf(stdout, "=== MAP_START_ADDRESS: %p-%p,  DATA_SIZE: %d, SUB_ARRAY: %d ===\n", map.map, smap, DATA_SIZE, MAX_SUB_ARRAY);

	if ( crc_smap_create_array(USHRT_MAX, sizeof(struct _st_data), smap, 30) < 0 )
	{
		printf("smap create fail. [errcd:%d]\n", mapper_error_code());
		return -1;
	}

	for ( x=0; x<2; x++)
	{
		for ( i=0; i<100000; i++ )
		{
			memset(&data, 0x00, sizeof(data));
			char a;
			char s[26+1] = "----------------------";
			char buf[30+1];

			if ( i < 10000 ) { a='A'; }
			else if ( i<20000 ) { a='B'; }
			else if ( i<30000 ) { a='C'; }
			else if ( i<40000 ) { a='D'; }
			else if ( i<50000 ) { a='E'; }
			else if ( i<60000 ) { a='F'; }
			else if ( i<70000 ) { a='G'; }
			else if ( i<80000 ) { a='H'; }
			else if ( i<90000 ) { a='I'; }
			else if ( i<100000 ) { a='J'; }
			else { a='Z'; }
			
			snprintf(buf, 31, "%c%c%c%s%05d", a, a, a, s, i);
			
			//snprintf(data[i].gid, 31, "%s", buf);
			//data[i].tm = time(NULL);
			
			snprintf(data.gid, 31, "%s", buf);

			data.tm = time(NULL);
			/*
			printf("Insert  [%s]-[%lu]\n", data[i].gid, data[i].tm);
			*/

			TRANM_MUTEX_LOCK(mlock);
			if ( crc_smap_push_array(smap, &data) == 0 )
			{
				//smap_using_count++;
				(*p_using_count)++;
			}
			TRANM_MUTEX_UNLOCK(mlock);
			fflush(stdout);
			usleep(500000);
		}
	}

	printf("S_ADDR:%p,  E_ADDR:%p, map_size(%d)\n", &map, map.map, sizeof(map));

	crc_smap_print_all();

	
	return 0;
}
