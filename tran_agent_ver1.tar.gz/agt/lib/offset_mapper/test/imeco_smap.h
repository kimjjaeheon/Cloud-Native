#ifndef __IMECO_SMAP_H__
#define __IMECO_SMAP_H__

#include "crc_smap.h"

struct _st_data
{
	char gid[30+1];
	time_t tm;
};

unsigned int* p_using_count;
struct _st_data* smap;

#if 0
struct _st_smap_list
{
	unsigned int using_count;
	struct _st_data* smap;
}

struct _st_smap_list* smap_list;
#endif

//#define MAP_SIZE (USHRT_MAX * sizeof(struct _st_data) * 10)
#define MAP_SIZE (sizeof(unsigned int) + (USHRT_MAX * sizeof(struct _st_data) * 10))
#define DATA_SIZE (sizeof(struct _st_data))

/*
struct _st_data smap[(USHRT_MAX+1)*10];
*/

unsigned int smap_timeout_check();

#endif
