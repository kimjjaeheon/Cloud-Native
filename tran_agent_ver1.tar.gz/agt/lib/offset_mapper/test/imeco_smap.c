#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

#include "imeco_smap.h"
#include "crc_smap.h"

int  smap_clear_tm=120, smap_clear_interval=60;

unsigned int smap_timeout_clear();

unsigned int smap_timeout_check()
{
	static time_t tm = 0;
	
	if ( !tm ) { tm = time(NULL); }

	if ( (time(NULL) - tm) > smap_clear_interval )
	{
		tm = time(NULL);
		return smap_timeout_clear();
	}	

	return 0;
}

unsigned int smap_timeout_clear()
{
	void *p          = NULL;

	uint32_t idx     = 0;
	uint32_t sub_idx = 0;

	int clear_count  = 0;

	uint32_t data_size = DATA_SIZE;

	for( idx=0; idx<crc_smap_get_size(); idx++ )
	{
		p =  smap + (MAX_SUB_ARRAY*idx); 
		fprintf(stdout, "--- smap_addr: %p-%p,  idx: %d,  sub_idx: %d,  data_size:%d,  sum:%d,  ?->%p\n", smap, p, idx, sub_idx, data_size, data_size*MAX_SUB_ARRAY*idx, smap+(400));
		for ( sub_idx=0; sub_idx<MAX_SUB_ARRAY; sub_idx++ )
		{
			p +=  (data_size*sub_idx);
			fprintf(stdout, "   === [%6u-%6u] cur_tm:%lu,  tm:%lu\n", idx, sub_idx, time(NULL), ((struct _st_data*)p)->tm);
			if( ((struct _st_data*)p)->tm &&  time(NULL)-((struct _st_data*)p)->tm > smap_clear_tm )
			{
				memset(p, 0x00, DATA_SIZE);
				clear_count++;
			}
		}
	}

	return clear_count;	
}
