#ifndef __LI_COMMON_ERRCD_H__
#define __LI_COMMON_ERRCD_H__

int mapper_errcd;

/* COMMON RESULT CODE */
#define LI_RET_SUCCESS         1
#define LI_RET_FAIL            0
#define LI_RET_ERROR          -1 

#define LI_UTIL_ERROR          1000
#define LI_UTIL_ERROR          1000

/* STL(String Token Loader) error code (1000~1099) */
#define STL_RET_SUCCESS        LI_RET_SUCCESS
#define STL_RET_FAIL           LI_RET_FAIL

/* 100x : STL logic error */
#define ERR_STL_NO_DATA           LI_UTIL_ERROR + 1     /* config 에서 로딩된 데이터가 없다 */
#define ERR_STL_TOKEN_FAIL        LI_UTIL_ERROR + 2     /* */
#define ERR_STL_INDEX_RANGE_ERROR LI_UTIL_ERROR + 3     /* */

/* 101x : file error */
#define ERR_STL_FOPEN_FAIL        LI_UTIL_ERROR + 10    /* config file open fail */
#define ERR_STL_FP_IS_NULL        LI_UTIL_ERROR + 11    /* fopen fail. file point is null. */
#define ERR_STL_BUFF_IS_NULL      LI_UTIL_ERROR + 12    /* file read buff is null */
#define ERR_STL_FREAD_FAIL        LI_UTIL_ERROR + 13    /* file read fail. (fread fail) */
#define ERR_STL_BUFFER_OVERFLOW   LI_UTIL_ERROR + 14    /* file 에서 read한 데이터가 버퍼 사이즈보다 크다 */
#define ERR_STL_ARG_NULL          LI_UTIL_ERROR + 15    /* 필수 argument 누락 */


/* 109x : memory error */
#define ERR_STL_ALLOC_FAIL        LI_UTIL_ERROR + 91     /* malloc fail */
#define ERR_STL_INIT_ALLOC_FAIL   LI_UTIL_ERROR + 92     /* init 시점 malloc fail */
#define ERR_STL_PUSH_ALLOC_FAIL   LI_UTIL_ERROR + 93     /* push 시점 malloc fail */
/* STL(String Token Loader) error code END */



/* CRC MAP error code (1100~1199) */
#define CMAP_RET_SUCCESS           LI_RET_SUCCESS
#define CMAP_RET_FAIL              LI_RET_FAIL
#define CMAP_RET_ERROR             LI_RET_ERROR

/* 11xx : CRC MAP logic error code */
#define ERR_CMAP_ARR_SIZE_ERROR    LI_UTIL_ERROR + 100   /* arrary size 오류 */
#define ERR_CMAP_CRC_RANGE_ERROR   LI_UTIL_ERROR + 101   /* crc 값 오류. array index 범위 초과 값 */
#define ERR_CMAP_ARG_NULL_ERROR    LI_UTIL_ERROR + 102   /* argument 누락 */
#define ERR_CMAP_KEY_VALUE_ERROR   LI_UTIL_ERROR + 103   /* */
#define ERR_CMAP_MAP_IS_EMPTY      LI_UTIL_ERROR + 104   /* crc map 에 데이터가 존재 하지 않는다 */
#define ERR_CMAP_EMPTY_INDEX       LI_UTIL_ERROR + 106   /* */
#define ERR_CMAP_KEY_NOT_FOUND     LI_UTIL_ERROR + 107   /* crc map 찾고자 하는 key 가 없다 */
#define ERR_CMAP_DATA_MSMATCH      LI_UTIL_ERROR + 108   /* */
#define ERR_CMAP_NOT_SUPPORT       LI_UTIL_ERROR + 109   /* */
#define ERR_CMAP_DATA_SIZE_ERROR   LI_UTIL_ERROR + 110
#define ERR_CMAP_COMP_SIZE_ERROR   LI_UTIL_ERROR + 111
#define ERR_CMAP_CMP_KEY_TOO_BIG   LI_UTIL_ERROR + 112
#define ERR_CMAP_KEY_EXIST         LI_UTIL_ERROR + 113
#define ERR_CMAP_STATIC_MAP_IS_NULL LI_UTIL_ERROR + 114

/* 112x : memory error */
#define ERR_CMAP_ALLOC_FAIL          LI_UTIL_ERROR + 120 /* malloc fail */
#define ERR_CMAP_MAP_ALLOC_FAIL      LI_UTIL_ERROR + 121 /* crc map 생성시점 malloc fail */
#define ERR_CMAP_SUB_MAP_ALLOC_FAIL  LI_UTIL_ERROR + 122 /* crc map sub 생성시점 malloc fail */
#define ERR_CMAP_COUNTING_ALLOC_FAIL LI_UTIL_ERROR + 123 /* crc map index별 data 수 생성시점  malloc fail */
#define ERR_CMAP_KEY_ALLOC_FAIL      LI_UTIL_ERROR + 124 /* key 생성시점 malloc fail */
#define ERR_CMAP_DATA_ALLOC_FAIL     LI_UTIL_ERROR + 125 /* data 생성시점 malloc fail */


/* OFFSET MAPPER error code (1200~1299) */
#define OMAPPER_RET_SUCCESS           LI_RET_SUCCESS
#define OMAPPER_RET_FAIL              LI_RET_FAIL
#define OMAPPER_RET_ERROR             LI_RET_ERROR
/* 12xx : CRC MAP logic error code */
#define ERR_OMAPPER_NULL_PATH            LI_UTIL_ERROR + 220 /* file path 가 null 이다. */
#define ERR_OMAPPER_NULL_TYPE            LI_UTIL_ERROR + 221 /* type 이 null 이다. */
#define ERR_OMAPPER_NULL_AP_TYPE         LI_UTIL_ERROR + 222 /* ap_type 가 null 이다. */
#define ERR_OMAPPER_NULL_DATA            LI_UTIL_ERROR + 223 /* data가 null 이다. */
#define ERR_OMAPPER_NULL_KEY             LI_UTIL_ERROR + 224 /* key가 null 이다. */
#define ERR_OMAPPER_NOT_SUPPORT_AP_TYPE  LI_UTIL_ERROR + 225 /* 지원하지 않는 AP_TYPE 이다 */
#define ERR_OMAPPER_NO_START_OFFSET      LI_UTIL_ERROR + 225 /* 시작 offset 이 존재 하지 않는다. */
#define ERR_OMAPPER_DATA_LEN_ERROR       LI_UTIL_ERROR + 226 /* data 길이가 key를 찾기 위한 최소 길이보다 작다 */
#define ERR_OMAPPER_NO_COMMON_OFFSET     LI_UTIL_ERROR + 227 /* common offset 정보가 존재 하지 않느다.  */


#endif
