#ifndef __STR_LOADER_H__
#define __STR_LOADER_H__
/* int tran_create_token(const char* file); */
int tran_create_token(const char* file, const char* delimeter);
void tran_destroy_token(void);
char* tran_get_token_string(const int idx, const int nth);

int tran_get_string_line_count();
int tran_get_string_token_count(const int idx);
int trna_get_string_array_size(void);

#endif
