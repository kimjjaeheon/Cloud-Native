#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#include "li_common_errcd.h"
#include "str_util.h"

/* DEFINE */
#define TRAN_TYPE_LINE 0
#define TRAN_TYPE_LOAD 1

#define TRAN_MAX_STRING_LEN 512
#define TRAN_MAX_TOT_TOKEN_LEN 256
#define TRAN_MAX_TOKEN_CNT 20
#define TRAN_TOKEN_DELIMETER ",-"

#define TRAN_MAX_NTH_VALUE 128

#define TRAN_MAX_DELIMETER_CNT 10

static char user_delimeter[TRAN_MAX_DELIMETER_CNT+1];
static char *token_delimeter;

struct _st_nth_value
{
	char nth_value[TRAN_MAX_NTH_VALUE];
};

/* sturct */
struct _st_token
{
	char cnt;
	struct *_st_nth_value;
	char *value;
};

struct _st_token_list
{
	int count;
	int max;

	struct _st_token* token;
};

/* global */
static struct _st_token_list st_token_list;


/* function */
static void *tran_fopen(const char* file, const char* mode)
{
	if ( !file || !mode )
	{
		return NULL;
	}
	return (void*)fopen(file, mode);
}

static int tran_fread(void* fp, char* buff)
{
	int read_cnt=0;

	if ( !fp )
	{
		mapper_errcd=ERR_STL_FP_IS_NULL;
		return -1;
	}
	if ( !buff)
	{
		mapper_errcd=ERR_STL_BUFF_IS_NULL;
		return -1;
	}

	while ( !feof(fp) && read_cnt < TRAN_MAX_STRING_LEN )
	{
		if ( fread(&buff[read_cnt], 1, 1, fp) <= 0 )
		{
			mapper_errcd=ERR_STL_FREAD_FAIL;
			return -1;
		}

		if ( buff[read_cnt] == '\n' || buff[read_cnt] == 0x00 )
		{
			return STL_RET_SUCCESS;
		}
		read_cnt++;
	}

	if ( read_cnt >= TRAN_MAX_STRING_LEN )
	{
		while ( !feof(fp) )
		{
			char tmp;
			if ( fread(&tmp, 1, 1, fp) <= 0 )
			{
				mapper_errcd=ERR_STL_FREAD_FAIL;
				return -1;
			}
			if ( tmp  == '\n' || tmp == 0x00 )
			{
				break;;
			}
		}
	}

	mapper_errcd=ERR_STL_BUFFER_OVERFLOW;
	return -1;
}

static int tran_init_token(const int line_cnt)
{
	if ( line_cnt <= 0 )
	{
		fprintf(stderr, "<Err> init fail. line_cnt(%d)\n", line_cnt);
		mapper_errcd=ERR_STL_NO_DATA;
		return -1;
	}

	memset(&st_token_list, 0x00, sizeof(struct _st_token_list));

	st_token_list.token = malloc(sizeof(struct _st_token)*line_cnt);

	if ( !st_token_list.token )
	{
		fprintf(stderr, "<Err> %s fail.(alloc fail)\n", __FUNCTION__);
		mapper_errcd=ERR_STL_INIT_ALLOC_FAIL;
		return -1;
	}

	st_token_list.max = line_cnt;
	memset(st_token_list.token, 0x00, sizeof(struct _st_token_list*)*line_cnt);

	fprintf(stdout, "<Init> Success. (line_cnt:%d)\n", st_token_list.max);

	return STL_RET_SUCCESS;
}

void tran_destroy_token(void)
{
	int cnt;

#ifdef _DEBUG
	int tot_cnt = st_token_list.max;
#endif

	if ( st_token_list.token )
	{
		for ( cnt=0; cnt<st_token_list.max; cnt++ )
		{
			if ( st_token_list.token[cnt].value )
			{
				free(st_token_list.token[cnt].value);
				st_token_list.token[cnt].value = NULL;
			}
		}
		free(st_token_list.token);
		st_token_list.token = NULL;
	}
#ifdef _DEBUG
	fprintf(stdout, "clear token list. [Total:%d], [Clear:%d]\n", tot_cnt, cnt);
#endif
}

static int tran_push_string(char* buff)
{
	int token_cnt=0;
	int offset=0;
	int len=0;
	char *p;

	if ( !buff )
	{
		mapper_errcd=ERR_STL_BUFF_IS_NULL;
		return -1;
	}

	st_token_list.token[st_token_list.count].value = malloc(sizeof(char)*TRAN_MAX_TOT_TOKEN_LEN);

	if ( !st_token_list.token[st_token_list.count].value )
	{
		fprintf(stderr, "<Err> %s fail. (alloc fail)\n");
		tran_destroy_token();
		mapper_errcd=ERR_STL_PUSH_ALLOC_FAIL;
		return -1;
	}

	memset(st_token_list.token[st_token_list.count].value, 0x00, sizeof(char)*TRAN_MAX_TOT_TOKEN_LEN);

	len = strlen(buff);

	memcpy(st_token_list.token[st_token_list.count].value, buff, len);

	if ( !(token_cnt=tran_str_n_token_single(st_token_list.token[st_token_list.count].value, token_delimeter, st_token_list.token[st_token_list.count].nth_value, TRAN_MAX_TOKEN_CNT)) )
	{
		mapper_errcd=ERR_STL_TOKEN_FAIL;
		return -1;
	}

	st_token_list.token[st_token_list.count].cnt = token_cnt;



#ifdef _CFG_DEBUG
	fprintf(stdout, "<PUSH> [%03d] %3.3s,  %11.11s,  %5.5s,  %s-%s,  %s-%s,  %s-%s,  %s-%s\n"
				, token_cnt
				, st_token_list.token[st_token_list.count].nth_value[0]
				, st_token_list.token[st_token_list.count].nth_value[1]
				, st_token_list.token[st_token_list.count].nth_value[2]
				, st_token_list.token[st_token_list.count].nth_value[3]
				, st_token_list.token[st_token_list.count].nth_value[4]
				, st_token_list.token[st_token_list.count].nth_value[5]
				, st_token_list.token[st_token_list.count].nth_value[6]
				, st_token_list.token[st_token_list.count].nth_value[7]
				, st_token_list.token[st_token_list.count].nth_value[8]
				, st_token_list.token[st_token_list.count].nth_value[9]
				, st_token_list.token[st_token_list.count].nth_value[10]
		   );
#endif
	st_token_list.count++;
	
	return STL_RET_SUCCESS;
}

char* tran_get_token_string(const int idx, const int nth)
{
	if ( !st_token_list.count )
	{
		return NULL;
	}

	if ( idx > st_token_list.count || nth >= st_token_list.token[idx].cnt )
	{
		fprintf(stderr, "<ERR_GET_STR> idx:%d(%d),  nth:%d(%d)\n", idx, st_token_list.count, nth, st_token_list.token[idx].cnt);
		return NULL;
	}
	return st_token_list.token[idx].nth_value[nth];
}

int tran_get_string_line_count()
{
	return st_token_list.count;
}

int tran_get_string_array_size(void)
{
	return st_token_list.max;
}

int tran_get_string_token_count(const int idx)
{
	if ( idx < 0 || idx > st_token_list.count )
	{
		mapper_errcd = ERR_STL_INDEX_RANGE_ERROR;
		return -1;
	}
	return st_token_list.token[idx].cnt;
}

static int tran_load_token(FILE* fp)
{
	char buff[256];
	int line_cnt = 0;

	static int type = TRAN_TYPE_LINE;

	if ( !fp )
	{
		mapper_errcd=ERR_STL_FP_IS_NULL;
		return -1;
	}

LOAD:
	while ( !feof(fp) )
	{
		memset(buff, 0x00, sizeof(buff));

		/* file read */
		if ( tran_fread(fp, buff) != -1 )
		{
			/* comment check */
			if ( tran_is_comment(buff) )
			{
				continue;
			}

			/* trim */
			tran_a_trim(buff);

			if ( !strlen(buff) )
			{
				continue;
			}

			switch( type )
			{
				case TRAN_TYPE_LINE: line_cnt++; break;
				case TRAN_TYPE_LOAD: tran_push_string(buff); break;
				default : break;
			}
		}
		else
		{
			continue;
		}
	}

	if ( type == TRAN_TYPE_LINE )
	{
		if ( tran_init_token(line_cnt) < 0 )
		{
			return -1;
		}
		(void)fseek(fp, 0L, SEEK_SET);
		type = TRAN_TYPE_LOAD;
		goto LOAD;
	}

	return STL_RET_SUCCESS;
}

int tran_create_token(const char* file, const char* delimeter)
{
	FILE* fp = NULL;

	if ( !file )
	{
		fprintf(stderr, "Argument is null. [file is null]\n");
		mapper_errcd=ERR_STL_ARG_NULL;
		return -1;
	}

	if ( delimeter )
	{
		if ( delimeter[0] )
		{
			memcpy(user_delimeter, delimeter, strlen(delimeter)>TRAN_MAX_DELIMETER_CNT ? TRAN_MAX_DELIMETER_CNT:strlen(delimeter));
			token_delimeter = user_delimeter;
		}
		else
		{
			token_delimeter = TRAN_TOKEN_DELIMETER;
		}
	}
	else
	{
		token_delimeter = TRAN_TOKEN_DELIMETER;
	}

	if ( !(fp=tran_fopen(file, "r")) )
	{
		fprintf(stderr, "Config open fail. [file:%s] [errno:%d]\n", file, errno);
		mapper_errcd=ERR_STL_FOPEN_FAIL;
		return -1;
	}

	if ( tran_load_token(fp) < 0 )
	{
		return -1;
	}

	fclose(fp);

	return STL_RET_SUCCESS;
}

void tran_string_print_all(void)
{
	int i = 0;
	int x = 0;


	fprintf(stdout, "=============== STR ARRAY INFO ===============\n");
	for ( i=0; i<tran_get_string_line_count() ; i++)
	{
		printf("<GET> [%5d]", i);
		for ( x=0; x<tran_get_string_token_count(i); x++)
		{
			printf(" %5s", tran_get_token_string(i, x));
		}
		printf("\n");
	}

	printf("STR ARRAY USING COUNT :%d/%d\n", tran_get_string_line_count(),tran_get_string_array_size());

	return;
}


/*
 * SAMPLE
 */
#ifdef _MAIN
int main(int argc, char** argv)
{
	int i;
#if 0
	const char* file= "/sw/shinvest/agt/src/liandli/cfg_loader/TRAN_FEP_KRX.cfg";
#else
	const char* file= "/sw/shinvest/agt/lib/offset_mapper/string_loader/sample.cfg";
#endif

	fprintf(stdout, "===== SAMPLE START =====\n");

	tran_create_token(file, NULL);

	fprintf(stdout, "Loaded Line count : %d\n", st_token_list.count);
#if 0
	for( i=0; i<st_token_list.count; i++ )
	{
		fprintf(stdout, "[%03d] %3.3s,  %11.11s,  %s-%s,  %s-%s,  %s-%s\n"
					, i
					, tran_get_token_string(i, 0)
					, tran_get_token_string(i, 1)
					, tran_get_token_string(i, 2)
					, tran_get_token_string(i, 3)
					, tran_get_token_string(i, 4)
					, tran_get_token_string(i, 5)
					, tran_get_token_string(i, 6)
					, tran_get_token_string(i, 7)
			   );
	}
#else
	char *p;
	for ( i=0; i<st_token_list.count; i++ )
	{
		int j = 0;
		fprintf(stdout, "[%03d] ", i);
		while ( (p=tran_get_token_string(i, j++)) )
		{
			fprintf(stdout, " %s,", p);
		}
		fprintf(stdout, "\n");
	}
#endif

	tran_destroy_token();
	fprintf(stdout, "===== SAMPLE END =====\n");

	return 0;
}
#endif
