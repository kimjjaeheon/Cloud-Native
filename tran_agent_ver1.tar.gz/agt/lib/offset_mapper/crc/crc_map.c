#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "li_common_errcd.h"
/*
#include "string_loader.h"
*/
#include "checksum.h"
#include "crc_map.h"

#if 0
/* MAX array */
#define CRC8_MAX  UCHAR_MAX + 1
#define CRC16_MAX USHRT_MAX + 1
#define CRC32_MAX UINT_MAX + 1

#define MAX_KEY_LEN 64
#define MAX_SUB_ARRAY 10
#endif


/*****************
* CRC Map struct *
*****************/
struct _st_crc_map
{
	char *key;
	void *data;
	struct _st_crc_map* next;
};

/***************
* CRC Map data *
***************/
static struct _st_crc_map *st_crc_map;

/***************
* CRC Map size *
***************/
/* Map Size    */
static unsigned long int g_crc_map_size;
/* Using Count */
static char *g_crc_map_using_count;

/*******************
* Create & Destory *
*******************/
/*
int          crc_map_create_array (const int array_size);
void         crc_map_destroy_array(void);
*/

/*****************
* Insert Funtion *
******************/
/* Insert to map*/
/*
int          crc_map_push_array(const int crc, const char* key, const void* data, const int data_len);
*/

/*********
* Getter *
**********/
/* search data from map */
void*        crc_map_search_data(const char *key, const int key_len);
/* get index of map      */
static int crc_map_get_index  (const char* key, const int key_len, long int* crc);


/*
 * CRC_MAP 생성
 */
int crc_map_create_array(const int array_size)
{
	cmap_errno = CMAP_RET_SUCCESS;

	if (   array_size != CRC8_MAX 
		&& array_size != CRC16_MAX 
		&& array_size != CRC32_MAX )
	{
		mapper_errcd = ERR_CMAP_ARR_SIZE_ERROR;
		return -1;
	}
#ifdef _CRC_DEBUG
	fprintf(stdout, "<DEV> CRC8_MAX   : %ld\n", CRC8_MAX);
	fprintf(stdout, "<DEV> CRC16_MAX  : %ld\n", CRC16_MAX);
	fprintf(stdout, "<DEV> CRC32_MAX  : %lld\n", CRC32_MAX);
#endif

	if ( !(st_crc_map = calloc(array_size+1, sizeof(struct _st_crc_map))) )
	{
		mapper_errcd = ERR_CMAP_MAP_ALLOC_FAIL;
		return -1;
	}

	if ( !(g_crc_map_using_count = calloc(array_size+1, sizeof(char))) )
	{
		free(st_crc_map);
		mapper_errcd = ERR_CMAP_COUNTING_ALLOC_FAIL;
		return -1;
	}

	g_crc_map_size = array_size+1;
	/*
	st_crc_map = malloc(array_size*sizeof(struct _st_crc_map));
	memset(st_crc_map, 0x00, array_size*sizeof(struct _st_crc_map));
	*/
	return CMAP_RET_SUCCESS;
}

/*
 * CRC MAP 에 데이터 복사
 */
int crc_map_push_array(const long int crc, const char* key, const void* data, const int data_len)
{
	int i=0;
	int key_len = 0;

	struct _st_crc_map *pst;

	/* argument check */
	if ( crc < 0 || crc > crc_map_get_size()-1 ) { mapper_errcd = ERR_CMAP_CRC_RANGE_ERROR; return -1;}
	if ( !key || !data )                         { mapper_errcd = ERR_CMAP_ARG_NULL_ERROR ; return -1;}
	if ( (key_len=strlen(key)) > MAX_KEY_LEN )   { mapper_errcd = ERR_CMAP_KEY_VALUE_ERROR; return -1;}
	/* argument check end */

	pst = &st_crc_map[crc];

	/* */
	for ( i=0; i<MAX_SUB_ARRAY; i++ )
	{
		/* not use array */
		if ( !pst->key )
		{
			if ( !(pst->key = malloc(key_len+1)) ) { mapper_errcd =  ERR_CMAP_KEY_ALLOC_FAIL; return -1;}
			if ( !(pst->data = malloc(data_len)) ) 
			{
				free(pst->key);
				pst->key = NULL;
				mapper_errcd = ERR_CMAP_DATA_ALLOC_FAIL; 
				return -1;
			}
			memset(pst->key, 0x00, key_len+1);
			memcpy(pst->key, key, key_len);
			memcpy(pst->data, data, data_len);
			g_crc_map_using_count[crc] += 1;
#ifndef _CRC_MAP_DEBUG
			printf("<PUSH> [%5lld]-[%p:%s]\n", crc, pst->key, pst->key);
#endif
			return CMAP_RET_SUCCESS;
		}
		/* using array */
		else
		{
			/* key mismatch     */
			/* sub arrary check */
			if ( !(pst->next) )
			{
				if ( !(pst->next = calloc(1, sizeof(struct _st_crc_map))) ) { mapper_errcd = ERR_CMAP_SUB_MAP_ALLOC_FAIL; return -1;}
				pst = pst->next;
#ifndef _CRC_MAP_DEBUG
				printf("<SUB>-");
#endif
			}
		}
	}

	return 0;
}

/*
 * CRC MAP 의 array 크기
 */
long int crc_map_get_size(void)
{
	return g_crc_map_size;
}

/*
 * Key값을 가지고 있는 CRC MAP의 INDEX 검색 (crc_map_get_index 를 호출 하여 추출)
 */
long int crc_map_search_key(const char *key, const int key_len)
{
	long int crc = -1;

	if ( !key || key_len <= 0 )
	{
		cmap_errno=ERR_CMAP_KEY_VALUE_ERROR;
		return -1;
	}

	if ( crc_map_get_index(key, key_len, &crc) != CMAP_RET_SUCCESS )
	{
		return -1;
	}
	return crc;
}

/*
 * Key값을 가지고 있는 CRC MAP의 DATA 검색
 */
void* crc_map_search_data(const char *key, const int key_len)
{
	long int crc = -1;

	if ( !key || key_len <= 0 || !g_crc_map_using_count )
	{
		cmap_errno=ERR_CMAP_KEY_VALUE_ERROR;
		return NULL;
	}
	
	if ( crc_map_get_index(key, key_len, &crc) != CMAP_RET_SUCCESS )
	{
		return NULL;
	}

	return st_crc_map[crc].data;
}

/*
 * Key값을 가지고 있는 CRC MAP의 INDEX 검색 (CRC MAP 에서 추출)
static long int crc_map_get_index(const char* key, const int key_len, long int* crc)
 */
static int crc_map_get_index(const char* key, const int key_len, long int* crc)
{
	struct _st_crc_map *pst;

	int idx;

	if ( !key || key_len <= 0 )
	{
		mapper_errcd = CMAP_RET_ERROR;
		return -1;
	}

	if ( !g_crc_map_using_count )
	{
		mapper_errcd = ERR_CMAP_MAP_IS_EMPTY;
		return -1;
	}

	switch (g_crc_map_size-1)
	{
		case CRC8_MAX  : *crc = crc_8(key, key_len); break;
		case CRC16_MAX : *crc = crc_16(key, key_len); break;
		case CRC32_MAX : *crc = crc_32(key, key_len); break;
		default : mapper_errcd = ERR_CMAP_NOT_SUPPORT; return -1;
	}

	if ( *crc < 0 || *crc > g_crc_map_size-1 )
	{
		mapper_errcd = ERR_CMAP_CRC_RANGE_ERROR;
		return -1;
	}

	pst = &st_crc_map[*crc];

	if ( !(pst->key) )
	{
		mapper_errcd = ERR_CMAP_KEY_NOT_FOUND;
		return -1;
	}

	for ( idx=0; idx<MAX_SUB_ARRAY; idx++ )
	{
		if ( !pst )
		{
			mapper_errcd = ERR_CMAP_KEY_NOT_FOUND;
			return -1;
		}
		
		if ( strlen(pst->key) != key_len )
		{
			if ( !(pst=pst->next) )
			{
				mapper_errcd = ERR_CMAP_KEY_NOT_FOUND;
				return -1;
			}
			continue;
		}

		if ( strcmp(pst->key, key) )
		{
			if ( !(pst=pst->next) )
			{
				mapper_errcd = ERR_CMAP_KEY_NOT_FOUND;
				return -1;
			}
			continue;
		}
		break;
	}

	return CMAP_RET_SUCCESS;
}

/*
 * CRC_MAP 자원회수 
 */
void crc_map_destroy_array()
{
	int i;

	struct _st_crc_map *pst;
	struct _st_crc_map *cur;

	for ( i=0; i<crc_map_get_size(); i++ )
	{
		pst = &st_crc_map[i];
		if ( pst->key ) { free(pst->key); }
		if ( pst->data ) { free(pst->data); }
		for ( ; pst->next!=NULL; pst=pst->next )
		{
		}
	}

}

/*
 * CRC_MAP에 insert 된 데이터 출력
 */
void crc_map_print_all(void)
{
	int i=0;
    int x=0;
	/*
	short *dup_cnt = malloc(sizeof(short)*crc_map_get_size());
	*/
	short dup_cnt;
	unsigned long int using_count = 0;

	fprintf(stdout, "=============== CRC MAP INFO ===============\n");
    for ( i=0; i<crc_map_get_size(); i++ )
    {
		dup_cnt = 0;
        struct _st_crc_map *pst = &st_crc_map[i];
        if ( pst->key )
        {
			using_count += g_crc_map_using_count[i];
            printf("<GET> [%5d]-[using:%2d]-[%p]", i, g_crc_map_using_count[i], pst->key);
            printf(" %s", pst->key);
            for ( ;  pst->next!= NULL; pst=pst->next)
            {
                printf(", %s", pst->next->key);
            }
            printf("\n");
        }
    }
	printf("CRC MAP USING COUNT :%d/%d\n", using_count,crc_map_get_size()*10);

}
