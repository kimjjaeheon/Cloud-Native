#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "li_common_errcd.h"
#include "checksum.h"
#include "crc_smap.h"

#if 0
/* MAX array */
#define CRC8_MAX  UCHAR_MAX
#define CRC16_MAX USHRT_MAX
#define CRC32_MAX UINT_MAX

#define MAX_KEY_LEN 64
#define MAX_SUB_ARRAY 10
#endif

#define MAX_DATA_SIZE 1024

static void* g_crc_smap;

/***************
* CRC Map size *
***************/
/* Map Size    */
static unsigned long int g_crc_smap_size;
/* Using Count */
static unsigned int g_crc_smap_using_count;
/* Data Size   */
static unsigned int g_crc_smap_data_size;
/* Compare Size*/
static unsigned int g_crc_smap_cmp_size;

/*******************
* function         *
*******************/
int crc_smap_search(uint32_t crc, void* data);

/*
 * CRC_MAP 생성
 */
int crc_smap_create_array(const int array_size, int data_size, void* ptr, int cmp_size)
{
	if (   array_size != CRC8_MAX 
		&& array_size != CRC16_MAX 
		&& array_size != CRC32_MAX )
	{
		mapper_errcd = ERR_CMAP_ARR_SIZE_ERROR;
		return -1;
	}

	if ( data_size <= 0 || data_size > MAX_DATA_SIZE )
	{
		mapper_errcd = ERR_CMAP_DATA_SIZE_ERROR;
		return -1;
	}

	if ( !ptr )
	{
		mapper_errcd = ERR_CMAP_MAP_IS_EMPTY;
		return -1;
	}

	if ( cmp_size <= 0 ||  cmp_size > data_size )
	{
#ifdef _CRC_DEBUG
		fprintf(stdout, "<DEV> cmp_size:%d (data_size:%d)\n", cmp_size, data_size);
#endif
		mapper_errcd = ERR_CMAP_COMP_SIZE_ERROR;
		return -1;
	}

#ifdef _CRC_DEBUG
	fprintf(stdout, "<DEV> CRC8_MAX   : %ld\n", CRC8_MAX);
	fprintf(stdout, "<DEV> CRC16_MAX  : %ld\n", CRC16_MAX);
	fprintf(stdout, "<DEV> CRC32_MAX  : %lld\n", CRC32_MAX);
#endif

	g_crc_smap_size      = array_size+1;
	g_crc_smap_data_size = data_size;
	g_crc_smap_cmp_size  = cmp_size;

	g_crc_smap = ptr;


	return CMAP_RET_SUCCESS;
}

/*
 * CRC SMAP 에 데이터 복사
 */
int crc_smap_push_array(void* map, void* data)
{
	int sub_idx   = 0;
	int key_len   = 0;

	uint32_t crc  = 0;

	char *p = (char*)map;
	/*
	uint8_t  crc8;
	uint16_t crc16;
	uint32_t crc32;
	*/

	/* argument check */
	if ( !map )
	{
		mapper_errcd = ERR_CMAP_STATIC_MAP_IS_NULL;
		return -1;
	}

	if ( !data )
	{
		mapper_errcd = ERR_CMAP_MAP_IS_EMPTY;
		return -1;
	}
	/* argument check end */

	/* validation */
	switch ( g_crc_smap_size-1 )
	{
		case CRC8_MAX  : crc = (uint32_t)crc_8 ((const unsigned char*)data, g_crc_smap_cmp_size); break;
		case CRC16_MAX : crc = (uint32_t)crc_16((const unsigned char*)data, g_crc_smap_cmp_size); break;
		case CRC32_MAX : crc = (uint32_t)crc_32((const unsigned char*)data, g_crc_smap_cmp_size); break;
		default : mapper_errcd = ERR_CMAP_NOT_SUPPORT; return -1;
	}

	if ( crc < 0 || crc > g_crc_smap_size-1 ) { mapper_errcd = ERR_CMAP_CRC_RANGE_ERROR; return -1;}
	/* validation end */

#ifdef _CRC_DEBUG
	fprintf(stdout, "<DEV> crc:%u, smap_size:%d, data[%*.*s]\n", crc, crc_smap_get_size(), g_crc_smap_cmp_size, g_crc_smap_cmp_size,(char*)data);
#endif

	if ( (sub_idx=crc_smap_search(crc, data)) < 0 )
	{
#ifdef _CRC_DEBUG
		fprintf(stdout, "<DEV> KEY ALREADY EXIST. [%*.*s]\n", g_crc_smap_cmp_size, g_crc_smap_cmp_size, data);
#endif
		mapper_errcd = ERR_CMAP_KEY_EXIST;
		return -1;
	}
	else
	{
		/*
		 * map                            = crc map start address
		 * (g_crc_smap_data_size*crc)     = Jump to array index
		 * (g_crc_smap_data_size*sub_idx) = Jump to sub array index
		 */
	
#ifdef _CRC_DEBUG
		fprintf(stdout, "<DEV> map_addr:%x, array_addr:%x  (data_size:%d, crc:%d, sub_dix:%d)\n"
				, g_crc_smap, g_crc_smap_data_size*crc*MAX_SUB_ARRAY
				, g_crc_smap_data_size, crc, sub_idx);
#endif
		memcpy(map + ( (g_crc_smap_data_size*MAX_SUB_ARRAY*crc)+(g_crc_smap_data_size*sub_idx) ), data, g_crc_smap_data_size);
	}

	return 0;
}

int crc_smap_search(uint32_t crc, void* data)
{
	int sub_idx = 0;
	void* p = NULL;

	int ret_idx = -1;

	for ( sub_idx=0; sub_idx<MAX_SUB_ARRAY; sub_idx++ )
	{
		/*
		 * g_crc_smap                               = crc map start address
		 * (g_crc_smap_data_size*MAX_SUB_ARRAY*crc) = Jump to array index
		 * (g_crc_smap_data_size*sub_idx)           = Jump to sub index
		 */
		p = g_crc_smap + (g_crc_smap_data_size*MAX_SUB_ARRAY*crc) + (g_crc_smap_data_size*sub_idx);
#if 0
#ifdef _CRC_DEBUG
	fprintf(stdout, "<DEV> sub_map_addr:%p-%p, (data_size:%d, crc:%d)\n", g_crc_smap, p, g_crc_smap_data_size, sub_idx);
#endif /* _CRC_DEBUG */
#endif
		if ( (*(char*)p) == 0x00 ) 
		{ 
			if ( ret_idx==-1 )
			{
				ret_idx=sub_idx;
			}
			continue; 
		}
		else
		{
			/* 다르면 다음 sub index 검색 */
			if ( memcmp(p, data, g_crc_smap_cmp_size) )
			{
				continue;
			}
			/* 같으면 sub index 리턴 */
			else
			{
				return -1;
			}
		}
	}

	return ret_idx;
}

/*
 * CRC MAP 의 array 크기
 */
uint32_t crc_smap_get_size(void)
{
	return g_crc_smap_size;
}

void crc_smap_destroy_array()
{
	return;
}

/*
 * CRC_MAP에 insert 된 데이터 출력
 */
void crc_smap_print_all(void)
{
	int count=0;
	int arr_idx, sub_idx;

	void *p;

	fprintf(stdout, "=============== CRC SMAP INFO ===============\n");
    for ( arr_idx=0; arr_idx<crc_smap_get_size(); arr_idx++ )
    {
		fprintf(stdout, "[%05d]-", arr_idx);
    	for ( sub_idx=0; sub_idx<MAX_SUB_ARRAY; sub_idx++ )
		{
			/*
			 * g_crc_smap                               = crc map start address
			 * (g_crc_smap_data_size*MAX_SUB_ARRAY*crc) = Jump to array index
			 * (g_crc_smap_data_size*sub_idx)           = Jump to sub index
			 */
			p = g_crc_smap + (g_crc_smap_data_size*MAX_SUB_ARRAY*arr_idx) + (g_crc_smap_data_size*sub_idx);
			if ( (*((char*)p)) == 0x00 )
			{
				fprintf(stdout, "[%02d]%*.*s ", sub_idx, g_crc_smap_cmp_size, g_crc_smap_cmp_size, "");
				continue;
			}
			fprintf(stdout, "[%02d]%*.*s ", sub_idx, g_crc_smap_cmp_size, g_crc_smap_cmp_size, (char*)p);
			count++;
		}
		fprintf(stdout, "\n");
    }
	printf("CRC SMAP USING COUNT :%d/%d\n",count, crc_smap_get_size()*10);

}
