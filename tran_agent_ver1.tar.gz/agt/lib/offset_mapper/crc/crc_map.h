#ifndef __CRC_MAP_H__
#define __CRC_MAP_H__

#include <limits.h>

/* MAX array */
#define CRC8_MAX  UCHAR_MAX
#define CRC16_MAX USHRT_MAX
#define CRC32_MAX UINT_MAX

#define MAX_KEY_LEN 64
#define MAX_SUB_ARRAY 10

int cmap_errno;


/*****************
* Insert Funtion *
******************/
/* Insert to map*/
int          crc_map_push_array(const long int crc, const char* key, const void* data, const int data_len);

/*********
* Getter *
**********/
/* search data from map */
void*    crc_map_search_data(const char *key, const int key_len);
/* search key from map  */
long int crc_map_search_key (const char *key, const int key_len);
/* get map size         */
long int crc_map_get_size(void);
/* get index of map      */
/*
static long int crc_map_get_index  (const char* key, const int key_len);
*/

int          crc_map_create_array (const int array_size);
void         crc_map_destroy_array(void);


/***********
* MAP Info *
************/
void crc_map_print_all(void);

#endif
