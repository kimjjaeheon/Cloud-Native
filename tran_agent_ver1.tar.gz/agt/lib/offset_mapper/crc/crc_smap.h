#ifndef __CRC_SMAP_H__
#define __CRC_SMAP_H__

#include <limits.h>

/* MAX array */
#define CRC8_MAX  UCHAR_MAX
#define CRC16_MAX USHRT_MAX
#define CRC32_MAX UINT_MAX

#define MAX_KEY_LEN 64
#define MAX_SUB_ARRAY 10

/*****************
* Insert Funtion *
******************/
/* Insert to map*/
int      crc_smap_push_array(void* map, void* data);

/*********
* Getter *
**********/
/* search data from map */
void*    crc_map_search_data(const char *key, const int key_len);
/* get smap size         */
uint32_t crc_smap_get_size(void);

int      crc_smap_create_array (const int array_size, int data_size, void* ptr, int cmp_size);
void     crc_smap_destroy_array(void);


/***********
* MAP Info *
************/
void crc_smap_print_all(void);

#endif
