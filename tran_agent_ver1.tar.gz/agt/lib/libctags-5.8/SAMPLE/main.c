
#include <stdio.h>
#include <string.h>
#include "init_ctags.h"

/*
void comment_function() {

}
*/

int test(argc, argv) 
int argc;
char** argv;
{
  return 0;
}

// void comment_function2() {
// 
// }

void iniparser_set_error_callback(int (*errback)(const char *, ...)) 
{

}

int 
main(int argc, char** argv) {

  int i = 1;

  init_ctags();

  for(; i<argc; ++i) 
  {
    make_ctags(argv[i]);

    // ------------------------------------------------------------
    int c = 0;
    fprintf(stderr, "%s: count=(%d)\n", argv[i], get_function_count());
    for (; c < get_function_count(); ++c) {
      st_tagInfo* p = get_function_info(c);
      fprintf(stderr, "%-30s %-10s %4lu %-16s %s\n", p->name,
              p->kindName, p->lineNumber,
              p->sourceFilename, p->source);
    }
    // ------------------------------------------------------------
    
  }

  free_ctags();

   
  return 0;
}



