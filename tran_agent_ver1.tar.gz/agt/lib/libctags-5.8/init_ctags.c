

#include "general.h"
#include "keyword.h"
#include "read.h"
#include "routines.h"
#include "options.h"

#include "init_ctags.h"

#include <string.h>

static cookedArgs* args;
static struct { long files, lines, bytes; } Totals = {0, 0, 0};

int tagInfoCount = 0;
st_tagInfo TagInfos[MAX_TAG_INFO];

boolean isDestinationStdout(void);
boolean createTagsForArgs(cookedArgs* const args);
boolean createTagsFromListFile(const char* const fileName);
boolean createTagsForEntry(const char* const entryName);
void makeTags(cookedArgs* args);

void addTotals(const unsigned int files,
               const long unsigned int lines,
               const long unsigned int bytes);

void init_ctags() {
  setCurrentDirectory();
  setExecutableName("penta_cc");
  initializeParsing();
}

void free_ctags() {
  freeKeywordTable();
  freeRoutineResources();
  freeSourceFileResources();
  freeTagFileResources();
  freeParserResources();
  freeRegexResources ();
}

void make_ctags(const char* filename) {
  
  char* argv[] = {
    "-x", "--c-types=f", (char*)filename, NULL
  };

  tagInfoCount = 0;

  args = cArgNewFromArgv(argv);
  previewFirstOption (args);
  
  initOptions();
  readOptionConfiguration();
  parseOptions(args);
  checkOptions();

  makeTags(args);
  cArgDelete(args);
  freeOptionResources();
}


void addTotals(const unsigned int files,
               const long unsigned int lines,
               const long unsigned int bytes) {
  // Totals.files += files;
  // Totals.lines += lines;
  // Totals.bytes += bytes;
}



boolean isDestinationStdout(void) {
  boolean toStdout = FALSE;

  if (Option.xref || Option.filter ||
      (Option.tagFileName != NULL &&
       (strcmp(Option.tagFileName, "-") == 0
#if defined(VMS)
        || strcmp(Option.tagFileName, "sys$output") == 0
#else
        || strcmp(Option.tagFileName, "/dev/stdout") == 0
#endif
        )))
    toStdout = TRUE;
  return toStdout;
}

void makeTags(cookedArgs* args) {
  boolean resize = FALSE;
  boolean files =
      (boolean)(!cArgOff(args) || Option.fileList != NULL || Option.filter);

  if (!files) {
    return;
  }

  if (!Option.filter)
    openTagFile();

  if (!cArgOff(args)) {
#ifdef _DEBUG
    printf("Reading command line arguments\n");
#endif
    resize = createTagsForArgs(args);
  }

  if (!Option.filter)
    closeTagFile(resize);
}

boolean createTagsForArgs(cookedArgs* const args) {
  boolean resize = FALSE;

  /*  Generate tags for each argument on the command line.
   */
  while (!cArgOff(args)) {
    const char* const arg = cArgItem(args);

#ifdef MANUAL_GLOBBING
    resize |= createTagsForWildcardArg(arg);
#else
    resize |= createTagsForEntry(arg);
#endif
    cArgForth(args);
    parseOptions(args);
  }
  return resize;
}

boolean createTagsForEntry(const char* const entryName) {
  boolean resize = FALSE;
  fileStatus* status = eStat(entryName);

  // Assert (entryName != NULL);
  if (isExcludedFile(entryName))
    verbose("excluding \"%s\"\n", entryName);
  else if (status->isSymbolicLink && !Option.followLinks)
    verbose("ignoring \"%s\" (symbolic link)\n", entryName);
  else if (!status->exists)
    error(WARNING | PERROR, "cannot open source file \"%s\"", entryName);
  else if (status->isDirectory) {
    // resize = recurseIntoDirectory (entryName);
  } else if (!status->isNormalFile)
    verbose("ignoring \"%s\" (special file)\n", entryName);
  else
    resize = parseFile(entryName);

  eStatFree(status);
  return resize;
}

int get_function_count() {
  return tagInfoCount;
}

st_tagInfo* get_function_info(int index) {
  return &TagInfos[index];
}

