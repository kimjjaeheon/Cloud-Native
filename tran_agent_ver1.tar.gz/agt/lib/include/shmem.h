#ifndef __shmem_h__
#define __shmem_h__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <signal.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>

#define SHMPERM		0666
#define SHM_IFLAGS 	(SHMPERM | IPC_CREAT | IPC_EXCL)

int create_shm(long shm_key, long shm_size, int *q_eexist);
int  remove_shm(int shm_id);
void *attach_shm(int shm_id);
int  detach_shm(void *shmptr);

#endif /*__shmem_h__*/
