#ifndef __TRNM_STR_UTIL__
#define __TRNM_STR_UTIL__

int tran_str_token(char* p_pattern_, const char* p_delimeter_, char** buf_);
int tran_str_n_token(char* p_pattern_, const char* p_delimeter_, char** buf_, int max_token_);
int tran_str_search(const char* src_, const char** dst_, const int dst_cnt_);

int tran_str_n_token_single(char* p_pattern_, const char* p_delimeter_, char** buf_, int max_token_);

/* trim function (using alloc) */
int tran_a_trim(char *buf);

#endif
