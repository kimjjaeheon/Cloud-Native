
#ifndef __USRUTIL_H__
#define __USRUTIL_H__

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#define FILETYPE_REG 1
#define FILETYPE_FILE FILE_TYPE_REG
#define FILETYPE_DIR 2
#define FILETYPE_ETC 3

// envstr to str 
// ex) $TRAN_HOME/agt -> /sw/tranm/agt
void env2str(char* src, char* outbuf, int len);

// 0:success, -1:fail
int makedir(char *dir, int if_file_del);

// 0:not exist, 1:file, 2:directory, 3:etc
int is_file_exist(char *file);

void  trim_right(char* str);
void  trim_left(char* str);
void  trim_all(char* str);

// need free
char* str_replace(char* org_str, const char* word, const char* rep_str);
int   str_split(char* src, const char* del, char** result, int max_count);
void  to_uppercase(char* src);
void  to_uppercase_copy(char* src, char* dst);
void  to_lowercase(char* src);
void  to_lowercase_copy(char* src, char* dst);
int   is_numstr(const char* str);

#define LOG_DEBUG(fp, fmt, ...) \
do { \
  fprintf(fp, fmt " [%s:%d]\n" \
    , ## __VA_ARGS__, __FILE__, __LINE__ ); \
} while(0)

#define ARRAY_COUNT(arr) (sizeof(arr)/sizeof(arr[0]))


#endif /* __USRUTIL_H__ */
