#ifndef __TRANM_QSORT_H__
#define __TRANM_QSORT_H__

int tranm_array_sort(void* data, int cnt, int size, int type, int *ptr_idx);
void *tranm_bsearch(const void *key, const void *base, int num, int size, int type, void *p);

#endif
