#ifndef __TRANM_SIGNAL_H__
#define __TRANM_SIGNAL_H__

void tran_thread_sig_ignore();

#endif
