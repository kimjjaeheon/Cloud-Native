#ifndef __hash_h__
#define __hash_h__

#include <stdio.h>
#include <sys/types.h>

u_int get_hidx(u_char *key, int len, int mask);
u_int get_hash_code(u_char *key, int len);

#endif /*__hash_h__*/
