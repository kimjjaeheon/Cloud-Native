#ifndef __tcp_base_h__
#define __tcp_base_h__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <errno.h>
#include <ctype.h>
#include <strings.h>

#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fcntl.h>
#include <unistd.h>


#define RECV_TIMEOUT	10 
#define TIMEOUT_ERR		-2
#define GENERAL_ERR		-1

#ifdef _MAGIC_BIT
#define MAGIC_BIT_SIZE          4
#define MAGIC_BIT(a)  {a[0]=0x90; a[1]=0x85; a[2]=0x20; a[3]=0x83;}
#define MAGIC_BIT_CHECK(a) a[0]==0x90&&a[1]==0x85&&a[2]==0x20&&a[3]==0x83?1:0
#endif

#define IP_URL_LEN		128

/*tcp server function */
int create_tcp_server_session(char *srv_ipaddr, int srv_port);
int accept_tcpserver_connection(int sock_fd, struct sockaddr_in *cli_addr);

/*tcp client function */
int create_tcp_client_session(char *svr_ipaddr, int svr_port, int non_block_flag);

/* common function*/
int send_tcp_data(int sock_fd, void *ptr, int len);
int recv_tcp_data(int sock_fd, void *ptr, int len);
int recv_tcp_data_timeout(int sock_fd, void *ptr, int len, int timeout);
void close_tcp_session(int sock_fd);

/* util function */
int url_to_ipaddr(char* url, char* ipaddr);

#ifdef _MAGIC_BIT
int magic_bit_check(int sockfd, const unsigned char* str);
#endif

#endif /* __tcp_base_h__ */
