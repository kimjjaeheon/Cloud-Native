#ifndef __msgq_h__
#define __msgq_h__

#define __BIGMSGQUEUE_ENABLED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <signal.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <errno.h>

#define MAX_SEND_SIZE   770
#define MSGQPERM        0666

struct qmsgbuf
{
	long mtype;
	char mtext[MAX_SEND_SIZE];
};

int  create_msgq(key_t key);
int  send_msgq(int qid, struct qmsgbuf *sbuf, int wsize);
int  read_msgq(int qid, long type, struct qmsgbuf *rbuf, int rsize, int flag);
void remove_msgq(int qid);
void change_mode_msgq(int qid, char *mode);
int  get_msgq_num(int qid);

#endif /*__msgq_h__*/
