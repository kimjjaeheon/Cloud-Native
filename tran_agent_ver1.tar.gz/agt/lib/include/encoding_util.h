#ifndef __TRAN_ENCODING_UTIL__
#define __TRAN_ENCODING_UTIL__

#define EUC_KR 	0
#define UTF_8 	1

int hcut(char *org_str, int org_len, int cut_len, int encoding_type);

#endif
