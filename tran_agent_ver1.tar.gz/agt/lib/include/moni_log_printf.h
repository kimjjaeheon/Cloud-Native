#ifndef __moni_printf_h__
#define __moni_printf_h__

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>

int  open_moni_log(const char *dir, const char *title);
void close_moni_log(void);
void moni_log_printf(char* fmt, ...);

#endif /* __moni_printf_h__ */
