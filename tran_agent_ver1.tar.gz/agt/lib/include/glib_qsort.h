#ifndef __GLIB_QSORT_H__
#define __GLIB_QSORT_H__

#include "tranm_std_lib.h"

#ifndef size_t
#define size_t int
#endif

void _quicksort (void *const pbase, size_t total_elems, size_t size, __comp cmp, void *arg);

#endif
