#ifndef __TRANM_STD_LIB_H__
#define __TRANM_STD_LIB_H__

/* Sorting type */
#define TRAN_SORT_TYPE_INT   1
#define TRAN_SORT_TYPE_LONG  2
#define TRAN_SORT_TYPE_FLOAT 3
#define TRAN_SORT_TYPE_PTR   10

/* function pointer */
typedef int (*__comp) (const void *, const void *, void *);

#endif
