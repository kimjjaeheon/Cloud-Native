#ifndef __TRANM_THREAD_H__
#define __TRANM_THREAD_H__

#include <pthread.h>

#define TRANM_MUTEX_LOCK(key) { pthread_mutex_lock(&key); }
#define TRANM_MUTEX_TRY_LOCK(key) { pthread_mutex_lock(&key); }
#define TRANM_MUTEX_UNLOCK(key) { pthread_mutex_unlock(&key); }

void tranm_th_join(pthread_t th);
void tranm_th_cancel(pthread_t th);


#endif /* __TRANM_THREAD_H__ */

