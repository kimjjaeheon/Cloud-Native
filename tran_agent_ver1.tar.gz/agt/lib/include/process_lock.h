#ifndef __SCHEDULER_LOCK_H__
#define __SCHEDULER_LOCK_H__

#ifdef __cplusplus
extern "C" {
#endif

int ProcessUnLock();
int ProcessLock(const char *szPath);

#ifdef __cplusplus
}
#endif

#endif
