#ifndef __read_cfg_h__
#define __read_cfg_h__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>

#ifdef _SUNOS
	#include <errno.h>
#else
	#include <sys/errno.h>
#endif

#include <ctype.h>

#define CONFLIB_MAX_TOKEN_LEN   64

int get_nth_token_in_file_section(char*, char*, char*, int, char*);
int get_string_in_section(FILE*, char*, char*);
int seek_section(FILE*, char*);

#endif /* __read_cfg_h__ */
