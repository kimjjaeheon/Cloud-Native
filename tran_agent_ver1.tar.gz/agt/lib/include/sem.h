#ifndef _sem_h_
#define _sem_h_

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <errno.h>

#define SEMPERM 0666
#define SEM_IFLAGS (SEMPERM | IPC_CREAT | IPC_EXCL)

int  create_sem(key_t semkey, int nsems);
int  sem_lock(int sem_id, short num, short sem_flg);
int  sem_unlock(int sem_id, short num, short sem_flg);
void sem_wait(int sem_id, short num);
int  init_sem_val(int sem_id, int nth_sem, int val);

#endif /*_sem_h_*/
