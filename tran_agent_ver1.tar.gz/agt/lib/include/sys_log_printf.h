#ifndef __sys_log_printf_h__
#define __sys_log_printf_h__

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>

int  open_sys_log(const char *dir, const char *title);
void close_sys_log(void);
void sys_log_printf(char* fmt, ...);

#endif /* __sys_log_printf_h__ */
