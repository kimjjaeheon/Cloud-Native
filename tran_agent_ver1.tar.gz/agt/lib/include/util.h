#ifndef _util_h_
#define _util_h_

#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <strings.h>
#include <errno.h>

int get_xth_value(char (*sbuf)[2000], char *ptr, int pos, char *deli);
int cut_xth_string(char *sbuf, char *msg, int msglen, int *offset);
void make_str(char *sbuf, char *msg, int msglen, int *offset, char deli_ch);

void make_an_type(char *sbuf, char *msg, int msglen, int offset, int totlen);
void make_an_type1(char *sbuf, char *msg, int msglen, int *offset, int totlen);
void make_ntype(char *sbuf, char *msg, int msglen, int offset, int totlen);
void make_ntype1(char *sbuf, char *msg, int msglen, int *offset, int totlen);

void set_idle(int tv_sec, int tv_usec);
long get_mili_time_delay(struct timespec *clock);
long get_micro_time_delay(struct timespec *clock);
long get_nano_time_delay(struct timespec *clock);

int mkpath(char *file_path, mode_t mode);
int replace_char(char *buf, char oldc, char newc);
int tran_r_trim(char *buf);

#endif /*_util_h_*/
