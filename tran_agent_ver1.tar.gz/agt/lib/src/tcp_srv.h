#ifndef __tcp_srv_h__
#define __tcp_srv_h__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/errno.h>
#include <ctype.h>

#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fcntl.h>
#include <unistd.h>

int  create_tcp_server_session(char *srv_ipaddr, int srv_port);
int  accept_tcpserver_connection(int sock_fd, struct sockaddr_in *cli_addr);
int  send_tcp_server_data(int sock_fd, void *ptr, int len);
int  recv_tcp_server_data(int sock_fd, void *ptr, int len);
void close_tcp_server_session(int sock_fd);

#endif /* __tcp_srv_h__ */
