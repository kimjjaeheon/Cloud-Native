#ifndef __TRANM_BSEARCH_H__
#define __TRANM_BSEARCH_H__

#include "tranm_std_lib.h"
void *tranm_bsearch(const void *key, const void *base, int num, int size, __comp cmp, void *p);

#endif

