#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char* tran_str_token_single(char* p_pattern_, const char* p_delimeter_);
int tran_str_n_token_single(char* p_pattern_, const char* p_delimeter_, char** buf_, int max_token_);

/** by LIANDLI in 2018.04.27
 * string_token
 * 문자열에서 구분자를 구분하여 파싱한다.
 * 구분자 사이에 아무런 값이 없을 경우 token count 가 증가 하지 않는다.
 *
 * param
 *  - p_pattern : 문자열
 *  - p_delimiter : 구분자 값
 *  - buf : token된 데이터의 주소정보를 저장하는 버퍼
 *
 * return
 *  - int : token count
 *
 * other
 *  - none
 */
int tran_str_token(char* p_pattern_, const char* p_delimeter_, char** buf_)
{
	int idx  = 0;
	char *p  = NULL;
	char *pp = NULL;
	p=strtok_r(p_pattern_, p_delimeter_, &pp);
	while(p)
	{
		buf_[idx++] = p;
		p = strtok_r(NULL, p_delimeter_, &pp);
		if( idx >= 100 )
			break;
	}

	return idx;
}

/** by LIANDLI in 2018.04.27
 * string_n_token
 * 문자열에서 구분자를 구분하여 파싱한다. 최대 n 개 만큼 파싱한다.
 *
 * param
 *  - p_pattern : 문자열
 *  - p_delimiter : 구분자 값
 *  - buf : token된 데이터의 주소정보를 저장하는 버퍼
 *  - max_token : 최대 token 수
 *
 * return
 *  - int : token count
 *
 * other
 *  - none
 */

int tran_str_n_token(char* p_pattern_, const char* p_delimeter_, char** buf_, int max_token_)
{
	int idx       = 0;
	int token_cnt = 0;
	char *p       = NULL;
	char *pp      = NULL;

	p=strtok_r(p_pattern_, p_delimeter_, &pp);
	while(p)
	{
		buf_[idx++] = p;
		p = strtok_r(NULL, p_delimeter_, &pp);

		if( ++token_cnt >= max_token_ )
		{
			break;
		}
	}

	return idx;
}

/** by LIANDLI in 2018.04.27
 * string_n_token_single
 * 문자열에서 구분자를 구분하여 파싱한다.
 * 구분자사이에 값이 없는 경우도 token count 가 증가 한다.
 *
 * param
 *  - p_pattern : 문자열
 *  - p_delimiter : 구분자
 *  - buf : token된 데이터의 주소정보를 저장하는 버퍼
 *  - max_token : 최대 token count
 *
 * return
 *  - int : token count
 *
 * other
 *  - none
 */
int tran_str_n_token_single(char* p_pattern_, const char* p_delimeter_, char** buf_, int max_token_)
{
	int idx         = 0;
	int token_cnt   = 0;
	char *p         = NULL;
	char *pp        = NULL;

	p = tran_str_token_single(p_pattern_, p_delimeter_);

	while(p)
	{
		if (*p )
		{
			buf_[idx++] = p;
		}
		else
		{
			buf_[idx++] = 0x00;
		}
		p = tran_str_token_single(NULL, p_delimeter_);

		if( ++token_cnt >= max_token_ )
		{
			break;
		}
	}

	return idx;
}

/** by LIANDLI in 2018.04.27
 * string_token_single
 * 문자열에서 구분자를 구분하여 파싱한다.
 * 구분자 사이에 아무런 값이 없을 경우 token count 가 증가 하지 않는다.
 *
 * param
 *  - p_pattern : 문자열
 *  - p_delimiter : 구분자 값
 *
 * return
 *  - int : token count
 *
 * other
 *  - none
 */
char* tran_str_token_single(char* p_pattern_, const char* p_delimeter_)
{
	int idx = 0;

	static char *src = 0x00;
	char *p   = 0x00;
	char *ret = 0x00;

	if ( p_pattern_ != NULL )
	{
		src = p_pattern_;
	}

	if ( src == NULL )
	{
		return NULL;
	}

	if ( (p = strpbrk(src, p_delimeter_)) != NULL )
	{
		*p = 0x00;
		ret = src;
		src = ++p;
	}
	else if ( *src )
	{
		ret = src;
		src = NULL;
	}

	return ret;
}

/** by LIANDLI in 2018.04.27
 * str_search
 * token 된 결과에서 문자를 찾는다.
 *
 * param
 *  - src : 찾을 문자열
 *  - dst : token 된 문자 포인터
 *  - dst_cnt : token 된 count
 *
 * return
 *  - int : token count
 *
 * other
 *  - none
 */
int tran_str_search(const char* src_, const char** dst_, const int dst_cnt_)
{
	int idx;

	for(idx=0; idx<dst_cnt_; idx++)
	{
		if( strstr(src_, dst_[idx]) )
		return 0;
	}
	return -1;
}

int tran_a_trim(char *buf)
{
    int curr_pos;
    int end = buf ? strlen(buf) : 0 ;

    int idx;
    int offset=0;

    /* buf 예외처리 */
    if( !end )
    {
        return -1;
    }

    char *tmp = (char*)malloc(sizeof(char)*end);

    /* malloc 예외처리 */
    if( !tmp )
    {
        return -1;
    }

    /* 초기화 */
    memset(tmp, 0x00, end);

    /* malloc 한 tmp 영역에 buf 복사 */
    memcpy(tmp, buf, end);

    /* All Trim */
    for( idx=0; idx<end; idx++ )
    {
        if( isspace(tmp[idx]) )
        {
            continue;
        }
        tmp[offset++] = tmp[idx];
    }

    snprintf(buf, offset+1, "%s", tmp);
    buf[offset+1] = 0x00;


    /* tmp 데이터 메모리 해제 */
    free(tmp);

    return 0;
}

int tran_is_comment(const char *buf)
{
    char *p = strchr(buf, '#');

    if ( p )
    {
        if ( p == buf )
        {
            return 1;
        }
        *p = 0x00;
    }

    return 0;
}

