#include "sem.h"

int create_sem(key_t semkey, int nsems)
{
	int i;
	int sem_id;

	if ((sem_id = semget((key_t)semkey, nsems, SEM_IFLAGS)) < 0)
	{
		if (errno == EEXIST)
		{
			sem_id = semget((key_t)semkey, nsems, 0);
		}
	}
	else
	{
		for (i = 0; i < nsems; i++)
		{
			init_sem_val(sem_id, i, 1);
		}
	}

	return sem_id;
}


int init_sem_val(int sem_id, int nth_sem, int val)
{
	union semun
	{
		int val;
		struct semid_ds *stat;
		ushort *array;
	} sem_union;

	sem_union.val = val;
	if (semctl(sem_id, nth_sem, SETVAL, sem_union) == -1)
	{
		/*
		perror("semctl");
		*/
		return -1;
	}
	return 1;
}


int sem_lock(int sem_id, short num, short sem_flg) 
{
	int r;
	struct sembuf sb;
	sb.sem_num = num;
	sb.sem_op = -1;
	sb.sem_flg = sem_flg;

	do {
		r = semop(sem_id, &sb, 1);
	} while (r < 0 && errno == EINTR);
	
	return r;
}


int sem_unlock(int sem_id, short num, short sem_flg) 
{
	int r;
	struct sembuf sb;
	sb.sem_num = num;
	sb.sem_op = 1;
	sb.sem_flg = sem_flg;

	do {
		r = semop(sem_id, &sb, 1);
	} while (r < 0 && errno == EINTR);

	return r;
}


void sem_wait(int sem_id, short num) 
{
	int r;
	struct sembuf sb;
	sb.sem_num = num;
	sb.sem_op = 0;
	sb.sem_flg = 0;

	do {
		r = semop(sem_id, &sb, 1);
	} while (r < 0 && errno == EINTR);

	return;
}

#if 0

int main(void)
{
	int ret;
	int sem_id;
	key_t semkey = 0x1000;
	sem_id = init_sem(semkey, 1);

	ret = sem_lock(sem_id, 0, SEM_UNDO | IPC_NOWAIT);
//	sem_wait(sem_id, 0); 
//	sleep(30);
	printf("######## ret : %d\n", ret);
	sem_unlock(sem_id, 0, SEM_UNDO | IPC_NOWAIT);

	printf("SEM_UNDO : %d\n", SEM_UNDO);
	printf("IPC_NOWAIT : %d\n", IPC_NOWAIT);

	return 0;
}

#endif
