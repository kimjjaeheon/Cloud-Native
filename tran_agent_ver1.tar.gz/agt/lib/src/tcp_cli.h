#ifndef __tcp_cli_h__
#define __tcp_cli_h__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/errno.h>
#include <ctype.h>

#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fcntl.h>
#include <unistd.h>


int  create_tcp_client_session(char *svr_ipaddr, int svr_port, int non_block_flag);
void close_tcp_client_session(int sock_id);
int  send_tcp_clent_data(int sock_id, void *ptr, int len);
int  recv_tcp_client_data(int sock_id, void *ptr, int len);

#endif /* __read_cfg_h__ */
