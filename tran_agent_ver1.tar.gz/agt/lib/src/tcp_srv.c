#include "tcp_srv.h"

#define MAX_PENDING  5

int create_tcp_server_session(char *srv_ipaddr, int srv_port)
{
	int sock_opt;
	int srv_sockfd;
	struct sockaddr_in srv_addr;

	if ((srv_sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{
		/*
		perror ("socket failed");
		*/
		exit (1);
	}

	sock_opt = 1;

	if (setsockopt(srv_sockfd, SOL_SOCKET, SO_REUSEADDR, (void *)&sock_opt,
				sizeof(sock_opt)) == -1)
	{
		/*
		perror("setsockopt failed");
		*/
		(void)close(srv_sockfd);
		exit(1);
	}

	bzero((char*)&srv_addr, sizeof(srv_addr));

	srv_addr.sin_family = AF_INET;
	srv_addr.sin_port = htons(srv_port);

	if (srv_ipaddr)
	{
		srv_addr.sin_addr.s_addr = inet_addr(srv_ipaddr);
	}
	else
	{
		srv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	}

	if (bind(srv_sockfd, (struct sockaddr *) &srv_addr, sizeof (srv_addr)) == -1)
	{
		/*
		perror("bind failed");
		*/
		exit(1);
	}

	if (listen(srv_sockfd, MAX_PENDING) == -1)
	{
		/*
		perror("listen failed");
		*/
		exit(1);
	}

	return srv_sockfd;;
}


int accept_tcpserver_connection(int srv_sockfd, struct sockaddr_in *cli_addr)
{
	int cli_sockfd;

	socklen_t addr_len = sizeof(struct sockaddr_in);

	if ((cli_sockfd = accept(srv_sockfd, (struct sockaddr *) cli_addr, &addr_len)) == -1)
	{
		/*
		perror("accept failed");
		*/
		exit(1);
	}

	return cli_sockfd;
}


int send_tcp_server_data(int sock_fd, void *ptr, int len)
{
	int send_len;

	if ((send_len = send(sock_fd, ptr, len, 0)) == -1)
	{
		/*
		perror ("send error");
		*/
		return -1;
	}
								    
	return send_len;
}


int recv_tcp_server_data(int sock_fd, void *ptr, int len)
{   
	int recv_len, err_len, add_len;

	while (1)
	{
		if ((recv_len = read(sock_fd, ptr, len)) == len)
		{
			break;
		}

		if (recv_len > 0)
		{
			printf("illegal_len = %d, ", recv_len);
			err_len = len - recv_len;

			while (1)
			{
				// 미 수신 추가 데이터 수신
				if ((add_len = read(sock_fd, (char *)ptr + recv_len, err_len)) == err_len)
				{
					printf("#%d bytes are added!\n", err_len);
					return len;
				}
				recv_len += add_len;
				err_len = len - recv_len;
			}
		}
		else
		{
			/*
			perror("recv error");
			*/
			break;
		}
	}
	return recv_len;
}


void close_tcp_server_session(int sock_fd)
{
    if (sock_fd != -1) close(sock_fd);
}   
