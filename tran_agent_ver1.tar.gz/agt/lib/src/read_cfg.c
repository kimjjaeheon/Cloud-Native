#include "read_cfg.h"

static FILE    *fp;
static char    buff[256], token[16][CONFLIB_MAX_TOKEN_LEN];
static int     lnum, lnum2;

int get_nth_token_in_file_section (
		char *fname, 
		char *section, 
		char *keyword, 
		int  n, 
		char *string
		)
{
	if ((fp = fopen(fname, "r")) == NULL)
	{
		fprintf (stderr,"[get_nth_token_in_file_section] fopen fail[%s]; errno=%d(%s)\n", 
				fname, errno, strerror(errno));
		return -1;
	}

	if ((lnum = seek_section(fp, section)) < 0)
	{
		fprintf(stderr,"[seek_section] not found section[%s] in file[%s]\n", 
				section, fname);
		fclose(fp);
		return -1;
	}

	if ((lnum2 = get_string_in_section(fp, keyword, buff)) < 0)
	{
		fprintf(stderr,"[get_string_in_section] not found keyword[%s]; file=%s, section=%s\n",
				keyword, fname, section);
		fclose(fp);
		return -1;
	}

	fclose(fp);

	lnum += lnum2;

	if (sscanf(buff, "%s%s%s%s%s %s%s%s%s%s %s%s%s%s%s %s",
					token[0], token[1], token[2], token[3], token[4],
					token[5], token[6], token[7], token[8], token[9],
					token[10],token[11],token[12],token[13],token[14],
					token[15]) < n)
	{
		fprintf(stderr,"[get_nth_token_in_file_section] can't found nth(%d) token; file=%s, section=%s, keyword=%s, lnum=%d\n", n, fname, section, keyword, lnum);
		return -1;
	}

	strcpy(string, token[n-1]);

	return 1;
}


int seek_section(
		FILE *fp,
		char *section
		)
{
	char    get_buf[256] = {0,};
	int     seek_line = 0;

	rewind(fp);

	while (fgets(get_buf, sizeof(get_buf), fp) != NULL)
	{
		seek_line++;

		if (get_buf[0] != '[')
		{
			continue;
		}

		char *end_ch = strchr(&get_buf[1], ']');
		int section_len = end_ch - &get_buf[1];

		if (section_len == strlen(section))
		{
			if (strstr(get_buf, section))
			{
				return seek_line;
			}
		}
	}

	fprintf(stderr,"[seek_section] not found section[%s]\n", section);

	return -1;
}


int get_string_in_section (
		FILE *fp,
		char *keyword,
		char *string
		)
{
	char	get_buf[256] = {0,};
	char 	value_str[CONFLIB_MAX_TOKEN_LEN], *next;
	int		str_line = 0;

	while (fgets(get_buf, sizeof(get_buf), fp) != NULL)
	{
		str_line++;

		if (get_buf[0] == '[') /* end of section */
			break;
		if (get_buf[0]=='#' || get_buf[0]=='\n') /* comment line or empty */
			continue;

		sscanf(get_buf,"%s", value_str);

		if (!strcmp(value_str, keyword))
		{
			strtok_r(get_buf, "=", &next);
			for (; isspace(*next); next++) ;
			strcpy(string, next);
			return str_line;
		}
	}

	fprintf(stderr,"[get_string_in_section] not found keyword[%s]\n", keyword);

	return -1;
}
