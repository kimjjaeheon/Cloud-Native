#include "shmem.h"

int create_shm(long shm_key, long shm_size, int *q_eexist)
{
	int shm_id;

	if ((shm_id = shmget(shm_key, shm_size, SHM_IFLAGS)) < 0)
	{
		if (errno == EEXIST)
		{
			shm_id = shmget(shm_key, shm_size, SHMPERM);
			*q_eexist = 1;
		}
		else
		{
			/*
			perror("shmget");
			*/
			return -1;
		}
	}
	else
	{
		*q_eexist = 0;
	}
	return shm_id;
}


int remove_shm(int shm_id)
{
	return shmctl(shm_id, IPC_RMID, (struct shmid_ds *) 0);
}


void *attach_shm(int shm_id)
{
	void *shmptr;

	if ((shmptr = (void *)shmat(shm_id, (char *)0, 0)) == (char *)(-1))
	{
		return NULL;
	}
	else
	{
		return shmptr;
	}
}


int detach_shm(void *shmptr)
{
	return shmdt(shmptr);
}
