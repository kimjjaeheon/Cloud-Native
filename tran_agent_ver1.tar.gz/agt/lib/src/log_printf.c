#include "log_printf.h"

#define MAX_PATH_LEN 256

static FILE *log_file;
static int cur_day = 0;

static char date_str[32];
static char time_str[32];
static char log_dir[256];
static char log_title[256];

static time_t now;
static struct tm *tm;

static void check_day(void)
{
	if (cur_day != tm->tm_yday)
	{
		close_log();
		open_log(NULL, NULL, 0);
	}
	return;
}


static char *get_cur_date(void)
{
	strftime(date_str, sizeof(date_str), "%Y-%m-%d", tm);
	cur_day = tm->tm_yday;
	return date_str;
}


static char *get_cur_time(void)
{
	strftime(time_str, sizeof(time_str), "%m-%d %T  ", tm);
	return time_str;
}


/* open the log file. */
int open_log(const char *dir, const char *title, int mflag)
{
	char full_log_fn[MAX_PATH_LEN];

	if (log_file)
	{
		return 0;
	}

	if (dir)
	{
		strcpy(log_dir, dir);
	}

	if (title)
	{
		strcpy(log_title, title);
	}

	if (mflag)
	{
		time(&now);
		tm = localtime(&now);
	}

	sprintf(full_log_fn, "%s/%s-%s-log", log_dir, log_title, get_cur_date());

	log_file = fopen(full_log_fn, "a");

	if (log_file)
	{
		setbuf(log_file, NULL);
	}

	return (log_file != NULL) ? 0 : -1;
}


/* close the log file. */
void close_log(void)
{
	if (log_file)
	{
		fclose(log_file);
		log_file = NULL;
	}
	return;
}


#define LOG_MSG_LEN	4096

void log_printf(char *fmt, ...)
{
	int nbuff;
	char buff[LOG_MSG_LEN + 1];
	va_list args;

	va_start (args, fmt);
	nbuff = vsnprintf (buff, LOG_MSG_LEN, fmt, args);
	va_end (args);

	if (nbuff < 1) return;

	time(&now);
	tm = localtime(&now);

	check_day();

	if (log_file)
	{
		fputs(get_cur_time(), log_file);
		fputs(buff, log_file);
		fputc('\n', log_file);
	}

	return;
}
