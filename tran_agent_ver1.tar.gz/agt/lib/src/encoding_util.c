#include <stdio.h>
#include <string.h>
#include "encoding_util.h"

int hangul_euckr(char *org_str, int org_len, int std_len);
int hangul_utf8(char *org_str, int org_len, int std_len);

/*
 * +++++++ RULE +++++++
 * EUC-KR
 * range :
 * rule 1 : 0xb0 <= 1st byte of word <= 0xc8
 * rule 2 : 0xa1 <= 2nd byte of word <= 0xfe  -- key value
 *
 * UTF-8
 * range : 
 * 1st byte of word is starting with 0xE...(AND operation 0xf0)
 * 2nd byte of word is starting with 10... (AND operation 0xc0)
 * 3rd byte of word is starting with 10... (AND operation 0xc0)
 */

/* 
 * org_str : original (input) string
 * org_len : length of original string
 * cut_len : length of cut
 * encoding type : include/common.h, encoding_util.h, jni/common.h 
 * 0 : EUC_KR
 * 1 : UTF_8
 * */

int hcut(char *org_str, int org_len, int cut_len, int encoding_type)
{
	if (org_str == NULL || cut_len <= 0)
	{
		return 0;
	}

	if ( org_len < 0)
	{
		org_len = strlen(org_str);
	}

	int std_len = 0;

	if (cut_len >= org_len)
	{
		return org_len;
	}
	else
	{
		std_len = cut_len;
	}

#ifdef _DEBUG
	printf("---------------------------------------------------\n");
	printf("org_len = %d \n", org_len);
	printf("cut_len = %d \n", cut_len);
	printf("std_len = %d \n", std_len);
#endif

	switch (encoding_type)
	{
		case EUC_KR :
			std_len = hangul_euckr(org_str, org_len, std_len);
			break;
		case UTF_8 :
			std_len = hangul_utf8(org_str, org_len, std_len);
			break;
		default :
			std_len = 0;
#ifdef _DEBUG
			printf("undefined encoding type");
#endif
			break;
	}

#ifdef _DEBUG
	printf("dest = |%.*s|\n", std_len, org_str);
#endif
	return std_len;
}


int hangul_utf8(char *org_str, int org_len, int std_len)
{
	int word_sequence = 0;

	while ((std_len - 1 - word_sequence >= 0) && (org_str[std_len - 1 - word_sequence] & 0x80))
	{
#ifdef _DEBUG
		printf("org_str[%d] = %x, (maskoff(%x) \n", std_len - 1 - word_sequence, org_str[std_len - 1 - word_sequence], (org_str[std_len - 1 - word_sequence] & 0xf0));
#endif
		if ((org_str[std_len - 1 - word_sequence] & 0xf0) == 0xe0) /* found first byte of hangul */
		{
			/* if found 1st byte of hangul */
			if ((org_len >= std_len - word_sequence + 2) && 
					((org_str[std_len - 1 - word_sequence + 1] & 0xc0) == 0x80) && 
					((org_str[std_len - 1 - word_sequence + 2] & 0xc0) == 0x80))
			{
#ifdef _DEBUG
				printf("found hangul(utf-8)\n");
#endif
				if (word_sequence >= 2)
				{
					word_sequence-=2;
				}
				else
				{
					word_sequence++;
				}
				break;
			}
			else
			{
				word_sequence++;
#ifdef _DEBUG
				printf("<!> unknown type of language format \n");
#endif
			}
		}
		else
		{
			word_sequence++;
		}
	}

	std_len -= word_sequence;

	return std_len;
}


int hangul_euckr(char *org_str, int org_len, int std_len)
{
	int word_sequence = 0;

	while ((std_len - 1 - word_sequence >= 0) && 
			((org_str[std_len - 1 - word_sequence] & 0xff) >= 0xa1) && 
			((org_str[std_len - 1 - word_sequence] & 0xff) <= 0xfe))
	{
#ifdef _DEBUG
		printf("org_str[%d] = %x, (maskoff(%x) \n", std_len - 1 - word_sequence, org_str[std_len - 1 - word_sequence], (org_str[std_len - 1 - word_sequence] & 0xf0));
#endif

		if (((org_str[std_len - 1 - word_sequence] & 0xff) >= 0xa1)  && ((org_str[std_len - 1 - word_sequence] & 0xff) <= 0xfe))
		{
			if ((((org_str[std_len - 1 - word_sequence] & 0xff) >= 0xa1) && (org_str[std_len - 1 - word_sequence] & 0xff) < 0xb0) 
					|| (((org_str[std_len - 1 - word_sequence] & 0xff) > 0xc8) && ((org_str[std_len - 1 - word_sequence] & 0xff) <= 0xfe))) 
			{
#ifdef _DEBUG
				printf("found hangul(euc-kr)\n");
#endif
				break;
			}
			else
			{
				word_sequence++;
			}
		}
	}

	std_len -= word_sequence;

	return std_len;
}
