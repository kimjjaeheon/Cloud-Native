#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>

#ifndef boolean
enum boolean { false, true };
#endif

static int fd = 0x00;

int ProcessLock(const char *szLockPath)
{
	if ( (fd=open(szLockPath, O_RDWR|O_CREAT, 0660)) < 0 )
	{
#if 0
		SCH_PRINT("<!> Scheduler already started. [lock_file:%s]", szLockPath);
#endif
		return -1;
	}

	if ( lockf(fd, F_TLOCK, 0L) < 0 )
	{
#if 0
		SCH_PRINT("<!> Lock fail. [err:%d, file:%s]", errno, szLockPath);
#endif
		close(fd);
		return -2;
	}

	return true;
}

int ProcessUnLock()
{
	if ( lockf(fd, F_ULOCK, 0L) < 0 )
	{
#if 0
		SCH_PRINT("<!> UnLock fail. [err:%d]", errno);
#endif
		close(fd);
		return false;
	}

	close(fd);
	return true;
}
