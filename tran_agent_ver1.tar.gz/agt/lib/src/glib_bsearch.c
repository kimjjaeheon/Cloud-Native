#include <stdio.h>
#include "glib_bsearch.h"
#include "tranm_qsort.h"
/*
 * A generic implementation of binary search for the Linux kernel
 *
 * Copyright (C) 2008-2009 Ksplice, Inc.
 * Author: Tim Abbott <tabbott@ksplice.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; version 2.
 */

/*
 * bsearch - binary search an array of elements
 * @key: pointer to item being searched for
 * @base: pointer to first element to search
 * @num: number of elements
 * @size: size of each element
 * @cmp: pointer to comparison function
 *
 * This function does a binary search on the given array.  The
 * contents of the array should already be in ascending sorted order
 * under the provided comparison function.
 *
 * Note that the key need not have the same type as the elements in
 * the array, e.g. key could be a string and the comparison function
 * could compare the string with the struct's name field.  However, if
 * the key and elements in the array are of the same type, you can use
 * the same comparison function for both sort() and bsearch().
 */
void *_tranm_bsearch(const void *key, const void *base, int num, int size, __comp cmp, void *p)
{

#ifdef _SAMPLE
	fprintf(stdout, "key:%x, base:%x, cnt:%d, size:%d, func:%x, ptr_idx:%d\n", key, base, num, size, cmp, p==NULL?0:*((int*)p));
#endif
	const char *pivot;
	int result;

	while (num > 0) {
#ifdef _HPUX
		pivot = (char*)((unsigned long)base + (unsigned long)((num >> 1) * size));
#else
		pivot = base + (num >> 1) * size;
#endif
		/*
		fprintf(stdout, "key[%s], pivot[%s]\n", key, pivot+4);
		*/
		result = cmp(key, pivot, p);

		if (result == 0)
			return (void *)pivot;

		if (result > 0) {
			base = pivot + size;
			num--;
		}
		num >>= 1;
	}

	return 0x00;
}

