#include "msgq.h"

int create_msgq(key_t key) 
{
	int qid;

	if ((qid = msgget(key, IPC_CREAT | MSGQPERM)) == -1)
	{
		/*
		perror("msgget");
		*/
	}

	return qid;
}
        

int send_msgq(int qid, struct qmsgbuf *sbuf, int wsize)
{
	int res;

	if ((res = msgsnd(qid, (void *)sbuf, wsize, IPC_NOWAIT)) == -1)
	{
		/*
		perror("msgsnd");
		*/
	}

	return res;
}


int read_msgq(int qid, long type, struct qmsgbuf *rbuf, int rsize, int flag)
{
	int res;

	do 
	{
		res = msgrcv(qid, (struct msgbuf *)rbuf, rsize, type, flag?IPC_NOWAIT:0);
	}
	while (res == -1 && errno == EINTR);

	return res;
}


void remove_msgq(int qid)
{
	msgctl(qid, IPC_RMID, 0);
	return;
}


void change_mode_msgq(int qid, char *mode)
{
	struct msqid_ds ds;
	msgctl (qid, IPC_STAT, &ds);
	sscanf (mode, "%ho", &ds.msg_perm.mode);
	msgctl (qid, IPC_SET, &ds);
	return;
}


int get_msgq_num(int qid)
{
	int res;
	struct msqid_ds ds;

	if ((res = msgctl(qid, IPC_STAT, &ds)) < 0)
	{
		/*
		perror("msgctl failed");
		*/
		return res;
	}

	return ds.msg_qnum;
}
