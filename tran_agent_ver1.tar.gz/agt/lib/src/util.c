#include "util.h"

int replace_char(char *buf, char oldc, char newc)
{
	int i = 0;
	char *nch = buf;

	do
	{
		nch = strchr(nch, oldc);

		if (nch)
		{
			*nch = newc;
			i++;
		}
	}
	while (nch);

	return i;
}


int mkpath(char *file_path, mode_t mode)
{
	char *p, *r;
	char dup_path[128];
	strcpy(dup_path, file_path);
	r = dup_path;

	for (p = strchr(r + 1, '/'); p; p = strchr(p + 1, '/'))
	{
		*p = '\0';

		if (mkdir(r, mode) == -1)
		{
			if (errno != EEXIST)
			{
				*p = '/';
				return -1;
			}
		}
		*p='/';
	}

	return 0;
}

#if 0
int get_xth_value(char (*sbuf)[2000], char *ptr, int pos, char *deli)
{
	char *tr;

	int i = 0;

	tr = strtok(ptr, deli);

	strcpy(*(sbuf + (i++)) , tr);

	while (tr != NULL)
	{
		if (i == pos)
		{
			break;
		}
		tr = strtok(NULL, deli);
		strcpy(*(sbuf + (i++)), tr);
	}

	return (((i == pos) || (pos == 0)) ? (i - 1) : -1);
}
#endif

int get_xth_value(char (*sbuf)[2000], char *ptr, int pos, char *deli)
{
    char *tr, *ch_str;
    int i = 0, diff_ptr;


    for (i = 0 ; i < pos ; i++)
    {
        ch_str = strchr(ptr, deli[0]);

        if (ch_str)
        {
		/*
                printf(">> diff ptr -ch_str is %d\n", ch_str - ptr);
		*/

                diff_ptr = ch_str - ptr;

                if (diff_ptr == 0)
                {
					strcpy(*(sbuf + (i)), "");
                }
                else
                {
					if (diff_ptr >= (2000 - 1))
					{
						memcpy(sbuf + i, ptr, 2000 - 1);
						sbuf[i][2000 - 1] = 0;
					}
					else
					{
						memcpy(sbuf + i, ptr, diff_ptr);
						sbuf[i][diff_ptr] = 0;
					}
                }
                ptr = ++ch_str;
        }
        else
        {
			sbuf[i][2000 - 1] = 0;
			strncpy(sbuf[i++], ptr, (2000 - 1));
			break;
        }
    }

    return (((i == pos) || (pos == 0)) ? i  : -1);
}


int cut_xth_string(char *sbuf, char *msg, int msglen, int *offset)
{
	memcpy(sbuf, &msg[*offset], msglen);
	*offset += msglen;
	return msglen;
}


void make_an_type(char *sbuf, char *msg, int msglen, int offset, int totlen)
{
	int whitelen = totlen - msglen;
	int i;

	if (whitelen < 0)
	{
		memcpy (&sbuf[offset], msg, totlen);
	}
	else
	{
		memcpy (&sbuf[offset], msg, msglen);

		for (i = 0; i < whitelen; i++)
		{
			sbuf[offset + msglen + i] = ' ';
		}
	}
}


void make_an_type1(char *sbuf, char *msg, int msglen, int *offset, int totlen)
{
	int whitelen = totlen - msglen;
	int i;

	if (whitelen < 0)
	{
		memcpy (&sbuf[*offset], msg, totlen);
		*offset += totlen;
	}
	else
	{
		memcpy (&sbuf[*offset], msg, msglen);

		for (i = 0; i < whitelen; i++)
		{
			sbuf[*offset + msglen + i] = ' ';
		}
	}
	*offset += totlen;
}


void make_ntype(char *sbuf, char *msg, int msglen, int offset, int totlen)
{
	int i;
	int whitelen = totlen - msglen;

	if (whitelen < 0)
	{
		memcpy (&sbuf[offset], msg, totlen);
		offset += totlen;
	}
	else
	{
		for (i = 0; i < whitelen; i++)
		{
			sbuf[offset + i] = '0';
		}
		memcpy (&sbuf[offset + i], msg, msglen);
	}
}


void make_ntype1(char *sbuf, char *msg, int msglen, int *offset, int totlen)
{
	int i;
	int whitelen = totlen - msglen;

	if (whitelen < 0)
	{
		memcpy (&sbuf[*offset], msg, totlen);
		*offset += totlen;
	}
	else
	{
		for (i = 0; i < whitelen; i++)
		{
			sbuf[*offset + i] = '0';
		}
		memcpy (&sbuf[*offset + i], msg, msglen);
	}
	*offset += totlen;
}


void make_str(char *sbuf, char *msg, int msglen, int *offset, char deli_ch)
{
	if (msg != NULL)
	{
		memcpy(&sbuf[*offset], msg, msglen);
		*offset += msglen;
	}

	if (deli_ch > 0)
	{
		sbuf[(*offset)++] = deli_ch;
	}
	return;
}

void make_strd(char *sbuf, char *msg, int msglen, int *offset, char deli)
{
	if (msg != NULL)
	{
		memcpy(&sbuf[*offset], msg, msglen);
		*offset += msglen;
	}
	sbuf[(*offset)++] = deli;
	return;
}


void make_strn(char *sbuf, char *msg, int msglen, int fixedlen, int *offset)
{
	if (msg != NULL)
	{
		if (msglen < fixedlen)
		{
			memcpy(&sbuf[*offset], msg, msglen);
			*offset += msglen;
			memset(&sbuf[*offset], ' ', fixedlen - msglen);
			*offset += (fixedlen - msglen);
		}
		else
		{
			memcpy(&sbuf[*offset], msg, fixedlen);
			*offset += fixedlen;
		}
	}
	sbuf[(*offset)++] = ',';
	return;
}


void make_strnd(char *sbuf, char *msg, int msglen, int fixedlen, int *offset, char deli)
{
	if (msg != NULL)
	{
		if (msglen < fixedlen)
		{
			memcpy(&sbuf[*offset], msg, msglen);
			*offset += msglen;
			memset(&sbuf[*offset], ' ', fixedlen - msglen);
			*offset += (fixedlen - msglen);
		}
		else
		{
			memcpy(&sbuf[*offset], msg, fixedlen);
			*offset += fixedlen;
		}
	}
	sbuf[(*offset)++] = deli;
	return;
}



void set_idle(int tv_sec, int tv_usec)
{
	struct timeval timeout;
	timeout.tv_sec  = tv_sec;
	timeout.tv_usec = tv_usec;
	select(0, (fd_set *)0, (fd_set *)0, (fd_set *)0, &timeout);
	return;
}


long  get_mili_time_delay(struct timespec *clock)
{
	long  time_delay, temp, temp_n = 0;

	if (clock[1].tv_nsec >= clock[0].tv_nsec)
	{
		temp = clock[1].tv_sec - clock[0].tv_sec;
		temp_n = clock[1].tv_nsec - clock[0].tv_nsec;
		time_delay = 1000 * temp + temp_n/1000000;
	}
	else
	{
		temp = clock[1].tv_sec - clock[0].tv_sec - 1;
		temp_n = 1000000000 + clock[1].tv_nsec - clock[0].tv_nsec;
		time_delay = 1000 * temp + temp_n/1000000;
	}
	return time_delay;
}


long  get_micro_time_delay(struct timespec *clock)
{
	long  time_delay, temp, temp_n = 0;

	if (clock[1].tv_nsec >= clock[0].tv_nsec)
	{
		temp = clock[1].tv_sec - clock[0].tv_sec;
		temp_n = clock[1].tv_nsec - clock[0].tv_nsec;
		time_delay = 1000000 * temp + temp_n/1000;
	}
	else
	{
		temp = clock[1].tv_sec - clock[0].tv_sec - 1;
		temp_n = 1000000000 + clock[1].tv_nsec - clock[0].tv_nsec;
		time_delay = 1000000 * temp + temp_n/1000;
	}
	return time_delay;
}


long  get_nano_time_delay(struct timespec *clock)
{
	long  time_delay, temp, temp_n = 0;

	if (clock[1].tv_nsec >= clock[0].tv_nsec)
	{
		temp = clock[1].tv_sec - clock[0].tv_sec;
		temp_n = clock[1].tv_nsec - clock[0].tv_nsec;
		time_delay = 1000000000 * temp + temp_n;
	}
	else
	{
		temp = clock[1].tv_sec - clock[0].tv_sec - 1;
		temp_n = 1000000000 + clock[1].tv_nsec - clock[0].tv_nsec;
		time_delay = 1000000000 * temp + temp_n;
	}
	return time_delay;
}


#if 0
void get_xth_value(char (*sbuf)[100], char *ptr, int len, int pos, char deli)
{
	char *row;
	int i, j, k;

	row = sbuf[j];

	for (i = 0, j = 0, k = 0; i < len; i++)
	{
		if (ptr[i] == deli)
		{
			sbuf[j][k] = 0;
			row = sbuf[++j];
			k = 0;
			continue;
		}
		row[k++] = ptr[i];
	}
	return;
}
#endif


#if 0
#define BUFSIZE 4096

int main(void)
{
	char msg_str[10][100];
	FILE *fp;
	char buff[BUFSIZE]; 

	if ((fp = fopen("/sms/wily/test/xml/corechan.map", "r")) == NULL)
	{
		printf("<!> cannot open map_file\n");
		return 1;
	}

	while (fgets(buff, BUFSIZE, fp) != NULL)
	{
		printf("**> %s\n", buff);
		get_xth_value(msg_str, buff, 4, ',');
		printf("->msg_str0 : |%s|\n", msg_str[0]);
		printf("->msg_str1 : |%s|\n", msg_str[1]);
		printf("->msg_str2 : |%s|\n", msg_str[2]);
		printf("->msg_str3 : |%s|\n", msg_str[3]);
	}
}

int tran_r_trim(char *buf)
{	
	int curr_pos;
	int end = buf ? strlen(buf) : 0 ;

	/* buf 예외처리 */
	if( !end )
	{
		return -1;
	}

	char *tmp = (char*)malloc(end);

	/* malloc 예외처리 */
	if( !tmp )
	{
		return -1;
	}

	/* 초기화 */
	memset(tmp, 0x00, end);

	/* malloc 한 tmp 영역에 buf 복사 */
	memcpy(tmp, buf, end);

	/* Right Trim */
	for( ; end > 0; end--)
	{
		if( tmp[end-1] == ' ' )
		{
			continue;
		}
		tmp[end] = 0x00;
		break;
	}

	snprintf(buf, end, "%s", tmp);

	/* tmp 데이터 메모리 해제 */
	free(tmp);

	return 0;
}
#endif
