#include "hash.h"

u_int get_hidx(u_char *key, int len, int mask)
{
	u_int hash = 0;
	int i;

	for (i = 0; i < len; ++i)
	{
		hash += key[i];
		hash += (hash << 10);
		hash ^= (hash >> 6);
	}

	hash += (hash << 3);
	hash ^= (hash >> 11);
	hash += (hash << 15);

	return hash & mask;
}

u_int get_hash_code(u_char *key, int len)
{
	u_int hash = 0;
	int i;

	for (i = 0; i < len; ++i)
	{
		hash += key[i];
		hash += (hash << 10);
		hash ^= (hash >> 6);
	}

	hash += (hash << 3);
	hash ^= (hash >> 11);
	hash += (hash << 15);

	return hash;
}

#if 0
int main(void)
{
	int i = 0;
	int conv_j, conv_k, conv_l;
	int write_qidx;

	unsigned char test[100] = "NHIS00000e12345";

/*
	printf("get_hidx : %u\n", get_hidx(test, 15, (256 * 256) - 1));
*/

	for (i = 0; i < 10000000; i++)
	{
#if 0
		/* get write qidx - 3 digit */
		conv_j = (test[12] - '0') * 100 + \
			 (test[13] - '0') * 10 + \
			 (test[14] - '0');

		conv_k = (test[14] - '0') * 100 + \
			 (test[13] - '0') * 10 + \
			 (test[12] - '0');

		conv_l = (test[13] - '0') * 100 + \
			 (test[14] - '0') * 10 + \
			 (test[12] - '0');

		write_qidx = (conv_j + conv_k + conv_l) & 8;
#endif
		get_hash_code(test, 5);
	}
}
#endif
