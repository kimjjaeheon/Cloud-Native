#include <stdio.h>

#include "tranm_thread.h"

/** by LIANDLI in 2016.06.07
 * tranm_th_join
 * Thread Join (쓰래드 종료 대기)
 *
 * param
 *  - th : Thread ID
 *
 * return
 *  - void
 *
 */
void tranm_th_join(pthread_t th)
{
	if (!th) return;

	if (!pthread_join(th, NULL))
	{
#ifdef _DEBUG
		fprintf(stderr, "(i) thread join completed.");
#endif
	}
	else
	{
#ifdef _DEBUG
		fprintf(stderr, "<!> thread cannot join.");
#endif
	}
	return;
}

/** by LIANDLI in 2016.06.07
 * tranm_th_close
 * Thread cancel (쓰래드 취소)
 *
 * param
 *  - th : Thread ID
 *
 * return
 *  - void
 *
 */void tranm_th_cancel(pthread_t th)
{
	if (!th) return;

	if (pthread_cancel(th))
	{
#ifdef _DEBUG
		fprintf(stderr, "<!> thread cannot cancel.");
#endif
	}
    else
    {
#ifdef _DEBUG
		fprintf(stderr, "<!> thread cancel completed.");
#endif
	}
	return;
}

