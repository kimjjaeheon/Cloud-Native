/*
 * [목적]
 * - 정적 데이터 및 사용자 정의 데이터 모두 처리 하기 위함.
 *
 * 2019.01.07 added by LIANDLI
 *
 * [지원타입]
 * - INT, LONG, FLOAT, PTR(string)
 *   -> 타입은 필요에 의하여 추가 될 수 있다.
 */

#include <stdio.h>
#include <string.h>
#include "glib_qsort.h"
#include "glib_bsearch.h"

#ifdef _SAMPLE
typedef struct _st_test
{
	int i;
	char str[32];
	long l; 
	float f;
}ST_TEST;
#endif

/*
 * qsort 를 위한 int 값 비교 
 * @ a : 비교값 1
 * @ b : 비교값 2
 * @ ptr : 비교값이 위치한 offset
 *   -> 즉, a(or b) 의 위치에서 ptr 의 값만큼 이동한 곳이 비교할 값이 존재 하는 위치 이다.
 * 2019.01.07 added by LIANDLI
 */
static int tranm_comp_int(const void *a, const void *b, void *ptr)
{
#ifdef _SAMPLE
	fprintf(stdout, "COMP_INT : %x, %x, %x\n", a, b, ptr);
#endif

	int *idx = (int*)ptr;

	const char *p1 = (const char *)a;
	const char *p2 = (const char *)b;

	const int *fst = (const int *)(p1+(*idx));
	const int *snd = (const int *)(p2+(*idx));

	return *fst == *snd ? 0 : *fst > *snd ? 1 : -1;
}

/*
 * qsort 를 위한 long 값 비교 
 * @ a : 비교값 1
 * @ b : 비교값 2
 * @ ptr : 비교값이 위치한 offset
 *   -> 즉, a(or b) 의 위치에서 ptr 의 값만큼 이동한 곳이 비교할 값이 존재 하는 위치 이다.
 * 2019.01.07 added by LIANDLI
 */
static int tranm_comp_long(const void *a, const void *b, void *ptr)
{
#ifdef _SAMPLE
	fprintf(stdout, "COMP_LONG : %x, %x, %x\n", a, b, ptr);
#endif
	int *idx = (int*)ptr;
	
	const char *p1 = (const char *)a;
	const char *p2 = (const char *)b;

	const long *fst = (const long *)(p1+(*idx));
	const long *snd = (const long *)(p2+(*idx));

	return *fst == *snd ? 0 : *fst > *snd ? 1 : -1;
}

/*
 * qsort 를 위한 float 값 비교 
 * @ a : 비교값 1
 * @ b : 비교값 2
 * @ ptr : 비교값이 위치한 offset
 *   -> 즉, a(or b) 의 위치에서 ptr 의 값만큼 이동한 곳이 비교할 값이 존재 하는 위치 이다.
 * 2019.01.07 added by LIANDLI
 */
static int tranm_comp_float(const void *a, const void *b, void *ptr)
{
#ifdef _SAMPLE
	fprintf(stdout, "COMP_FLOAT : %x, %x, %x\n", a, b, ptr);
#endif
	int *idx = (int*)ptr;
	
	const char *p1 = (const char *)a;
	const char *p2 = (const char *)b;

	const float *fst = (const float *)(p1+(*idx));
	const float *snd = (const float *)(p2+(*idx));

	return *fst == *snd ? 0 : *fst > *snd ? 1 : -1;
}

/*
 * qsort 를 위한 문자열 값 비교 
 * @ a : 비교값 1
 * @ b : 비교값 2
 * @ ptr : 비교값이 위치한 offset
 *   -> 즉, a(or b) 의 위치에서 ptr 의 값만큼 이동한 곳이 비교할 값이 존재 하는 위치 이다.
 * 2019.01.07 added by LIANDLI
 */
static int tranm_comp_ptr(const void *a, const void *b, void *ptr)
{
#ifdef _SAMPLE
	fprintf(stdout, "COMP_PTR : %x, %x, %x\n", a, b, ptr);
#endif
	int *idx = (int*)ptr;
#ifdef _HPUX
	const char *fst = (const char *)((unsigned long)a+(unsigned long)(*idx));
	const char *snd = (const char *)((unsigned long)b+(unsigned long)(*idx));
#else
	const char *fst = (const char *)(a+(*idx));
	const char *snd = (const char *)(b+(*idx));
#endif

	return strcmp(fst, snd);
}

/*
 * qsort 레퍼 함수
 * @ data : 소팅할 데이터가 담긴 array
 * @ cnt  : array에 담긴 데이터 갯수 
 * @ size : array 1개의 사이즈
 * @ type : 소팅할 데이터 타입
 * @ ptr_idx : 비교값이 위치한 offset
 *   -> 즉, arrya 1개의 데이터 시작위치에서 ptr 의 값만큼 이동한 곳이 비교할 값이 존재 하는 위치 이다.
 *
 * ! 2019.01.07 기준 지원 타입
 *   -> INT, LOG, FLOAT, PTR(string)
 * 2019.01.07 added by LIANDLI
 */
int tranm_array_sort(void* data, int cnt, int size, int type, int *ptr_idx)
{
	if ( !data || cnt <= 0 || size <= 0 || !ptr_idx )
	{
#ifdef _SAMPLE
	fprintf(stdout, "[%s] argument fail : %x, %d, %d, %d, %x\n", __FUNCTION__, data?data:0x00, cnt, size, type, ptr_idx?ptr_idx:0x00);
#endif
		return -1;
	}
#ifdef _SAMPLE
	fprintf(stdout, "FUNC : %s, %d\n", __FUNCTION__, *ptr_idx);
#endif

	switch( type )
	{
		case TRAN_SORT_TYPE_INT   : _quicksort(data, cnt, size, tranm_comp_int, ptr_idx);   break;
		case TRAN_SORT_TYPE_LONG  : _quicksort(data, cnt, size, tranm_comp_long, ptr_idx);  break;
		case TRAN_SORT_TYPE_FLOAT : _quicksort(data, cnt, size, tranm_comp_float, ptr_idx); break;
		case TRAN_SORT_TYPE_PTR   : _quicksort(data, cnt, size, tranm_comp_ptr, ptr_idx);   break;
		default : 
#ifdef _SAMPLE
	fprintf(stdout, "SORT type not eixst: %d\n", type);
#endif
		return -2;
	}
	return 0;
}


/*
 * bsearch 레퍼 함수
 * @ key : array에서 찾을 데이터
 * @ base  : array
 * @ num : array의 최대 값 
 * @ size : array 1개의 사이즈
 * @ type : 소팅할 데이터 타입
 * @ p : 비교값이 위치한 offset
 *   -> 즉, arrya 1개의 데이터 시작위치에서 p 의 값만큼 이동한 곳이 비교할 값이 존재 하는 위치 이다.
 *
 * ! 2019.01.08 기준 지원 타입
 *   -> INT, LOG, FLOAT, PTR(string)
 * 2019.01.08 added by LIANDLI
 */
void *tranm_bsearch(const void *key, const void *base, int num, int size, int type, void *p)
{
	if ( !key || !base || num <= 0 || size <= 0 || !p )
	{
#ifdef _SAMPLE
	fprintf(stdout, "[%s] argument fail : %x, %d, %d, %d, %x\n", __FUNCTION__, key?key:0x00, base?base:0x00, num, size, type, p?p:0x00);
#endif
		return 0x00;
	}

	switch( type )
	{
		case TRAN_SORT_TYPE_INT   : return _tranm_bsearch(key, base, num, size, tranm_comp_int, p);
		case TRAN_SORT_TYPE_LONG  : return _tranm_bsearch(key, base, num, size, tranm_comp_long, p);
		case TRAN_SORT_TYPE_FLOAT : return _tranm_bsearch(key, base, num, size, tranm_comp_float, p);
		case TRAN_SORT_TYPE_PTR   : return _tranm_bsearch(key, base, num, size, tranm_comp_ptr, p);
#ifdef _SAMPLE
		fprintf(stdout, "bsearch type not eixst: %d\n", type);
#endif
		default : break;
	}

	return 0x00;
}



/* 
 * Sample code
 * Build : cc -D_SAMPLE tranm_qsort.c glib_qsort.c
 * Run : ./a.out
 */
#ifdef _SAMPLE
int main()
{
	int i=10;
	int ptr_idx=0;
	ST_TEST st[10] = {
						{10,"jjj", 100, 1.0 }
						,{ 6,"fff", 60, 5.0}
						,{ 4,"ddd", 40, 7.0}
						,{ 7,"ggg", 70, 4.0}
						,{ 9,"iii", 90, 2.0}
						,{ 8,"hhh", 80, 3.0}
						,{ 5,"eee", 50, 6.0}
						,{ 2,"bbb", 20, 9.0}
						,{ 1,"aaa", 10, 10.0}
						,{ 3,"ccc", 30, 8.0}
					};

	/* 소팅 전 어레이 데이터 출력 */
	fprintf(stdout, "[ SORT BEFORE ]\n");
	for(i=0; i<10; i++)
	{
		fprintf(stdout, "%02d) %2d, %s, %lu, %.2f\n", i, st[i].i, st[i].str, st[i].l, st[i].f);
	}
	printf("========================================\n");


	ptr_idx = (void*)(&(st[0].l)) - (void*)st;
	/* 소팅 */
	tranm_array_sort((void*)st, 10, sizeof(ST_TEST), TRAN_SORT_TYPE_LONG, &ptr_idx);

	fprintf(stdout, "ptr_idx [%x]\n", &ptr_idx);

	/*
	ptr_idx = (void*)(&(st[0].str)) - (void*)st;
	tranm_array_sort((void*)st, 10, sizeof(ST_TEST), TRAN_SORT_TYPE_PTR, &ptr_idx);
	*/

	/* 소팅 후 어레이 데이터 출력 */
	fprintf(stdout, "[ SORT AFTER ]\n");
	for(i=0; i<10; i++)
	{
		fprintf(stdout, "%02d) %2d, %s, %lu, %.2f\n", i, st[i].i, st[i].str, st[i].l, st[i].f);
	}

	ST_TEST x = {7, "ggg", 70, 4.0};
	ST_TEST *p = NULL;

	/* bsearch */
	p = (ST_TEST*)tranm_bsearch(&x, st, 10, sizeof(ST_TEST), TRAN_SORT_TYPE_LONG, &ptr_idx);

	if(p)
		fprintf(stdout, "%x -> [%d-%s]\n", p, p->i, p->str);
	else
		fprintf(stdout, "search fail\n");
}
#endif
