#include "tcp_base.h"

#define MAX_PENDING  5

int create_tcp_server_session(char *srv_ipaddr, int srv_port)
{
	int sock_opt;
	int srv_sockfd;
	struct sockaddr_in srv_addr;

	struct timeval tmo = {1, 0}; /* 1:sec, 0:msec */

	if ((srv_sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{
		/*
		perror("socket failed");
		*/
		exit (1);
	}

	/* Socket receive timeout */
	if (setsockopt(srv_sockfd, SOL_SOCKET, SO_RCVTIMEO, (void *)&tmo, sizeof(tmo)) == -2)
	{
		close(srv_sockfd);
		/*
		perror("setsockopt failed");
		*/
		exit(1);
	}

	sock_opt = 1;

	/* Socket address reuse */
	if (setsockopt(srv_sockfd, SOL_SOCKET, SO_REUSEADDR, (void *)&sock_opt,
				sizeof(sock_opt)) == -1)
	{
		close(srv_sockfd);
		/*
		perror("setsockopt failed");
		*/
		exit(1);
	}

	bzero((char*)&srv_addr, sizeof(srv_addr));

	srv_addr.sin_family = AF_INET;
	srv_addr.sin_port = htons(srv_port);

	if (srv_ipaddr)
	{
		srv_addr.sin_addr.s_addr = inet_addr(srv_ipaddr);
	}
	else
	{
		srv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	}

	if (bind(srv_sockfd, (struct sockaddr *) &srv_addr, sizeof (srv_addr)) == -1)
	{
		close(srv_sockfd);
		/*
		perror("bind failed");
		*/
		exit(1);
	}

	if (listen(srv_sockfd, MAX_PENDING) == -1)
	{
		close(srv_sockfd);
		/*
		perror("listen failed");
		*/
		exit(1);
	}

	return srv_sockfd;
}


int accept_tcpserver_connection(int srv_sockfd, struct sockaddr_in *cli_addr)
{
	int cli_sockfd;

#ifdef _AIX
	socklen_t addr_len = sizeof(struct sockaddr_in);
#else
	int addr_len = sizeof(struct sockaddr_in);
#endif

	if ((cli_sockfd = accept(srv_sockfd, (struct sockaddr *) cli_addr, &addr_len)) == -1)
	{
		close(srv_sockfd);
		/*
		perror("accept failed");
		*/
		exit(1);
	}

	return cli_sockfd;
}

#ifdef _MAGIC_BIT
int magic_bit_check(int sockfd, const unsigned char* str)
{
	int recv_len=0;
	unsigned char magic_bit[MAGIC_BIT_SIZE];

	if ( str )
	{
		memcpy(magic_bit, str, MAGIC_BIT_SIZE);
	}
	else
	{
		if ( (recv_len=recv_tcp_data(sockfd, magic_bit, MAGIC_BIT_SIZE)) <= 0 )
		{
			return -1;
		}
	}

	return MAGIC_BIT_CHECK(magic_bit);
}
#endif


#if 0
int send_tcp_data(int sock_fd, void *ptr, int len)
{
	int send_len;

	if ((send_len = send(sock_fd, ptr, len, 0)) == -1)
	{
		/*
		perror ("send error");
		*/
		return -1;
	}
								    
	return send_len;
}
#endif


int send_tcp_data(int sock_fd, void *ptr, int len)
{
	int nleft = len, nwritten;

	while (nleft > 0)
	{
		nwritten = write(sock_fd, ptr, nleft);
		if (nwritten <= 0)
		{
			return (nwritten);
		}

		nleft -= nwritten;
		ptr = (char *)ptr + nwritten;
	}
	return (len - nleft);
}


int recv_tcp_data_timeout(int sock_fd, void *ptr, int len, int timeout)
{
	fd_set fds;
	int n;
	struct timeval tv;
	int recv_len, err_len, add_len;

	/* set up the file descripter set */
	FD_ZERO(&fds);
	FD_SET(sock_fd, &fds);

	/* set up the struct timeval for the timeout */
	tv.tv_sec = timeout;
	tv.tv_usec = 0;

	/* wait until timeout or data received */
	if ((n = select(sock_fd + 1, &fds, NULL, NULL, &tv)) <= 0)
	{
		if (n == 0) return TIMEOUT_ERR;
		if (n == -1) return GENERAL_ERR;
	}

	while (1)
	{
		if ((recv_len = read(sock_fd, ptr, len)) == len)
		{
			break;
		}

		if (recv_len > 0)
		{
			/*
			printf("illegal_len = %d, ", recv_len);
			*/
			err_len = len - recv_len;

			while (1)
			{
				/*
					 미 수신 추가 데이터 수신
				*/
				if ((add_len = read(sock_fd, (char *)ptr + recv_len, err_len)) == err_len)
				{
					printf("#%d bytes are added!\n", err_len);
					return len;
				}
				
				if (add_len > 0)
				{
					recv_len += add_len;
					err_len = len - recv_len;
				}
				else
				{
					printf("read error!!, add_len : %d", add_len);
					break;
				}
			}
		}
		else
		{
			break;
/*
			if (errno != EINTR) break;
*/
		}
	}
	return recv_len;
}


int recv_tcp_data(int sock_fd, void *ptr, int len)
{   
	int recv_len, err_len, add_len;

	while (1)
	{
		if ((recv_len = read(sock_fd, ptr, len)) == len)
		{
			break;
		}

		if (recv_len > 0)
		{
			/*
			printf("illegal_len = %d, ", recv_len);
			*/
			err_len = len - recv_len;

			while (1)
			{
				/*
					 미 수신 추가 데이터 수신
				*/
				if ((add_len = read(sock_fd, (char *)ptr + recv_len, err_len)) == err_len)
				{
/*
					printf("%d \n", recv_len);
					printf("#%d bytes are added! \n", err_len);
*/
					return len;
				}
				
				if (add_len > 0)
				{
					recv_len += add_len;
					err_len = len - recv_len;
				}
				else
				{
/*
					printf("read error!!, add_len : %d", add_len);
*/
					break;
				}
			}
		}
		else
		{
			break;
/*
			if (errno != EINTR) break;
*/
		}
	}
	return recv_len;
}



int create_tcp_client_session(char *svr_ipaddr, int svr_port, int non_block_mode)
{
	int sock_fd;
	struct hostent *hp;
	struct sockaddr_in addr;

#ifdef _AIX
	socklen_t flag, flag_len = sizeof(flag);
#else
	int flag, flag_len = sizeof(flag);
#endif

	if (!(hp = gethostbyname(svr_ipaddr))) return -1;

	if ((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		/*
		perror("socket error");
		*/
	}

	/* clear out address structures */
	memset((char *) &addr, 0, sizeof (addr));

	/* Set up the destination address to which we will connect */
	addr.sin_family = AF_INET;
	/*
	memcpy(&addr.sin_addr, hp->h_addr, sizeof (addr.sin_addr));
	*/
	memcpy(&addr.sin_addr, hp->h_addr_list[0], sizeof (addr.sin_addr));
	addr.sin_port = htons(svr_port);

	/* set socket to nodelay */
	if (getsockopt(sock_fd, IPPROTO_TCP, TCP_NODELAY, &flag, &flag_len) < 0)
	{
		close(sock_fd);
		perror("getsockopt");
		return -1;
	}

	flag = 1;

	if (setsockopt(sock_fd, IPPROTO_TCP, TCP_NODELAY, (char *) &flag, sizeof(int)) == -1)
	{
		close(sock_fd);
		/*
		perror("setsockopt");
		*/
		return -1;
	}

	if ((flag = fcntl(sock_fd, F_GETFL, 0)) < 0)
	{
		close(sock_fd);
		/*
		perror("fcntl error");
		*/
		return -1;
	}

	if (non_block_mode)
	{
		flag |= O_NONBLOCK;
		if (fcntl(sock_fd, F_SETFL, flag) < 0)
		{
			close(sock_fd);
			/*
			perror("fcntl error");
			*/
			return -1;
		}
	}

	if (connect(sock_fd, (struct sockaddr *)&addr, sizeof(addr)) == -1) 
	{
		close(sock_fd);
		/*
		perror("connect error");
		*/
		return -1;
	}

	return sock_fd;
}

void close_tcp_session(int sock_fd)
{
    if (sock_fd != -1)
	{
		shutdown(sock_fd, 2);
		close(sock_fd);
	}
}   

int url_to_ipaddr(char* url, char* ipaddr)
{
	int i=0;

	struct hostent *host;
	struct in_addr addr;

	if ( !url || !strlen(url) )
	{
		return -1;
	}

	host = gethostbyname (url);

	if(!host)
	{
		fprintf(stderr, "host error\n");
		return -2;
	}

	addr.s_addr = *((u_long *)(host->h_addr_list[0]));
	fprintf(stderr, "address : %s, url:%s\n", inet_ntoa(addr), url);

	snprintf(ipaddr, 20, "%s", inet_ntoa(addr));

	while(host->h_addr_list[i] != NULL)
	{
	addr.s_addr = *((u_long *)(host->h_addr_list[i]));
	printf("address : %s\n", inet_ntoa(addr));
	i++;
	}
	return 0;

}

#if 0
typedef struct {
	int     send_size;
	int     recv_size;
} MSG_SIZE;



int main(void)
{
	MSG_SIZE sbuf, rbuf;
	int sock_fd, send_len;

	sbuf.send_size = 8;
	sbuf.recv_size = 8;

	rbuf.send_size = 0;
	rbuf.recv_size = 0;

	sock_fd = create_tcp_client_session("172.19.99.1", 8888, 0);
#if 0
	send_len = send_tcp_clent_data(sock_fd, &sbuf, sizeof(sbuf));
	printf("sbuf.send_size = %d\n", sbuf.send_size);
	printf("sbuf.recv_size = %d\n", sbuf.recv_size);
	recv_tcp_client_data(sock_fd, &rbuf, sizeof(rbuf));

	printf("rbuf.send_size = %d\n", rbuf.send_size);
	printf("rbuf.recv_size = %d\n", rbuf.recv_size);
#endif

	close_tcp_session(sock_fd);

	return 1;
}
#endif
