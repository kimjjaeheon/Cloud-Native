#include <stdio.h>
#include "tranm_bsearch.h"
#include "tranm_qsort.h"
/*
 * A generic implementation of binary search for the Linux kernel
 *
 * Copyright (C) 2008-2009 Ksplice, Inc.
 * Author: Tim Abbott <tabbott@ksplice.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; version 2.
 */

void *tranm_bsearch(const void *key, const void *base, int num, int size, int type, void *p)
{
	if ( !key || !base || !p )
	{
		return 0x00;
	}

	switch( type )
	{
		case TRAN_SORT_TYPE_INT   : return _tranm_bsearch(key, base, num, size, tran_comp_int, p);
		case TRAN_SORT_TYPE_LONG  : return _tranm_bsearch(key, base, num, size, tran_comp_long, p);
		case TRAN_SORT_TYPE_FLOAT : return _tranm_bsearch(key, base, num, size, tran_comp_float, p);
		case TRAN_SORT_TYPE_PTR   : return _tranm_bsearch(key, base, num, size, tran_comp_ptr, p);
#ifdef _SAMPLE
		fprintf(stdout, "bsearch type not eixst: %d\n", type);
#endif
		default : break;
	}
	
	return 0x00;
}


/*
 * bsearch - binary search an array of elements
 * @key: pointer to item being searched for
 * @base: pointer to first element to search
 * @num: number of elements
 * @size: size of each element
 * @cmp: pointer to comparison function
 *
 * This function does a binary search on the given array.  The
 * contents of the array should already be in ascending sorted order
 * under the provided comparison function.
 *
 * Note that the key need not have the same type as the elements in
 * the array, e.g. key could be a string and the comparison function
 * could compare the string with the struct's name field.  However, if
 * the key and elements in the array are of the same type, you can use
 * the same comparison function for both sort() and bsearch().
 */
void *_tranm_bsearch(const void *key, const void *base, int num, int size, __comp cmp, void *p)
{

#ifdef _SAMPLE
	fprintf(stdout, "key:%x, base:%x, cnt:%d, size:%d, func:%x, ptr_idx:%d\n", key, base, num, size, cmp, p==NULL?0:*((int*)p));
#endif
	const char *pivot;
	int result;

	while (num > 0) {
		pivot = base + (num >> 1) * size;
		/*
		fprintf(stdout, "key[%s], pivot[%s]\n", key, pivot+4);
		*/
		result = cmp(key, pivot, p);

		if (result == 0)
			return (void *)pivot;

		if (result > 0) {
			base = pivot + size;
			num--;
		}
		num >>= 1;
	}

	return 0x00;
}

