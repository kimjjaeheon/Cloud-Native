#include "moni_log_printf.h"

#define MAX_PATH_LEN 256

static FILE *log_file;
static int cur_day = 0;

static char date_str[32];
static char time_str[32];
static char log_dir[256];
static char log_title[256];

static void check_day(void)
{
	time_t t;
	struct tm tm;

	time(&t);
	tm = *localtime(&t);

	if (cur_day != tm.tm_yday)
	{
		close_moni_log();
		open_moni_log(NULL, NULL);
	}
}


static char *get_cur_date(void)
{
	struct tm *tm;
	time_t now;
	time(&now);
	tm = localtime(&now);
	cur_day = tm->tm_yday;
	strftime(date_str, sizeof(date_str), "%Y%m%d", tm);
	return date_str;
}


static char *get_cur_time(void)
{
	struct timeval curr;
	gettimeofday(&curr, NULL);
	strftime(time_str, 32, "%m-%d %T  ", localtime((time_t*)&curr.tv_sec));
	return time_str;
}


/* open the log file. */
int open_moni_log(const char *dir, const char *title)
{
	char full_log_fn[MAX_PATH_LEN];

	if (log_file)
	{
		return 0;
	}

	if (dir)
	{
		strcpy(log_dir, dir);
	}
	if (title)
	{
		strcpy(log_title, title);
	}

	sprintf(full_log_fn, "%s/%s.%s", log_dir, log_title, get_cur_date());

	log_file = fopen(full_log_fn, "a");

	if (log_file)
	{
		setbuf(log_file, NULL);
	}

	return (log_file != NULL) ? 0 : -1;
}


/* close the log file. */
void close_moni_log(void)
{
	if (!log_file)
	{
		return;
	}
	fclose(log_file);
	log_file = NULL;
	return;
}

#define LOG_MSG_LEN 4096

void moni_log_printf(char *fmt, ...)
{
	int nbuff;
	char buff[LOG_MSG_LEN + 1];
	va_list args;

	va_start(args, fmt);
	nbuff = vsnprintf(buff, LOG_MSG_LEN, fmt, args);
	va_end(args);

	if (nbuff < 1) return;

	check_day();

	if (log_file)
	{
		fputs(get_cur_time(), log_file);
		fputs(buff, log_file);
		fputc('\n', log_file);
	}
	return;
}
