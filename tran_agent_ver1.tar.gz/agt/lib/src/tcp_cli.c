#include "tcp_cli.h"

int create_tcp_client_session(char *svr_ipaddr, int svr_port, int non_block_mode)
{
	int sock_fd, sock_opt;
	struct hostent *hp;
	struct sockaddr_in addr;
	int flag, flag_len = sizeof(flag);

	if (!(hp = gethostbyname(svr_ipaddr))) return -1;

	if ((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		/*
		perror("socket error");
		*/
	}

	sock_opt = 1;

	/* clear out address structures */
	memset((char *) &addr, 0, sizeof (addr));

	/* Set up the destination address to which we will connect */
	addr.sin_family = AF_INET;
	memcpy(&addr.sin_addr, hp->h_addr, sizeof (addr.sin_addr));
	addr.sin_port = htons(svr_port);

	/* set socket to nodelay */
	if (getsockopt(sock_fd, IPPROTO_TCP, TCP_NODELAY, &flag, (socklen_t*)&flag_len) < 0)
	{
		close(sock_fd);
		/*
		perror("getsockopt");
		*/
		return -1;
	}

	flag = 1;

	if (setsockopt(sock_fd, IPPROTO_TCP, TCP_NODELAY, (char *) &flag, sizeof(int)) == -1)
	{
		close(sock_fd);
		/*
		perror("setsockopt");
		*/
		return -1;
	}

	if ((flag = fcntl(sock_fd, F_GETFL, 0)) < 0)
	{
		close(sock_fd);
		/*
		perror("fcntl error");
		*/
		return -1;
	}

	if (non_block_mode)
	{
		flag |= O_NONBLOCK;
		if (fcntl(sock_fd, F_SETFL, flag) < 0)
		{
			close(sock_fd);
			/*
			perror("fcntl error");
			*/
			return -1;
		}
	}

	if (connect(sock_fd, (struct sockaddr *)&addr, sizeof(addr)) == -1) 
	{
		close(sock_fd);
		/*
		perror("connect error");
		*/
		return -1;
	}

	return sock_fd;
}


void close_tcp_client_session(int sock_fd)
{
	if (sock_fd != -1) close(sock_fd);
}


int send_tcp_client_data(int sock_fd, void *ptr, int len)
{
	int send_len;
	if ((send_len = send(sock_fd, ptr, len, 0)) == -1)
	{
		/*
		perror ("send error");
		*/
		return -1;
	}

	return send_len;
}


int recv_tcp_client_data(int sock_fd, void *ptr, int len)
{
	int recv_len, err_len, add_len;

	while (1)
	{
		if ((recv_len = read(sock_fd, ptr, len)) == len)
		{
			break;
		}

		if (recv_len > 0)
		{
			printf("illegal_len = %d, ", recv_len);
			err_len = len - recv_len;

			while (1)
			{
				// 미 수신 추가 데이터 수신
				if ((add_len = read(sock_fd, (char *)ptr + recv_len, err_len)) == err_len)
				{
					printf("#%d bytes are added!\n", err_len);
					return len;
				}
				recv_len += add_len;
				err_len = len - recv_len;
			}
		}
		else
		{
			/*
			perror("recv error");
			*/
			break;
		}

	}
	return recv_len;
}

#if 0
#define TRAN_LOG_QSIZE  300

#define MAX_BLOCK_LOG  4

typedef struct
{
    char tran_log[TRAN_LOG_QSIZE];
} LOG;

typedef struct
{
	int log_num;
	LOG block_logs[MAX_BLOCK_LOG];
} LOG_BODY;



int main(void)
{
	LOG_BODY sbuf, rbuf;
	int sock_fd, send_len, send_cnt = 0;

	sbuf.log_num = 4;

	sock_fd = create_tcp_client_session("127.0.0.1", 8888, 0);

	printf("send size: %d\n", sizeof(LOG_BODY));

	for(;send_cnt < 10000; send_cnt++)
	{
		send_len = send_tcp_clent_data(sock_fd, &sbuf, sizeof(sbuf));
		recv_tcp_client_data(sock_fd, &rbuf, sizeof(int));
	}
	printf("send complete\n");
	close_tcp_client_session(sock_fd);

	return 1;
}
#endif
