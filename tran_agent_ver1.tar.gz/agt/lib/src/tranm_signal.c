#include <stdio.h>
#include <signal.h>
#include "tranm_signal.h"

void tran_thread_sig_ignore()
{
	/* signal ignore 처리 */
	sigset_t set;
	sigfillset(&set);
	pthread_sigmask(SIG_SETMASK, &set, NULL);
}
