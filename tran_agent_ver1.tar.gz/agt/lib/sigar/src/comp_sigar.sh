#!/usr/bin/bash

rm sigar_ln.c
rm sigar_os.h

if [ "$1" = "LINUX" ] || [ "$1" = "AIX" ] || [ "$1" = "linux" ] || [ "$1" = "aix" ]; then
	echo "****************************"
	echo "**                       "
	echo "**   COMPILE MODE -> $1  "
	echo "**                       "
	echo "****************************"
else
	echo "usage : $0 os (linux, aix, sol, hpux or LINUX, AIX, SOL, HPUX)"
	exit
fi


if [ "$1" = "linux" ] || [ "$1" = "LINUX" ]; then
	ln -s ./os/linux/linux_sigar.c sigar_ln.c
	ln -s ./os/linux/sigar_os.h sigar_os.h
	make -f makefile.linux clean all install
elif [ "$1" = "aix" ] || [ "$1" = "AIX" ]; then
	ln -s ./os/aix/aix_sigar.c sigar_ln.c
	ln -s ./os/aix/sigar_os.h sigar_os.h
	make -f makefile.aix clean all install
elif [ "$1" = "hpux" ] || [ "$1" = "HPUX" ]; then
	ln -s ./os/hpux/hpux_sigar.c sigar_ln.c
	ln -s ./os/hpux/sigar_os.h sigar_os.h
	make -f makefile.hpux clean all install
elif [ "$1" = "sol" ] || [ "$1" = "SOL" ]; then
	ln -s ./os/sol/solaris_sigar.c sigar_ln.c
	ln -s ./os/sol/sigar_os.h sigar_os.h
	make -f makefile.sol clean all install
fi
