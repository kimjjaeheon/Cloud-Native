#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#ifdef _HPUX
#include <sys/mpctl.h>
#endif

#ifdef _AIX
#include <libperfstat.h>
#endif

#include "cpu.h"
#include "sigar_format.h"

/* CPU 정보 수집 */
int cpu_info(sigar_t *t, ST_TRAN_SYS_INFO *sys_info) {
    int ret;

#ifndef _AIX
    sigar_cpu_t cpu;
	static sigar_cpu_t old;
#else
	perfstat_cpu_total_t cpu;
	static perfstat_cpu_total_t old;
#endif
	sigar_cpu_perc_t perc;

#ifndef _AIX
	memset(&cpu, 0x00, sizeof(sigar_cpu_t));
#else
	memset(&cpu, 0x00, sizeof(perfstat_cpu_total_t));
#endif

	memset(&perc, 0x00, sizeof(sigar_cpu_perc_t));

#ifndef _AIX
    if (SIGAR_OK == (ret = sigar_cpu_get(t, &cpu))) 
#else
    if (SIGAR_OK == (ret = sigar_cpu_get(t, &cpu))) 
#endif
	{
#ifdef _AIX
		if ( old.user == 0 )
		{
			memcpy(&old, &cpu, sizeof(perfstat_cpu_total_t));
		}
#endif
		sigar_cpu_perc_calculate(&old, &cpu, &perc);
		unsigned long cs;
		unsigned long cu;
		unsigned long cw;
		unsigned long ci;

/*
		cs = (cpu.sys - old.sys) * 100 / ()
*/
#ifdef _DEBUG
		printf("********************\n");
		printf("*  CPU INFO START  *\n");
		printf("********************\n");
#ifndef _AIX
		printf("-  user : %.2f \n", perc.user*100);
		printf("-  sys  : %.2f \n", perc.sys*100 );
		printf("-  nice : %.2f \n", perc.nice*100);
		printf("-  idle : %.2f \n", perc.idle*100);
		printf("-  wait : %.2f \n", perc.wait*100);
		printf("-  irq  : %.2f \n", perc.irq *100);
		printf("-  soft_irq : %.2f \n", perc.soft_irq*100);
		printf("-  stolen : %.2f \n", perc.stolen*100);
		printf("-  used  : %.2f \n", perc.combined*100);
#else
		printf("-  user : %.2f \n", perc.user);
		printf("-  sys  : %.2f \n", perc.sys );
		printf("-  nice : %.2f \n", perc.nice);
		printf("-  idle : %.2f \n", perc.idle);
		printf("-  wait : %.2f \n", perc.wait);
		printf("-  irq  : %.2f \n", perc.irq );
		printf("-  soft_irq : %.2f \n", perc.soft_irq);
		printf("-  stolen : %.2f \n", perc.stolen);
		printf("-  used  : %.2f \n", perc.combined);
#endif
		printf("-  core count : %d\n", cpu_core_cnt(t));
		printf("--------------------\n");
/*
		printf("- user) old: %lu  cur: %lu\n", old.user, cpu.user);
		printf("- sys ) old: %lu  cur: %lu\n", old.sys, cpu.sys);
		printf("- nice) old: %lu  cur: %lu\n", old.nice, cpu.nice);
		printf("- idle) old: %lu  cur: %lu\n", old.idle, cpu.idle);
		printf("- wait) old: %lu  cur: %lu\n", old.wait, cpu.wait);
*/
		printf("********************\n");
		printf("*  CPU INFO END    *\n");
		printf("********************\n\n\n");
#endif

#ifndef _AIX
		sys_info->cpu.idle     = perc.idle*100;
		sys_info->cpu.used     = perc.combined*100;
		sys_info->cpu.core_cnt = cpu_core_cnt(t);
		sys_info->cpu.user     = perc.user*100;
		sys_info->cpu.sys      = perc.sys*100;
		sys_info->cpu.nice     = perc.nice*100;
		sys_info->cpu.wait     = perc.wait*100;
		sys_info->cpu.irq      = perc.irq*100;
		sys_info->cpu.soft_irq = perc.soft_irq*100;
		sys_info->cpu.stolen   = perc.stolen*100;
#else
		sys_info->cpu.idle     = perc.idle;
		sys_info->cpu.used     = perc.combined;
		sys_info->cpu.core_cnt = cpu_core_cnt(t);
		sys_info->cpu.user     = perc.user;
		sys_info->cpu.sys      = perc.sys;
		sys_info->cpu.nice     = perc.nice;
		sys_info->cpu.wait     = perc.wait;
		sys_info->cpu.irq      = perc.irq;
		sys_info->cpu.soft_irq = perc.soft_irq;
		sys_info->cpu.stolen   = perc.stolen;
#endif

	}
	else
	{
    	return ret ? -1 : 0;
	}

#ifndef _AIX
	memcpy(&old, &cpu, sizeof(sigar_cpu_t));
#else
	memcpy(&old, &cpu, sizeof(perfstat_cpu_total_t));
#endif

    return ret ? -1 : 0;
}

/* CPU Core count 추출 */
int cpu_core_cnt(sigar_t *t)
{
#if 0
	printf("***************************\n");
	printf("*  TOTAL CORE COUNT : %03d *\n", sigar_cpu_core_count(t));
	printf("***************************\n\n\n");

	return sigar_cpu_core_count(t);
#endif
#ifdef _HPUX
	return mpctl(MPC_GETNUMSPUS_SYS, NULL, NULL);
#else
	return sysconf(_SC_NPROCESSORS_ONLN);
#endif
}

/* CPU core 정보 추출 */
int cpu_core_info(sigar_t *t)
{
    sigar_cpu_list_t cpulist;
	sigar_cpu_t old;
	sigar_cpu_perc_t perc;
    size_t idx;
    int ret;

	memset(&cpulist, 0x00, sizeof(sigar_cpu_list_t));
    if (SIGAR_OK != (ret = sigar_cpu_list_get(t, &cpulist))) {
		fprintf(stderr, "ret = %d (%s)\n", ret, sigar_strerror(t, ret));
		return ret;
    }

#ifdef _DEBUG
	printf("*************************\n");
	printf("*  CPU LIST INFO START  *\n");
	printf("*************************\n");
	printf("-  number : %lu \n", cpulist.number);
	printf("-  size	  : %lu \n", cpulist.size);
#endif

    for (idx = 0; idx < cpulist.number; idx++) {
		memset(&old, 0x00, sizeof(sigar_cpu_t));
		memset(&perc, 0x00, sizeof(perc));
        sigar_cpu_t cpu = cpulist.data[idx];
		sigar_cpu_perc_calculate(&old, &(cpulist.data[idx]), &perc);
#ifdef _DEBUG
		printf("   [%d번째 CORE] \n", idx);
		printf("   -  user : %.2f \n", perc.user*100);
		printf("   -  sys  : %.2f \n", perc.sys *100);
		printf("   -  nice : %.2f \n", perc.nice*100);
		printf("   -  idle : %.2f \n", perc.idle*100);
		printf("   -  wait : %.2f \n", perc.wait*100);
		printf("   -  irq  : %.2f \n", perc.irq *100);
		printf("   -  soft_irq : %.2f \n", perc.soft_irq*100);
		printf("   -  stolen : %.2f \n", perc.stolen*100);
		printf("   -  total : %.2f \n", perc.combined*100);
		printf("------------------------------\n");
#endif
    }
#ifdef _DEBUG
	printf("*************************\n");
	printf("*  CPU LIST INFO END    *\n");
	printf("*************************\n\n\n");
#endif

    sigar_cpu_list_destroy(t, &cpulist);

    return ret;
}

