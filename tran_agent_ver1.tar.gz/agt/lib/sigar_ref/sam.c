#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include "sigar.h"
#include "cpu.h"
#include "mem.h"
#include "proc.h"
#include "net.h"
#include "disk.h"
#include "os.h"

#define MAX_DISK_LIST 100
char disk_dev_name[1024];

int main(int argc_, char** argv_)
{
	int ret;
	int token_cnt;
	sigar_t *t;
	ST_TRAN_SYS_INFO sys_info;
	char *disk_dev_name_list[MAX_DISK_LIST];

	fprintf(stdout, "181818181818181818181818\n");
	sleep(1);
    if( argc_ != 2)
	{
		fprintf(stderr, "usage : %s option\n", argv_[0]);
		fprintf(stderr, "(option : all, cpu, os, disk, mem, proc, conn)\n");
		exit(0);
	}


	memset(&sys_info, 0x00, sizeof(ST_TRAN_SYS_INFO));
	memset(disk_dev_name, 0x00, sizeof(disk_dev_name));

	sprintf(disk_dev_name, "/dev/mapper/tran-agt01,/dev/mapper/tranlog-log01,devtmpfs");

	sys_info.disk_count = sigar_ref_string_token(disk_dev_name, ",", disk_dev_name_list);

	/* 
	 * sigar open
	 * 시스템 정보 수집 라이브러리 사용을 위한 함수
	 * 꼭! 호출 해야 한다.
	 * 정보 수집 완료 후 해지 해줘야 한다.
	 */
	if( SIGAR_OK != (ret=sigar_open(&t)) )
	{
		fprintf(stderr, "siagr open fail");
		fprintf(stderr, "ret = %d (%s)\n", ret, sigar_strerror(t, ret));
		exit(0);
	}

	/* 전체 정보 보기 */
	if( !(strcmp(argv_[1], "all")) )
	{
		cpu_info(t, &sys_info);       /* CPU 전체에 대한 정보 수집         호출   */ 
		cpu_core_cnt(t);   /* CPU 의 전체 코어 수 수집             */
		cpu_core_info(t);  /* CORE 별 정보수집                     */

		
		proc_stat_info(t, &sys_info); /* 프로세스 전체에 대한 요약정보 수집   */
		proc_list_info(t); /* 프로세스 개별에 대한 정보 수집       */

		net_conn_info(t, &sys_info);  /* 네트워크 연결정보 수집               */
		disk_info(t, &sys_info, disk_dev_name_list);      /* 디스크 정보 수집                     */
		os_info(t, &sys_info);        /* OS 정보 수집                      호출   */
		mem_info(t, &sys_info);       /*메로리 정보 수집                   호출   */
	}
	/* 개별정보 보기 */
	else
	{

		if( !strcmp(argv_[1], "cpu") )
		{
			cpu_info(t, &sys_info);
			cpu_core_cnt(t);
			cpu_core_info(t);
		}
		else if( !strcmp(argv_[1], "mem") )
			mem_info(t, &sys_info);
		else if( !strcmp(argv_[1], "proc") )
		{
			int i, idx;
			pid_t pid[3]={125619, 1067, 51660};
			unsigned long mem_rss[3]={0x00,};
			double cpu_ratio[3]={0x00,};
#if 0
			for( idx=0; idx<10; idx++ )
			{
				proc_cpu_mem_info(p, pid, mem_rss, cpu_ratio, 3);
				proc_cpu_mem_info(p, pid, mem_rss, cpu_ratio, 3);
				proc_cpu_mem_info(p, pid, mem_rss, cpu_ratio, 3);

				for(i=0; i<3; i++)
				{
					printf("cpu_mem_info [%lu,  %f,  %lu]\n", pid[i], cpu_ratio[i], mem_rss[i]);
				}
				sleep(3);
			}
#endif

			proc_list_info(t);
			/*
			proc_stat_info(t, &sys_info);
			sleep(3);
			proc_list_info(t);
			*/
		}
		else if( !strcmp(argv_[1], "conn") )
		{
			net_conn_info(t, &sys_info);
			net_interface_stat(t, "enp1s0f0", &sys_info);
		}
		else if( !strcmp(argv_[1], "disk") )
			disk_info(t, &sys_info, disk_dev_name_list);
		else if( !strcmp(argv_[1], "os") )
			os_info(t, &sys_info);
		else
			fprintf(stderr, "type is not exist\n");
	}

	/*
	 * 시스템 정보 수집 완료후 자원 해지
	 */
	sigar_close(t);

	printf("*******************\n");
	printf("*   SYSTEN INFO   *\n");
	printf("*******************\n");
	printf(" @ CPU\n");
	printf(" - idle     : %.2f\n", sys_info.cpu.idle);
	printf(" - used     : %.2f\n", sys_info.cpu.used);
	printf(" - core_cnt : %d\n", sys_info.cpu.core_cnt);
	printf(" -------------------------\n");
	printf(" @ MEM\n");
	printf(" - total : %.2f\n", sys_info.mem.total);
	printf(" - used  : %.2f\n", sys_info.mem.used);
	printf(" - free  : %.2f\n", sys_info.mem.free);
	printf(" -------------------------\n");
	printf(" @ OS\n");
	printf(" - name        : %s\n", sys_info.os.name);
	printf(" - kernel_ver  : %s\n", sys_info.os.ver);
	printf(" - machine     : %s\n", sys_info.os.machine);
	printf(" - vendor      : %s\n", sys_info.os.vendor);
	printf(" - venddor_ver : %s\n", sys_info.os.vendor_ver);
	printf(" -------------------------\n");
	printf(" @ DISK\n");
	int idx;
	for(  idx=0; idx < sys_info.disk_count; idx++)
	{
		printf("   [%d 번 디스크]\n", idx);
		printf("   - ratio         : %.0f%\n", sys_info.disk[idx].ratio*100);
		printf("   - dir_name      : %s\n", sys_info.disk[idx].dir_name);
		printf("   - dev_name      : %s\n", sys_info.disk[idx].dev_name);
		printf("   - type_name     : %s\n", sys_info.disk[idx].type_name);
		printf("   - sys_type_name : %s\n", sys_info.disk[idx].sys_type_name);
		printf("   - option        : %s\n", sys_info.disk[idx].option);
		printf("   - total         : %s MB\n", sys_info.disk[idx].total);
		printf("   - free          : %s MB\n", sys_info.disk[idx].free);
		printf("   - used          : %s MB\n", sys_info.disk[idx].used);
	}

	/* disk 정보는 동적 처리이기 때문에 사용 후 해제 한다. */
	free(sys_info.disk);


	return 0;
}
