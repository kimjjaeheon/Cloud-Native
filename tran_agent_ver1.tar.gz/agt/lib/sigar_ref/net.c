#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "net.h"
#include "util.h"

int net_interface_info(sigar_t *t, ST_TRAN_SYS_INFO *sys_info)
{
	int i;
	static int if_cnt;

	sigar_net_interface_list_t iflist;
	memset(&iflist, 0x00, sizeof(sigar_net_interface_list_t));

	sigar_net_interface_list_get(t, &iflist);

	/* interface 수가 0이면 즉시 리턴 */
	if ( !(iflist.number) )
	{
		if ( iflist.data )
		{
			free(iflist.data);
		}
		return -1;
	}

	/* if_cnt 가 0이면 sigar를 통해 수집한 if 갯수 변경 */
	if ( !if_cnt )
	{
		if_cnt = iflist.number;
	}

	if ( !(sys_info->if_list) )
	{
		sys_info->if_list = (ST_TRAN_INTERFACE_INFO*)malloc(sizeof(ST_TRAN_INTERFACE_INFO)*iflist.number);

		if ( !sys_info->if_list )
		{
			return -2;
		}

		memset(sys_info->if_list, 0x00, sizeof(ST_TRAN_INTERFACE_INFO)*iflist.number);
	}

	/* if_cnt 와 iflist.number의 값이 다르면 interface 갯수에 변경이 발생한 것으로 데이터를 초기화 한 후 리턴 한다. */
	if ( if_cnt != iflist.number )
	{
		if( sys_info->if_list )
		{
			free(sys_info->if_list);
			sys_info->if_list = NULL;
		}
		if ( iflist.data )
		{
			free(iflist.data);
		}
		if_cnt = 0;

		return -3;
	}

#ifdef _DEBUG
	printf("***********************\n");
	printf("*  NET INTERFACE LIST *\n");
	printf("***********************\n");
	printf("[TOTAL IF CNT : %d]\n", iflist.number);
#endif
	for( i=0; i<iflist.number; i++)
	{
#ifdef _DEBUG
		printf("%02d) %s\n", i, iflist.data[i]);
#endif

		memcpy(&(sys_info->if_list[i].old), &(sys_info->if_list[i].cur), sizeof(ST_TRAN_NETWORK_USAGE));

		net_interface_stat(t, iflist.data[i], &(sys_info->if_list[i].cur));

		snprintf(sys_info->if_list[i].if_name, PROC_NAME_LEN+1, "%s", iflist.data[i]);

		if ( !(sys_info->if_count) )
		{
			memcpy(&(sys_info->if_list[i].old), &(sys_info->if_list[i].cur), sizeof(ST_TRAN_NETWORK_USAGE));
		}
#ifdef _DEBUG
		printf("[IF_NAME : %s] \n", sys_info->if_list[i].if_name);
		printf("   ->rx_bytes      : %010llu<->%010llu (%llu, avg:%llu)\n", sys_info->if_list[i].old.rx_byte     , sys_info->if_list[i].cur.rx_byte     , sys_info->if_list[i].cur.rx_byte      - sys_info->if_list[i].old.rx_byte     , (sys_info->if_list[i].cur.rx_byte      - sys_info->if_list[i].old.rx_byte     )/60);
		printf("   ->rx_packets    : %010llu<->%010llu (%llu, avg:%llu)\n", sys_info->if_list[i].old.rx_packet   , sys_info->if_list[i].cur.rx_packet   , sys_info->if_list[i].cur.rx_packet    - sys_info->if_list[i].old.rx_packet   , (sys_info->if_list[i].cur.rx_packet    - sys_info->if_list[i].old.rx_packet   )/60);
		printf("   ->rx_errors     : %010llu<->%010llu (%llu, avg:%llu)\n", sys_info->if_list[i].old.rx_error    , sys_info->if_list[i].cur.rx_error    , sys_info->if_list[i].cur.rx_error     - sys_info->if_list[i].old.rx_error    , (sys_info->if_list[i].cur.rx_error     - sys_info->if_list[i].old.rx_error    )/60);
		printf("   ->rx_dropped    : %010llu<->%010llu (%llu, avg:%llu)\n", sys_info->if_list[i].old.rx_dropped  , sys_info->if_list[i].cur.rx_dropped  , sys_info->if_list[i].cur.rx_dropped   - sys_info->if_list[i].old.rx_dropped  , (sys_info->if_list[i].cur.rx_dropped   - sys_info->if_list[i].old.rx_dropped  )/60);
		printf("   ->rx_overruns   : %010llu<->%010llu (%llu, avg:%llu)\n", sys_info->if_list[i].old.rx_overrun  , sys_info->if_list[i].cur.rx_overrun  , sys_info->if_list[i].cur.rx_overrun   - sys_info->if_list[i].old.rx_overrun  , (sys_info->if_list[i].cur.rx_overrun   - sys_info->if_list[i].old.rx_overrun  )/60);
		printf("   ->rx_frame      : %010llu<->%010llu (%llu, avg:%llu)\n", sys_info->if_list[i].old.rx_frame    , sys_info->if_list[i].cur.rx_frame    , sys_info->if_list[i].cur.rx_frame     - sys_info->if_list[i].old.rx_frame    , (sys_info->if_list[i].cur.rx_frame     - sys_info->if_list[i].old.rx_frame    )/60);
		printf("   ->tx_bytes      : %010llu<->%010llu (%llu, avg:%llu)\n", sys_info->if_list[i].old.tx_byte     , sys_info->if_list[i].cur.tx_byte     , sys_info->if_list[i].cur.tx_byte      - sys_info->if_list[i].old.tx_byte     , (sys_info->if_list[i].cur.tx_byte      - sys_info->if_list[i].old.tx_byte     )/60);
		printf("   ->tx_packets    : %010llu<->%010llu (%llu, avg:%llu)\n", sys_info->if_list[i].old.tx_packet   , sys_info->if_list[i].cur.tx_packet   , sys_info->if_list[i].cur.tx_packet    - sys_info->if_list[i].old.tx_packet   , (sys_info->if_list[i].cur.tx_packet    - sys_info->if_list[i].old.tx_packet   )/60);
		printf("   ->tx_errors     : %010llu<->%010llu (%llu, avg:%llu)\n", sys_info->if_list[i].old.tx_error    , sys_info->if_list[i].cur.tx_error    , sys_info->if_list[i].cur.tx_error     - sys_info->if_list[i].old.tx_error    , (sys_info->if_list[i].cur.tx_error     - sys_info->if_list[i].old.tx_error    )/60);
		printf("   ->tx_dropped    : %010llu<->%010llu (%llu, avg:%llu)\n", sys_info->if_list[i].old.tx_dropped  , sys_info->if_list[i].cur.tx_dropped  , sys_info->if_list[i].cur.tx_dropped   - sys_info->if_list[i].old.tx_dropped  , (sys_info->if_list[i].cur.tx_dropped   - sys_info->if_list[i].old.tx_dropped  )/60);
		printf("   ->tx_overruns   : %010llu<->%010llu (%llu, avg:%llu)\n", sys_info->if_list[i].old.tx_overrun  , sys_info->if_list[i].cur.tx_overrun  , sys_info->if_list[i].cur.tx_overrun   - sys_info->if_list[i].old.tx_overrun  , (sys_info->if_list[i].cur.tx_overrun   - sys_info->if_list[i].old.tx_overrun  )/60);
		printf("   ->tx_collisions : %010llu<->%010llu (%llu, avg:%llu)\n", sys_info->if_list[i].old.tx_collision, sys_info->if_list[i].cur.tx_collision, sys_info->if_list[i].cur.tx_collision - sys_info->if_list[i].old.tx_collision, (sys_info->if_list[i].cur.tx_collision - sys_info->if_list[i].old.tx_collision)/60);
		printf("   ->tx_carrier    : %010llu<->%010llu (%llu, avg:%llu)\n", sys_info->if_list[i].old.tx_carrier  , sys_info->if_list[i].cur.tx_carrier  , sys_info->if_list[i].cur.tx_carrier   - sys_info->if_list[i].old.tx_carrier  , (sys_info->if_list[i].cur.tx_carrier   - sys_info->if_list[i].old.tx_carrier  )/60);
#endif

	}
	sys_info->if_count = iflist.number;
#ifdef _DEBUG
	printf("[TOTAL IF CNT : %d]\n", iflist.number);
#endif

	free(iflist.data);
}

/* Network Interface 별 사용량 추출 */
/*
int net_interface_stat(sigar_t *t, const char* if_nm, ) 
*/
int net_interface_stat(sigar_t *t, const char* if_nm, ST_TRAN_NETWORK_USAGE *usage) 
{
	int ret=0;
	sigar_net_interface_stat_t ifstat;

	memset(&ifstat, 0x00, sizeof(sigar_net_interface_stat_t));
	/*
	sigar_net_interface_stat_get(t, "enp1s0f0", ifstat);
	*/
	if( (ret = sigar_net_interface_stat_get(t, if_nm, &ifstat)) == SIGAR_OK )
	{
#ifdef _DEBUG
		printf("***********************\n");
		printf("*  NET INTERFACE STAT *\n");
		printf("***********************\n");
		printf("[IF_NAME : %s] \n", if_nm);
		printf("   ->rx_bytes      : %llu\n", ifstat.rx_bytes     );
		printf("   ->rx_packets    : %llu\n", ifstat.rx_packets   );
		printf("   ->rx_errors     : %llu\n", ifstat.rx_errors    );
		printf("   ->rx_dropped    : %llu\n", ifstat.rx_dropped   );
		printf("   ->rx_overruns   : %llu\n", ifstat.rx_overruns  );
		printf("   ->rx_frame      : %llu\n", ifstat.rx_frame     );
		printf("   ->tx_bytes      : %llu\n", ifstat.tx_bytes     );
		printf("   ->tx_packets    : %llu\n", ifstat.tx_packets   );
		printf("   ->tx_errors     : %llu\n", ifstat.tx_errors    );
		printf("   ->tx_dropped    : %llu\n", ifstat.tx_dropped   );
		printf("   ->tx_overruns   : %llu\n", ifstat.tx_overruns  );
		printf("   ->tx_collisions : %llu\n", ifstat.tx_collisions);
		printf("   ->tx_carrier    : %llu\n", ifstat.tx_carrier   );
#endif
		if ( usage )
		{
			usage->rx_byte       = ifstat.rx_bytes     ;
			usage->rx_packet     = ifstat.rx_packets   ;
			usage->rx_error      = ifstat.rx_errors    ;
			usage->rx_dropped    = ifstat.rx_dropped   ;
			usage->rx_overrun    = ifstat.rx_overruns  ;
			usage->rx_frame      = ifstat.rx_frame     ;
			usage->tx_byte       = ifstat.tx_bytes     ;
			usage->tx_packet     = ifstat.tx_packets   ;
			usage->tx_error      = ifstat.tx_errors    ;
			usage->tx_dropped    = ifstat.tx_dropped   ;
			usage->tx_overrun    = ifstat.tx_overruns  ;
			usage->tx_collision  = ifstat.tx_collisions;
			usage->tx_carrier    = ifstat.tx_carrier   ;
		}
	}
	else
	{
#ifdef _DEBUG
		printf("NET INTERFACE NOT FOUNE [%s]\n", if_nm  );
#endif
	}
	return ret;
}

/* 인터페이스별 네크워크 connection 정보 추루 */
int net_conn_info(sigar_t *t, ST_TRAN_SYS_INFO *sys_info) 
{
    sigar_net_connection_list_t connlist;
    size_t idx;
    int ret;
	unsigned char c[4];

	memset(&connlist, 0x00, sizeof(sigar_net_connection_list_t));
    if (SIGAR_OK == (ret = sigar_net_connection_list_get(t, &connlist,
                SIGAR_NETCONN_SERVER | SIGAR_NETCONN_CLIENT | SIGAR_NETCONN_TCP | SIGAR_NETCONN_UDP))) 
	{
#ifdef _DEBUG
		printf("*************************\n");
		printf("*  NET CONN LIST START  *\n");
		printf("*************************\n");
#endif
        for (idx = 0; idx < connlist.number; idx++) 
		{
            sigar_net_connection_t con = connlist.data[idx];
#ifdef _DEBUG
			printf("[%d번째 연결]\n", idx);
			printf("   - LOCAL ADDRESS\n");
			sigar_ref_ip_swap(con.local_address.addr.in, c);
			printf("     -> local_in   : %d.%d.%d.%d\n", c[0], c[1], c[2], c[3]);
			printf("     -> local_port : %ld\n", con.local_port);
			printf("     -> local_mac  : %x:%x:%x:%x:%x:%x:%x:%x\n"
					, con.local_address.addr.mac[0], con.local_address.addr.mac[1], con.local_address.addr.mac[2], con.local_address.addr.mac[3]
					, con.local_address.addr.mac[4], con.local_address.addr.mac[5], con.local_address.addr.mac[6], con.local_address.addr.mac[7]);
			printf("   - REMOTE ADDRESS\n");
			sigar_ref_ip_swap(con.remote_address.addr.in, c);
			printf("     -> remote_in   : %d.%d.%d.%d\n", c[0], c[1], c[2], c[3]);
			printf("     -> remote_port : %ld\n", con.remote_port);
			printf("     -> remote mac  : %x:%x:%x:%x:%x:%x:%x:%x\n"
					, con.remote_address.addr.mac[0], con.remote_address.addr.mac[1], con.remote_address.addr.mac[2], con.remote_address.addr.mac[3]
					, con.remote_address.addr.mac[4], con.remote_address.addr.mac[5], con.remote_address.addr.mac[6], con.remote_address.addr.mac[7]);
			printf("   - uid        : %ld\n", con.uid);
			printf("   - inode      : %ld\n", con.inode);
			printf("   - type       : %ld\n", con.type);
			printf("   - state      : %ld\n", con.state);
			printf("   - send_queue : %ld\n", con.send_queue);
			printf("   - recv_queue : %ld\n", con.receive_queue);
			printf("--------------------------------------\n");
#endif
        }
#ifdef _DEBUG
		printf("*************************\n");
		printf("*  NET CONN LIST END    *\n");
		printf("*************************\n\n\n");
#endif
    } 
	else 
	{
#ifdef _DEBUG
            fprintf(stderr, "ret = %d (%s)\n", ret, sigar_strerror(t, ret));
#endif
        
    }

	sigar_net_connection_list_destroy(t, &connlist);

    return ret;
}

