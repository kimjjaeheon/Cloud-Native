#include <stdlib.h>
#include <string.h>
#include <sigar.h> /* jhp */

/* IP 변환 */
void sigar_ref_ip_swap(int a, char* c)
{
    c[0] = a & 0xFF;
    c[1] = (a >> 8) & 0xFF;
    c[2] = (a >> 16) & 0xFF;
    c[3] = (a >> 24) & 0xFF;
}

/* string token */
int sigar_ref_string_token(char* p_pattern_, const char* p_delimiter, char** buf_)
{
    int idx=0;
    char *p = NULL;
    char *pp = NULL;
    p=strtok_r(p_pattern_, ",", &pp);
    while(p)
    {
        buf_[idx++] = p;
        p = strtok_r(NULL, ",", &pp);
        if( idx >= 100 )
            break;
    }

    return idx;
}

/* token string search */
int sigar_ref_string_search(const char* src_, const char** dst_, const int dst_cnt_)
{
    int idx;

    for(idx=0; idx<dst_cnt_; idx++)
    {
        if( strstr(src_, dst_[idx]) )
		{
			if( strlen(src_) == strlen(dst_[idx]) )
			{
            	return 0;
			}
			else
			{
				return -1;
			}

		}
    }
    return -1;
}
