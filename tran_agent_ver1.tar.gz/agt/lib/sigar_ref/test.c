#include <sys/types.h>
#ifdef HAVE_SYS_TIME_H
#include <sys/time.h>
#endif
#ifdef HAVE_SYS_RESOURCE_H
#include <sys/resource.h>
#endif

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#if defined(MSVC)
#include <WinError.h>
#endif

#include "proc.h"
#include "sigar_private.h"
#include "sigar_format.h"
#include "sigar_tests.h"

#ifdef HAVE_VALGRIND_VALGRIND_H
#include <valgrind/valgrind.h>
#else
#define RUNNING_ON_VALGRIND 0 
#endif

int proc_stat_info(sigar_t *t, ST_TRAN_SYS_INFO *sys_info)
{
	int ret;

    sigar_proc_stat_t proc_stat;

	memset(&proc_stat, 0x00, sizeof(sigar_proc_stat_t));
    if( SIGAR_OK == sigar_proc_stat_get(t, &proc_stat))
	{
		printf("**************************\n");
		printf("*  PROC STAT INFO START  *\n");
		printf("**************************\n");
		printf(" - total    : %lu\n", proc_stat.total);
		printf(" - sleeping : %lu\n", proc_stat.sleeping);
		printf(" - running  : %lu\n", proc_stat.running);
		printf(" - zombie   : %lu\n", proc_stat.zombie);
		printf(" - stopped  : %lu\n", proc_stat.stopped);
		printf(" - idle     : %lu\n", proc_stat.idle);
		printf(" - threads  : %lu\n", proc_stat.threads);
		printf("**************************\n");
		printf("*  PROC STAT INFO END    *\n");
		printf("**************************\n\n\n");
	}
	else
	{
		fprintf(stderr, "ret = %d (%s)\n", ret, sigar_strerror(t, ret));
	}

    return ret;
}

int proc_list_info(sigar_t *t)
{
    sigar_proc_list_t proclist;
    int idx;
	int ret;

	memset(&proclist, 0x00, sizeof(sigar_proc_list_t));
    if( SIGAR_OK != (ret=sigar_proc_list_get(t, &proclist)) )
	{
		return ret;
	}

#ifdef _DEBUG
	printf("*********************************\n");
	printf("*  PROC LIST DETAIL INFO START  *\n");
	printf("*********************************\n");
#endif
    for (idx = 0; idx < proclist.number; idx++) {
        sigar_pid_t pid = proclist.data[idx];
        sigar_proc_mem_t proc_mem;
        sigar_proc_time_t proc_time;
        sigar_proc_state_t proc_state;
		sigar_proc_cpu_t *proccpu;

        if (SIGAR_OK == sigar_proc_state_get(t, pid, &proc_state)) 
		{
			if( !strstr(proc_state.name, "log_") && !strstr(proc_state.name, "agtmgmt") 
					&& !strstr(proc_state.name, "agtchkd") && !strstr(proc_state.name, "hash") )
			{
				continue;
			}
#ifdef _DEBUG
			printf("[%d 번째 프로세스]\n", idx);
			printf("   PROC_STAT_INFO\n");
			printf("   - name     : %s\n", proc_state.name);
			printf("   - state    : %c\n", proc_state.state);
			printf("   - ppid     : %lu\n", proc_state.ppid);
			printf("   - tty      : %d\n", proc_state.tty);
			printf("   - priority : %d\n", proc_state.priority);
			printf("   - nice     : %d\n", proc_state.nice);
			printf("   - processor: %d\n", proc_state.processor);
			printf("   - threads  : %lu\n", proc_state.threads);
#endif
        } 
		else 
		{
        	fprintf(stderr, "ret = %d (%s)\n", ret, sigar_strerror(t, ret));
        }
        if (SIGAR_OK == (ret = sigar_proc_mem_get(t, pid, &proc_mem))) 
		{
#ifdef _DEBUG
			printf("   PROC_MEM_INFO\n");
			printf("   - size         : %.2f\n", proc_mem.size );
			printf("   - resident     : %.2f\n", proc_mem.resident );
			printf("   - share        : %.2f\n", proc_mem.share );
			printf("   - minor_faults : %.2f\n", proc_mem.minor_faults );
			printf("   - major_faults : %.2f\n", proc_mem.major_faults );
			printf("   - page_fault   : %.2f\n", proc_mem.page_faults );
#endif
        } else 
		{
			fprintf(stderr, "ret = %d (%s)\n", ret, sigar_strerror(t, ret));
        }

		if (SIGAR_OK == sigar_proc_cpu_get(t, pid, proccpu))
		{
#ifdef _DEBUG
			printf("   PROC_CPU_INFO\n");
			printf("   - user     : %lu\n", proccpu->user );
			printf("   - sys      : %lu\n", proccpu->sys );
			printf("   - total    : %lu\n", proccpu->total );
			printf("   - ratio    : %.2f\n", proccpu->percent );
			printf("   - start_tm : %lu\n", proccpu->start_time );
#endif
		}
		else
		{
			fprintf(stderr, "ret = %d (%s)\n", ret, sigar_strerror(t, ret));
		}


        if (SIGAR_OK == (ret = sigar_proc_time_get(t, pid, &proc_time))) 
		{
#ifdef _DEBUG
			printf("   PROC_TIME_INFO\n");
			printf("   - start_time : %lu\n", proc_time.start_time);
			printf("   - user       : %lu\n", proc_time.user);
			printf("   - sys        : %lu\n", proc_time.sys);
			printf("   - total      : %lu\n", proc_time.total);
#endif
        } 
		else 
		{
			fprintf(stderr, "ret = %d (%s)\n", ret, sigar_strerror(t, ret));
        }
    }
	printf("*********************************\n");
	printf("*  PROC LIST DETAIL INFO END    *\n");
	printf("*********************************\n\n\n");

    sigar_proc_list_destroy(t, &proclist);

    return ret;
}

