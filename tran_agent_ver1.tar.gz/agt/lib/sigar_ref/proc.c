#include <sys/types.h>
#ifdef HAVE_SYS_TIME_H
#include <sys/time.h>
#endif
#ifdef HAVE_SYS_RESOURCE_H
#include <sys/resource.h>
#endif

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#if defined(MSVC)
#include <WinError.h>
#endif

#include "proc.h"
#include "sigar_private.h"
#include "sigar_format.h"

/*
#include "sigar_tests.h"
*/

#ifdef HAVE_VALGRIND_VALGRIND_H
#include <valgrind/valgrind.h>
#else
#define RUNNING_ON_VALGRIND 0 
#endif

/*
typedef struct _st_proc_cpu_mem_info
{
	unsigned long pid;
	sigar_proc_mem_t   mem;
	sigar_proc_cpu_t   cpu_old;
	sigar_proc_cpu_t   cpu_now;

}ST_PROC_CPU_MEM_INFO_LIST;

typedef struct _st_proc_cpu_mem_info_list
{
	int proc_count;
}ST_PROC_CPU_MEM_INFO_LIST;
*/

#if 0
int proc_cpu_mem_info(sigar_t *t, ST_TRAN_SYS_INFO *sys_info, void* p)
{
	int proc_idx;
	ST_PROC_CPU_MEM_INFO_LIST *pst = p;

	sigar_cpu_t cpu;
	static sigar_cpu_t old;
	sigar_cpu_perc_t perc;
	sigar_cpu_perc_calculate(&old, &cpu, &perc);


	if( !pst )
	{
		return -1;
	}

	for( proc_idx=0; proc_idx<p->proc_count; proc_idx++ )
	{
        if (SIGAR_OK == (ret = sigar_proc_mem_get(t, pid, &proc_mem))) 
		{
#ifdef _DEBUG
			printf("   PROC_MEM_INFO\n");
			printf("   - size         : %lu\n", proc_mem.size/1024 );
			printf("   - resident     : %lu\n", proc_mem.resident/1024 );
			printf("   - share        : %lu\n", proc_mem.share/1024 );
			printf("   - minor_faults : %lu\n", proc_mem.minor_faults/1024 );
			printf("   - major_faults : %lu\n", proc_mem.major_faults/1024 );
			printf("   - page_fault   : %lu\n", proc_mem.page_faults/1024 );
			/*
			printf("   - size         : %.2f\n", proc_mem.size );
			printf("   - resident     : %.2f\n", proc_mem.resident );
			printf("   - share        : %.2f\n", proc_mem.share );
			printf("   - minor_faults : %.2f\n", proc_mem.minor_faults );
			printf("   - major_faults : %.2f\n", proc_mem.major_faults );
			printf("   - page_fault   : %.2f\n", proc_mem.page_faults );
			*/
#endif
        } else 
		{
			fprintf(stderr, "ret = %d (%s)\n", ret, sigar_strerror(t, ret));
        }

        if (SIGAR_OK == (ret = sigar_proc_time_get(t, pid, &proc_time))) 
		{
#ifdef _DEBUG
			printf("   PROC_TIME_INFO\n");
			printf("   - start_time : %lu\n", proc_time.start_time);
			printf("   - user       : %lu\n", proc_time.user);
			printf("   - sys        : %lu\n", proc_time.sys);
			printf("   - total      : %lu\n", proc_time.total);
#endif
        } 
		else 
		{
			fprintf(stderr, "ret = %d (%s)\n", ret, sigar_strerror(t, ret));
        }

		memcpy(&proccpu, &proc_time, sizeof(proc_time));
        if (SIGAR_OK == (ret = sigar_proc_cpu_get(t, pid, &proccpu))) 
		{
#ifdef _DEBUG
			printf("   PROC_CPU_INFO\n");
			printf("   - user       : %lu\n", proccpu.user );
			printf("   - sys        : %lu\n", proccpu.sys );
			printf("   - total      : %lu\n", proccpu.sys );
			printf("   - raito      : %.2f\n", proccpu.percent );
			printf("   - start_time : %lu\n", proccpu.start_time );
#endif
        } else 
		{
			fprintf(stderr, "ret = %d (%s)\n", ret, sigar_strerror(t, ret));
        }
	}
}
#endif

/* PROCESS 상테 정보 추출 */
int proc_stat_info(sigar_t *t, ST_TRAN_SYS_INFO *sys_info)
{
	int ret;

    sigar_proc_stat_t proc_stat;

	memset(&proc_stat, 0x00, sizeof(sigar_proc_stat_t));
    ret  = sigar_proc_stat_get(t, &proc_stat);
    if( SIGAR_OK == ret )
	{
#ifdef _DEBUG
		printf("**************************\n");
		printf("*  PROC STAT INFO START  *\n");
		printf("**************************\n");
		printf(" - total    : %lu\n", proc_stat.total);
		printf(" - sleeping : %lu\n", proc_stat.sleeping);
		printf(" - running  : %lu\n", proc_stat.running);
		printf(" - zombie   : %lu\n", proc_stat.zombie);
		printf(" - stopped  : %lu\n", proc_stat.stopped);
		printf(" - idle     : %lu\n", proc_stat.idle);
		printf(" - threads  : %lu\n", proc_stat.threads);
		printf("**************************\n");
		printf("*  PROC STAT INFO END    *\n");
		printf("**************************\n\n\n");
#endif
	}
	else
	{
#ifdef _DEBUG
		fprintf(stderr, "ret = %d (%s)\n", ret, sigar_strerror(t, ret));
#endif
	}

    return ret;
}

/* PROCESS CPU/MEMORY 정보 추출 */
int proc_cpu_mem_info(sigar_t *t, pid_t *pid, double *cpu_ratio, unsigned long* mem_rss, int proc_cnt)
{
	int idx;
	int ret;

	for(idx=0; idx<proc_cnt; idx++)
	{
        sigar_proc_mem_t proc_mem;
		sigar_proc_cpu_t proccpu;
        if (SIGAR_OK == (ret = sigar_proc_mem_get(t, pid[idx], &proc_mem))) 
		{
			mem_rss[idx] = (unsigned long)proc_mem.resident/1024;
#ifdef _DEBUG
			fprintf(stdout, "   - mem size         : %lu\n", proc_mem.size/1024 );
			fprintf(stdout, "   - mem resident     : %lu\n", proc_mem.resident/1024 );
#endif
		}
		else
		{
#ifdef _DEBUG
			fprintf(stdout, "<!> sigar_ref -> proc_cpu_mem_info : pid(%lu) mem get fail (%d:%s)\n", pid[idx], ret, sigar_strerror(t, ret));
#endif
		}
        if (SIGAR_OK == (ret = sigar_proc_cpu_get(t, pid[idx], &(proccpu)))) 
		{
#ifdef _AIX
			cpu_ratio[idx] = (double)(((proccpu.percent)*100)/(cpu_core_cnt()));
#else
			cpu_ratio[idx] = (double)((proccpu.percent)*100);
#endif
#ifdef _DEBUG
			fprintf(stdout, "   - cpu raito      : %f\n", cpu_ratio[idx] );
#endif
		}
		else
		{
#ifdef _DEBUG
			fprintf(stdout, "<!> sigar_ref -> proc_cpu_mem_info : pid(%lu) cpu ratio get fail (%d:%s)\n", pid[idx], ret, sigar_strerror(t, ret));
#endif
		}
	}
	return ret;
}

/* PID list 에 있는 pid 의 정보 수집 */
/*
int proc_pid_list_info(sigar_t *t, ST_TRAN_PID_LIST *pid_list)
{
	return 0;
}
*/

/* SYSTEM 에서 기동중인 모든 PROCESS에 대한 종합 정보 수집 */
int proc_list_info(sigar_t *t, ST_TRAN_SYS_INFO *sys_info)
{
    static sigar_proc_list_t proclist;
    int idx;
	int ret;

	memset(&proclist, 0x00, sizeof(sigar_proc_list_t));
    if( SIGAR_OK != (ret=sigar_proc_list_get(t, &proclist)) )
	{
#ifdef _DEBUG
		fprintf(stderr, "ret = %d (%s)\n", ret, sigar_strerror(t, ret));
#endif
		return ret;
	}

	if ( sys_info == NULL )
	{
    	sigar_proc_list_destroy(t, &proclist);
		return -1;
	}
	
	if ( sys_info->proc_list != NULL )
	{
		free(sys_info->proc_list);
		sys_info->proc_list = NULL;
	}

	if ( (sys_info->proc_list = malloc((sizeof(ST_TRAN_PROC_INFO)*proclist.number)+1)) == NULL )
	{
    	sigar_proc_list_destroy(t, &proclist);
		return -1;
	}

	memset(sys_info->proc_list, 0x00, (sizeof(ST_TRAN_PROC_INFO)*proclist.number)+1);
	sys_info->proc_count = proclist.number;

#ifdef _DEBUG
	printf("*********************************\n");
	printf("*  PROC LIST DETAIL INFO START  *\n");
	printf("*********************************\n");
#endif
	int i;
    for (idx = 0; idx < proclist.number; idx++) 
	{
        sigar_pid_t pid = proclist.data[idx];
        sigar_proc_mem_t proc_mem;
        sigar_proc_time_t proc_time;
		sigar_proc_cpu_t proccpu;

#ifdef _SIGAR_PROC_CPU_STAT
        sigar_proc_state_t proc_state;
        if (SIGAR_OK == sigar_proc_state_get(t, pid, &proc_state)) 
		{
			snprintf(sys_info->proc_list[idx].proc_name, PROC_NAME_LEN+1, "%s", proc_state.name);
			sys_info->proc_list[idx].pid = pid;
			sys_info->proc_list[idx].ppid = proc_state.ppid;
			sys_info->proc_list[idx].state = proc_state.state;
			sys_info->proc_list[idx].tty = proc_state.tty;
			sys_info->proc_list[idx].priority = proc_state.priority;
			sys_info->proc_list[idx].nice = proc_state.nice;
			sys_info->proc_list[idx].processor = proc_state.processor;
			sys_info->proc_list[idx].threads = proc_state.threads;
#	ifdef _DEBUG
			printf("[Index : %d]\n", idx);
			printf("   * PROC_STAT_INFO\n");
			printf("   - name     : %s : %s\n", proc_state.name, sys_info->proc_list[idx].proc_name);
			printf("   - pid      : %lu : %lu\n", pid, sys_info->proc_list[idx].pid);
			printf("   - ppid     : %lu : %lu\n", proc_state.ppid, sys_info->proc_list[idx].ppid);
			printf("   - state    : %c : %c\n", proc_state.state, sys_info->proc_list[idx].state);
			printf("   - tty      : %d : %d\n", proc_state.tty, sys_info->proc_list[idx].tty);
			printf("   - priority : %d : %d\n", proc_state.priority, sys_info->proc_list[idx].priority);
			printf("   - nice     : %d : %d\n", proc_state.nice, sys_info->proc_list[idx].nice);
			printf("   - processor: %d : %d\n", proc_state.processor, sys_info->proc_list[idx].processor);
			printf("   - threads  : %lu : %lu\n", proc_state.threads, sys_info->proc_list[idx].threads);
#	endif
        } 
		else 
		{
#	ifdef _DEBUG
        	fprintf(stderr, "ret = %d (%s)\n", ret, sigar_strerror(t, ret));
#	endif
			continue;
        }
#endif /* _SIGAR_PROC_CPU_STAT */

#ifdef _SIGAR_PROC_CRED_INFO
        sigar_proc_cred_name_t proc_cred;
        if (SIGAR_OK == (ret = sigar_proc_cred_name_get(t, pid, &proc_cred))) 
		{
			snprintf(sys_info->proc_list[idx].user, PROC_USER_LEN+1, "%s", proc_cred.user);
			snprintf(sys_info->proc_list[idx].group, PROC_GROUP_LEN+1, "%s", proc_cred.group);
#	ifdef _DEBUG
			printf(" * PROC_USER_INFO\n");
			printf("   - user      : %s : %s\n", proc_cred.user, sys_info->proc_list[idx].user);
			printf("   - group     : %s : %s\n", proc_cred.group, sys_info->proc_list[idx].group);
#	endif
		}
		else 
		{
#	ifdef _DEBUG
        	fprintf(stderr, "ret = %d (%s)\n", ret, sigar_strerror(t, ret));
#	endif
			continue;
        }
#endif /* _SIGAR_PROC_CRED_INFO */

        if (SIGAR_OK == (ret = sigar_proc_mem_get(t, pid, &proc_mem))) 
		{
			/*
			mem_rss[idx] = (unsigned long)proc_mem.resident/1024;
			*/
			sys_info->proc_list[idx].mem = proc_mem.size/1024;
			sys_info->proc_list[idx].mem_res = proc_mem.resident/1024;
#ifdef _DEBUG
			printf(" * PROC_MEM_INFO\n");
			fprintf(stdout, "   - mem size         : %lu : %lu\n", proc_mem.size/1024, sys_info->proc_list[idx].mem);
			fprintf(stdout, "   - mem resident     : %lu : %lu\n", proc_mem.resident/1024, sys_info->proc_list[idx].mem_res);
#endif
		}
		else
		{
#ifdef _DEBUG
			fprintf(stdout, "<!> sigar_ref -> proc_cpu_mem_info : pid(%lu) mem get fail (%d:%s)\n", pid, ret, sigar_strerror(t, ret));
#endif
		}

        if (SIGAR_OK == (ret = sigar_proc_cpu_get(t, pid, &proccpu))) 
		{
/*
#ifdef _AIX
			sys_info->proc_list[idx].cpu = ((proccpu.percent)*100) / (cpu_core_cnt());
#else
			sys_info->proc_list[idx].cpu = (proccpu.percent) * 100;
#endif
*/

#ifdef _DEBUG
			printf(" * PROC_CPU_INFO\n");
#	ifdef _AIX
			printf("   - cpu raito      : %.2f\n", (((proccpu.percent)*100)/(cpu_core_cnt())));
#	else
			printf("   - cpu raito      : %.2f\n", (proccpu.percent)*100);
#	endif
#endif
#ifdef _DEBUG
			/*
			fprintf(stdout, "   - cpu raito      : %f\n", cpu_ratio );
			*/
#endif
		}
		else
		{
#ifdef _DEBUG
			fprintf(stdout, "<!> sigar_ref -> proc_cpu_mem_info : pid(%lu) cpu ratio get fail (%d:%s)\n", pid, ret, sigar_strerror(t, ret));
#endif
		}

#ifdef _SIGAR_PROC_TIME_INFO
        if (SIGAR_OK == (ret = sigar_proc_time_get(t, pid, &proc_time))) 
		{
			sys_info->proc_list[idx].start_tm = proc_time.start_time;
			sys_info->proc_list[idx].user_tm = proc_time.user;
			sys_info->proc_list[idx].sys_tm = proc_time.sys;
			sys_info->proc_list[idx].total_tm = proc_time.total;
#ifdef _DEBUG
			printf(" * PROC_TIME_INFO\n");
			printf("   - start_time : %lu : %lu\n", proc_time.start_time, sys_info->proc_list[idx].start_tm);
			printf("   - user       : %lu : %lu\n", proc_time.user, sys_info->proc_list[idx].user_tm);
			printf("   - sys        : %lu : %lu\n", proc_time.sys, sys_info->proc_list[idx].sys_tm);
			printf("   - total      : %lu : %lu\n", proc_time.total, sys_info->proc_list[idx].total_tm);
#endif
        } 
		else 
		{
#ifdef _DEBUG
			fprintf(stderr, "ret = %d (%s)\n", ret, sigar_strerror(t, ret));
#endif
        }
#endif
    }

	sleep(1);
    for (idx = 0; idx < proclist.number; idx++) 
	{
        sigar_pid_t pid = proclist.data[idx];
		sigar_proc_cpu_t proccpu;
        if (SIGAR_OK == (ret = sigar_proc_cpu_get(t, pid, &(proccpu)))) 
		{
#ifdef _AIX
			sys_info->proc_list[idx].cpu = ((proccpu.percent)*100) / (cpu_core_cnt());
#else
			sys_info->proc_list[idx].cpu = (proccpu.percent) * 100;
#endif

#ifdef _DEBUG
			printf(" * PROC_CPU_INFO\n");
			printf("   - PID : %d\n", pid);
#ifdef _AIX
			printf("   - cpu raito      : %.2f : %.2f\n", (((proccpu.percent)*100)/(cpu_core_cnt())), sys_info->proc_list[idx].cpu);
#else
			printf("   - cpu raito      : %.2f : %.2f\n", (proccpu.percent)*100, sys_info->proc_list[idx].cpu);
#endif
#endif
#ifdef _DEBUG
			/*
			fprintf(stdout, "   - cpu raito      : %f\n", cpu_ratio );
			*/
#endif
		}
		else
		{
#ifdef _DEBUG
			fprintf(stdout, "<!> sigar_ref -> proc_cpu_mem_info : pid(%lu) cpu ratio get fail (%d:%s)\n", pid, ret, sigar_strerror(t, ret));
#endif
		}
	}
#ifdef _DEBUG
	printf("*********************************\n");
	printf("*  PROC LIST DETAIL INFO END    *\n");
	printf("*********************************\n\n\n");
#endif

    sigar_proc_list_destroy(t, &proclist);
#ifdef _DEBUG
	sigar_cache_dump2(t);
#endif

    return ret;
}

