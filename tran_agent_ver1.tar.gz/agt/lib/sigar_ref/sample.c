#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "sigar.h"
#include "sigar_ref.h"

char disk_dev_name[1024];

int main(int argc_, char** argv_)
{
	/* sigar »ý¼º ¹× Ãʱâȭ */
	st_sigar* p = create_sigar();

	if( !p )
	{
		fprintf(stderr, "create_sigar fail\n");
		exit(-1);
	}

	if( argc_ != 2)
	{
		fprintf(stderr, "usage : %s option\n", argv_[0]);
		fprintf(stderr, "(option : all, cpu, os, disk, mem, proc, conn)\n");
		exit(0);
	}

	memset(disk_dev_name, 0x00, sizeof(disk_dev_name));

	/* µð½ºũ Á¤º¸¸¦ °¡Á®¿À±â À§ÇÑ ÆÄÀϽýºÅ۸í  */
	sprintf(disk_dev_name, "/sw,/log");

	/* Àüü Á¤º¸ º¸±â */
	if( !(strcmp(argv_[1], "all")) )
	{
		sigar_cpuinfo(p);                         /* CPU Àüü¿¡ ´ëÇÑ Á¤º¸ ¼öÁý */
		sigar_procinfo(p);                        /* ÇÁ·μ¼½º Á¤º¸ ¼öÁý        */
		sigar_conninfo(p);                        /* ³×Ʈ¿öũ ¿¬°á Á¤º¸ ¼öÁý   */
		sigar_diskinfo(p, disk_dev_name);         /* µð½ºũ Á¤º¸ ¼öÁý          */
		sigar_osinfo(p);                          /* OS Á¤º¸ ¼öÁý              */
		sigar_meminfo(p);                         /* ¸޸ð¸® Á¤º¸ ¼öÁý          */
	}
	/* °³º°Á¤º¸ º¸±â */
	else
	{
		int x;
		if( !strcmp(argv_[1], "cpu") )
		{
			for(x=0; x<60; x++)
			{
				sigar_cpuinfo(p);
				sleep(1);
			}
		}
		else if( !strcmp(argv_[1], "mem") )
			sigar_meminfo(p);
		else if( !strcmp(argv_[1], "proc") )
		{
			/*
			sigar_procinfo(p);
			sigar_proc_listinfo(p);
			*/
			int i, idx;
			pid_t pid[3]={3284, 15902, 1001};
			unsigned long mem_rss[3]={0x00,};
			double cpu_ratio[3]={0x00,};
			for(i=0; i<3; i++)
			{
				printf("cpu_mem_info [%lu,  %f,  %lu]\n", pid[i], cpu_ratio[i], mem_rss[i]);  
			}
			printf("==============================================================\n");

#if 0
			for( idx=0; idx<10; idx++ )
			{
				sigar_proc_resource_info(p, pid, cpu_ratio, mem_rss, 3);

				for(i=0; i<3; i++)
				{
					printf("cpu_mem_info [%lu,  %f,  %lu]\n", pid[i], cpu_ratio[i], mem_rss[i]);  
				}
				sleep(3);
			}
#endif
			ST_TRAN_SYS_INFO sys_info;
			memset(&sys_info, 0x00, sizeof(ST_TRAN_SYS_INFO));
			proc_list_info(p->t, &sys_info);
		}
		else if( !strcmp(argv_[1], "conn") )
		{
			sigar_conninfo(p);
			net_interface_stat(p->t, "enp1s0f0", NULL);

			ST_TRAN_SYS_INFO sys_info;
			memset(&sys_info, 0x00, sizeof(ST_TRAN_SYS_INFO));

			/*
			net_interface_info(p->t, &sys_info);
			*/

			p->getIfInfo(p);
			sleep(60);
			/*
			net_interface_info(p->t, &sys_info);
			*/
			p->getIfInfo(p);
			sleep(60);
			p->getIfInfo(p);
			/*
			net_interface_info(p->t, &sys_info);
			*/
		}
		else if( !strcmp(argv_[1], "disk") )
		{
			char disk_list[10][10]={{"/sw"},{"/log"},{"/dev"},{"/dev/shm"},{"/run"}};
			char *ptr[10];
			ptr[0] = disk_list[0];
			ptr[1] = disk_list[1];
			ptr[2] = disk_list[2];
			ptr[3] = disk_list[3];
			ptr[4] = disk_list[4];

			for(x=0; x<10; x++)
			{
				p->getDiskInfoStatic(p, ptr, 5);
				sleep(1);
				printf("=====================================================================\n");
			}
		}
			/*
			sigar_diskinfo(p, disk_dev_name);
			*/
		else if( !strcmp(argv_[1], "os") )
			sigar_osinfo(p);
		else
			fprintf(stderr, "type is not exist\n");
	}


	printf("*******************\n");
	printf("*   SYSTEN INFO   *\n");
	printf("*******************\n");
	printf(" @ CPU\n");
	printf(" - idle     : %.2f\n", p->sys_info.cpu.idle);
	printf(" - used     : %.2f\n", p->sys_info.cpu.used);
	printf(" - core_cnt : %d\n", p->sys_info.cpu.core_cnt);
	printf(" -------------------------\n");
	printf(" @ MEM\n");
	printf(" - total : %.2f\n", p->sys_info.mem.total);
	printf(" - used  : %.2f\n", p->sys_info.mem.used);
	printf(" - free  : %.2f\n", p->sys_info.mem.free);
	printf(" -------------------------\n");
	printf(" @ OS\n");
	printf(" - name        : %s\n", p->sys_info.os.name);
	printf(" - kernel_ver  : %s\n", p->sys_info.os.ver);
	printf(" - machine     : %s\n", p->sys_info.os.machine);
	printf(" - vendor      : %s\n", p->sys_info.os.vendor);
	printf(" - venddor_ver : %s\n", p->sys_info.os.vendor_ver);
	printf(" -------------------------\n");
	if( !strcmp(argv_[1], "disk") || !strcmp(argv_[1], "all") )
	{
		printf(" @ DISK\n");
		int idx;
		for(  idx=0; idx < p->sys_info.disk_count; idx++)
		{
			printf("   [%d DISK]\n", idx);
			printf("   - ratio         : %.0f%\n", p->sys_info.disk_list[idx].ratio*100);
			printf("   - dir_name      : %s\n", p->sys_info.disk_list[idx].dir_name);
			printf("   - dev_name      : %s\n", p->sys_info.disk_list[idx].dev_name);
			printf("   - type_name     : %s\n", p->sys_info.disk_list[idx].type_name);
			printf("   - sys_type_name : %s\n", p->sys_info.disk_list[idx].sys_type_name);
			printf("   - option        : %s\n", p->sys_info.disk_list[idx].option);
			printf("   - total         : %llu MB\n", p->sys_info.disk_list[idx].total);
			printf("   - free          : %llu MB\n", p->sys_info.disk_list[idx].free);
			printf("   - used          : %llu MB\n", p->sys_info.disk_list[idx].used);
		}
	}

	/*
	 * ½ýºÅÛ Á¤º¸ ¼öÁý ¿ϷáÈÄ Àڿø ÇØÁö
	 */
	destroy_sigar(p);
	return 0;
}
