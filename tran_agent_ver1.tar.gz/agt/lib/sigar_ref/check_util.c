#include <stdio.h>
#include <string.h>

/* 문자열 토큰 처리 */
int string_token(char* p_pattern_, const char* p_delimiter, char** buf_)
{
    int idx=0;
    char *p = NULL;
    char *pp = NULL;
    p=strtok_r(p_pattern_, ",", &pp);
    while(p)
    {
        buf_[idx++] = p;
        p = strtok_r(NULL, ",", &pp);
        if( idx >= 100 )
            break;
    }

    return idx;
}

/* 토큰된 문자에서 특정 문자 검색 */
int string_search(const char* src_, const char** dst_, const int dst_cnt_)
{
    int idx;

    for(idx=0; idx<dst_cnt_; idx++)
    {
        if( strstr(src_, dst_[idx]) )
            return 0;
    }
    return -1;
}

