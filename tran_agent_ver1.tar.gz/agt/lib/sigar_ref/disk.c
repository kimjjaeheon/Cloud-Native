#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "disk.h"
#include "sigar_ref.h"
#include "sigar_format.h"

#include "util.h"

#define KB 1024
#define MB KB*KB
#define GB MB*MB

#define XB MB

/* int disk_info(sigar_t *t, ST_TRAN_SYS_INFO *sys_info) */
/* DISK 정보 추출 */
/*
int disk_info(sigar_t *t, ST_TRAN_SYS_INFO *sys_info, char **disk_dev_name_list)
*/
int disk_info(sigar_t *t, ST_TRAN_SYS_INFO *sys_info)
{
    sigar_file_system_list_t fslist;
	int ret;
	int disk_cnt=0;
    int idx;
	char buf[1024];

	memset(&fslist, 0x00, sizeof(sigar_file_system_list_t));
    if( SIGAR_OK != (ret=sigar_file_system_list_get(t, &fslist)) )
	{
		return ret;
	}

#ifdef A_DEBUG
	printf("**********************\n");
	printf("*  DISK USING STATE  *\n");
	printf("**********************\n");
	printf("- number : %lu\n", fslist.number);
	printf("- size   : %.2f\n", fslist.size);
#endif

	/*
	 * disk 수 만큼 alloc 
	 */
	if ( !(sys_info->disk_list) )
	{
		sys_info->disk_list = malloc(sizeof(ST_TRAN_DISK_INFO)*fslist.number);
		if ( !(sys_info->disk_list) )
		{
			sigar_file_system_list_destroy(t, &fslist);
			return -1;
		}
	}
	memset(sys_info->disk_list, 0x00, sizeof(ST_TRAN_DISK_INFO)*fslist.number);

	sys_info->disk_count = fslist.number;

    for (idx = 0; idx < fslist.number; idx++) 
	{
        sigar_file_system_usage_t fsusage;
        sigar_disk_usage_t diskusage;

		memset(&diskusage, 0x00, sizeof(sigar_disk_usage_t));

#ifdef A_DEBUG
		printf("[%d DISK 정보 ]\n", idx);
		printf("   - dir_name      : %s\n", fslist.data[idx].dir_name);
		printf("   - dev_name      : %s\n", fslist.data[idx].dev_name);
		printf("   - type_name     : %s\n", fslist.data[idx].type_name);
		printf("   - sys_type_name : %s\n", fslist.data[idx].sys_type_name);
		printf("   - options       : %s\n", fslist.data[idx].options);
		printf("   - type          : %d\n", fslist.data[idx].type);
		printf("   - flags         : %lu\n", fslist.data[idx].flags);
#endif


        if (SIGAR_OK != (ret = sigar_file_system_ping(t, &fslist.data[idx]))) 
		{
            continue;
        }

		memset(&fsusage, 0x00, sizeof(fsusage));
        if (SIGAR_OK == (ret = sigar_file_system_usage_get(t, fslist.data[idx].dir_name, &fsusage))) 
		{
			sys_info->disk_list[disk_cnt].ratio = fsusage.use_percent;
			sprintf(sys_info->disk_list[disk_cnt].dir_name, fslist.data[idx].dir_name);
			sprintf(sys_info->disk_list[disk_cnt].dev_name, fslist.data[idx].dev_name);
			sprintf(sys_info->disk_list[disk_cnt].type_name, fslist.data[idx].type_name);
			sprintf(sys_info->disk_list[disk_cnt].sys_type_name, fslist.data[idx].sys_type_name);
			sprintf(sys_info->disk_list[disk_cnt].option, fslist.data[idx].options);
#ifdef _AIX
			if ( !strcmp(fslist.data[idx].type_name, "none") )
			{
				continue;
			}
#endif
			sys_info->disk_list[disk_cnt].total = (sigar_uint64_t)fsusage.total;
			sys_info->disk_list[disk_cnt].free  = (sigar_uint64_t)fsusage.free;
			sys_info->disk_list[disk_cnt].used  = (sigar_uint64_t)fsusage.used;
			/*
			sprintf(sys_info->disk_list[disk_cnt].total, "%lu", (sigar_uint64_t)fsusage.total/1024);
			sprintf(sys_info->disk_list[disk_cnt].free, "%lu", (sigar_uint64_t)fsusage.free/1024);
			sprintf(sys_info->disk_list[disk_cnt].used, "%lu", (sigar_uint64_t)fsusage.used/1024);
			*/
			disk_cnt++;
#ifdef A_DEBUG
			printf("   [ DISK 사용량]\n", idx);
			/*
			printf("   - reads        : %.2f\n", fsusage.disk.reads/XB);
			printf("   - writes       : %.2f\n", fsusage.disk.writes/XB);
			printf("   - write_bytes  : %.2f\n", fsusage.disk.write_bytes/XB);
			printf("   - read_bytes   : %.2f\n", fsusage.disk.read_bytes/XB);
			printf("   - rtime        : %lu\n", fsusage.disk.rtime);
			printf("   - wtime        : %lu\n", fsusage.disk.wtime);
			printf("   - qtime        : %lu\n", fsusage.disk.qtime);
			printf("   - time         : %lu\n", fsusage.disk.time);
			printf("   - snaptime     : %lu\n", fsusage.disk.snaptime);
			printf("   - service_time : %lu\n", fsusage.disk.service_time);
			printf("   - queue        : %lu\n", fsusage.disk.queue);
			*/
			printf("   - ratio        : %.2f\n", fsusage.use_percent);
			printf("   - total        : %llu MB\n", (sys_info->disk_list[disk_cnt-1].total)/1024);
			printf("   - free         : %llu MB\n", (sys_info->disk_list[disk_cnt-1].free)/1024);
			printf("   - used         : %llu MB\n", (sys_info->disk_list[disk_cnt-1].used)/1024);
			printf("   - avail        : %llu MB\n", (sigar_uint64_t)fsusage.avail/1024);
			printf("   - files        : %llu MB\n", (sigar_uint64_t)fsusage.files/1024);
			printf("   - free_files   : %llu MB\n", (sigar_uint64_t)fsusage.free_files/1024);
#endif
        } 
		else 
		{
#ifdef A_DEBUG
			fprintf(stderr, "sigar_file_system_usage_get(%s) ret = %d (%s)\n",
					fslist.data[idx].dir_name,
					ret, sigar_strerror(t, ret));
#endif
			continue;
        }

        if (SIGAR_OK == (ret = sigar_disk_usage_get(t, fslist.data[idx].dev_name, &diskusage))) 
		{
#ifdef A_DEBUG
			printf("   [DISK IO 정보]\n", idx);
			printf("   - reads        : %lu\n", diskusage.reads);
			printf("   - writes       : %lu\n", diskusage.writes);
			printf("   - write_bytes  : %lu\n", diskusage.write_bytes);
			printf("   - read_bytes   : %lu\n", diskusage.read_bytes);
			printf("   - rtime        : %lu\n", diskusage.rtime);
			printf("   - wtime        : %lu\n", diskusage.wtime);
			printf("   - qtime        : %lu\n", diskusage.qtime);
			printf("   - time         : %lu\n", diskusage.time);
			printf("   - snaptime     : %lu\n", diskusage.snaptime);
			printf("   - service_time : %lu\n", diskusage.service_time);
			printf("   - queue        : %lu\n", diskusage.queue);
#endif
        } 
		else 
		{
#ifdef A_DEBUG
			fprintf(stderr, "sigar_disk_usage_get(%s) ret = %d (%s)\n",
						fslist.data[idx].dev_name,
						ret, sigar_strerror(t, ret));
#endif
        }
    }
#ifdef A_DEBUG
	printf("**********************\n");
	printf("*  DISK USING END    *\n");
	printf("**********************\n\n\n");
#endif

    sigar_file_system_list_destroy(t, &fslist);

    return ret;
}

/* DISK 정보 추출 (STATIC) */
int disk_info_static(sigar_t *t, ST_TRAN_SYS_INFO *sys_info, char **disk_dev_name_list, const unsigned int disk_list_cnt)
{
	int ret;
	int disk_cnt=0;
    int idx;
	char buf[1024];

#ifdef A_DEBUG
	printf("**********************\n");
	printf("*  DISK USING STATE  *\n");
	printf("**********************\n");
	printf("- number : %lu\n", disk_list_cnt);
#endif

	/*
	 * disk 수 만큼 alloc 
	 */
	if ( !(sys_info->disk_list) )
	{
		sys_info->disk_list = malloc(sizeof(ST_TRAN_DISK_INFO)*MAX_DISK_LIST);
		if ( !(sys_info->disk_list) )
		{
			return -1;
		}
	}
	memset(sys_info->disk_list, 0x00, sizeof(ST_TRAN_DISK_INFO)*MAX_DISK_LIST);

	sys_info->disk_count = disk_list_cnt;

    for (idx = 0; idx < disk_list_cnt; idx++) 
	{
        sigar_file_system_usage_t fsusage;
        sigar_disk_usage_t diskusage;

		memset(&diskusage, 0x00, sizeof(sigar_disk_usage_t));

#ifdef A_DEBUG
		printf("[%d DISK 정보 ]\n", idx);
		printf("   - dir_name      : %s\n", disk_dev_name_list[idx]);
#endif


		memset(&fsusage, 0x00, sizeof(fsusage));
        if (SIGAR_OK == (ret = sigar_file_system_usage_get(t, disk_dev_name_list[idx], &fsusage))) 
		{
			sys_info->disk_list[disk_cnt].ratio = fsusage.use_percent;
			sprintf(sys_info->disk_list[disk_cnt].dir_name, disk_dev_name_list[idx]);

			sys_info->disk_list[disk_cnt].total = (sigar_uint64_t)fsusage.total;
			sys_info->disk_list[disk_cnt].free  = (sigar_uint64_t)fsusage.free;
			sys_info->disk_list[disk_cnt].used  = (sigar_uint64_t)fsusage.used;
			/*
			sprintf(sys_info->disk_list[disk_cnt].total, "%lu", (sigar_uint64_t)fsusage.total/1024);
			sprintf(sys_info->disk_list[disk_cnt].free, "%lu", (sigar_uint64_t)fsusage.free/1024);
			sprintf(sys_info->disk_list[disk_cnt].used, "%lu", (sigar_uint64_t)fsusage.used/1024);
			*/
			disk_cnt++;
#ifdef A_DEBUG
			printf("   [ DISK 사용량]\n", idx);
			/*
			printf("   - reads        : %.2f\n", fsusage.disk.reads/XB);
			printf("   - writes       : %.2f\n", fsusage.disk.writes/XB);
			printf("   - write_bytes  : %.2f\n", fsusage.disk.write_bytes/XB);
			printf("   - read_bytes   : %.2f\n", fsusage.disk.read_bytes/XB);
			printf("   - rtime        : %lu\n", fsusage.disk.rtime);
			printf("   - wtime        : %lu\n", fsusage.disk.wtime);
			printf("   - qtime        : %lu\n", fsusage.disk.qtime);
			printf("   - time         : %lu\n", fsusage.disk.time);
			printf("   - snaptime     : %lu\n", fsusage.disk.snaptime);
			printf("   - service_time : %lu\n", fsusage.disk.service_time);
			printf("   - queue        : %lu\n", fsusage.disk.queue);
			*/
			printf("   - ratio        : %.2f\n", fsusage.use_percent);
			printf("   - total        : %llu MB\n", (sys_info->disk_list[disk_cnt-1].total)/1024);
			printf("   - free         : %llu MB\n", (sys_info->disk_list[disk_cnt-1].free)/1024);
			printf("   - used         : %llu MB\n", (sys_info->disk_list[disk_cnt-1].used)/1024);
			printf("   - avail        : %llu MB\n", (sigar_uint64_t)fsusage.avail/1024);
			printf("   - files        : %llu MB\n", (sigar_uint64_t)fsusage.files/1024);
			printf("   - free_files   : %llu MB\n", (sigar_uint64_t)fsusage.free_files/1024);
#endif
        } 
		else 
		{
#ifdef A_DEBUG
			fprintf(stderr, "sigar_file_system_usage_get(%s) ret = %d (%s)\n",
					disk_dev_name_list[idx],
					ret, sigar_strerror(t, ret));
#endif
			continue;
        }

        if (SIGAR_OK == (ret = sigar_disk_usage_get(t, disk_dev_name_list[idx], &diskusage))) 
		{
#ifdef A_DEBUG
			printf("   [DISK IO 정보]\n", idx);
			printf("   - reads        : %lu\n", diskusage.reads);
			printf("   - writes       : %lu\n", diskusage.writes);
			printf("   - write_bytes  : %lu\n", diskusage.write_bytes);
			printf("   - read_bytes   : %lu\n", diskusage.read_bytes);
			printf("   - rtime        : %lu\n", diskusage.rtime);
			printf("   - wtime        : %lu\n", diskusage.wtime);
			printf("   - qtime        : %lu\n", diskusage.qtime);
			printf("   - time         : %lu\n", diskusage.time);
			printf("   - snaptime     : %lu\n", diskusage.snaptime);
			printf("   - service_time : %lu\n", diskusage.service_time);
			printf("   - queue        : %lu\n", diskusage.queue);
#endif
        } 
		else 
		{
#ifdef A_DEBUG
			fprintf(stderr, "sigar_disk_usage_get(%s) ret = %d (%s)\n",
						disk_dev_name_list[idx],
						ret, sigar_strerror(t, ret));
#endif
        }
    }
#ifdef A_DEBUG
	printf("**********************\n");
	printf("*  DISK USING END    *\n");
	printf("**********************\n\n\n");
#endif

    return ret;
}

