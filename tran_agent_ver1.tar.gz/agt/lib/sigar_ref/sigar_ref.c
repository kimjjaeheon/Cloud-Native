#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#include "sigar_ref.h"

/* 초기화 */
void init_sigar(st_sigar* p_sigar);

/* ref function */
int		sigar_meminfo	(st_sigar* p_this);
int		sigar_cpuinfo	(st_sigar* p_this);
int		sigar_osinfo	(st_sigar* p_this);
int		sigar_diskinfo	(st_sigar* p_this);
int		sigar_diskinfo_static	(st_sigar* p_this, char **disk_dev_name_list, const unsigned int disk_list_cnt);
/*
int		sigar_diskinfo	(st_sigar* p_this, char* p_);
*/
int		sigar_procinfo	(st_sigar* p_this);
int		sigar_proc_resource_info	(st_sigar* p_this, pid_t* pid, double* cpu_ratio, unsigned long* mem_rss, int cnt);
int		sigar_proc_listinfo	(st_sigar* p_this);
int		sigar_conninfo	(st_sigar* p_this);
int		sigar_ifinfo	(st_sigar* p_this);


/* sigar 생성 */
st_sigar* create_sigar()
{
	int ret;
	st_sigar* p_sigar = NULL;
	p_sigar = (st_sigar*)malloc(sizeof(st_sigar));

	if( !p_sigar )
	{
		return NULL;
	}

	memset(p_sigar, 0x00, sizeof(st_sigar));
	init_sigar(p_sigar);

    if( SIGAR_OK != (ret=sigar_open(&(p_sigar->t))) )
    {
#ifdef _DEBUG
        fprintf(stderr, "siagr open fail");
        fprintf(stderr, "ret = %d (%s)\n", ret, sigar_strerror(p_sigar->t, ret));
#endif
		return NULL;
    }
	return p_sigar;
}

/* sigar 초기화 */
void init_sigar(st_sigar* p_sigar)
{
	if( !p_sigar )
	{
		return;
	}

	p_sigar->getOsInfo   = sigar_osinfo;
	p_sigar->getCpuInfo  = sigar_cpuinfo;
	p_sigar->getMemInfo  = sigar_meminfo;
	p_sigar->getDiskInfo = sigar_diskinfo;
	p_sigar->getDiskInfoStatic = sigar_diskinfo_static;
	p_sigar->getConnInfo = sigar_conninfo;
	p_sigar->getProcInfo = sigar_procinfo;
	p_sigar->getProcResourceInfo = sigar_proc_resource_info;
	p_sigar->getProcListInfo = sigar_proc_listinfo;
	p_sigar->getIfInfo   = sigar_ifinfo;
}

/* sigar 자원 반납 */
void destroy_sigar(st_sigar* p_sigar)
{
	if( !p_sigar )
	{
		return;
	}
	sigar_close(p_sigar->t);

	if( p_sigar->sys_info.disk_list )
	{
		free(p_sigar->sys_info.disk_list);
	}

	if( p_sigar->sys_info.proc_list )
	{
		free(p_sigar->sys_info.proc_list);
	}

	if( p_sigar->sys_info.if_list )
	{
		free(p_sigar->sys_info.if_list);
	}
}


/* os info */
int sigar_osinfo(st_sigar* p_sigar)
{
	SIGAR_MUTEX_LOCK(sigar_mlock);
	os_info(p_sigar->t, &(p_sigar->sys_info));
	SIGAR_MUTEX_UNLOCK(sigar_mlock);
	return 0;
}

/* cpu info */
int sigar_cpuinfo(st_sigar* p_sigar)
{
	SIGAR_MUTEX_LOCK(sigar_mlock);
	cpu_info(p_sigar->t, &(p_sigar->sys_info));
	SIGAR_MUTEX_UNLOCK(sigar_mlock);
	return 0;
}

/* mem info */
int sigar_meminfo(st_sigar* p_sigar)
{
	SIGAR_MUTEX_LOCK(sigar_mlock);
	mem_info(p_sigar->t, &(p_sigar->sys_info));
	SIGAR_MUTEX_UNLOCK(sigar_mlock);
	return 0;
}

#if 0
/* disk info */
int sigar_diskinfo(st_sigar* p_sigar, char* p_disk_dev_name)
{
	p_sigar->sys_info.disk_count = sigar_ref_string_token(p_disk_dev_name, ",", p_sigar->pp_disk_dev_name_list);
	disk_info(p_sigar->t, &(p_sigar->sys_info), p_sigar->pp_disk_dev_name_list);
	return 0;
}
#endif

/* disk info */
int sigar_diskinfo(st_sigar* p_sigar)
{
	SIGAR_MUTEX_LOCK(sigar_mlock);
	disk_info(p_sigar->t, &(p_sigar->sys_info));
	SIGAR_MUTEX_UNLOCK(sigar_mlock);
	return 0;
}

/* disk info static */
int sigar_diskinfo_static(st_sigar* p_sigar, char **disk_dev_name_list, const unsigned int disk_list_cnt)
{
	SIGAR_MUTEX_LOCK(sigar_mlock);
	disk_info_static(p_sigar->t, &(p_sigar->sys_info), disk_dev_name_list, disk_list_cnt);
	SIGAR_MUTEX_UNLOCK(sigar_mlock);
	return 0;
}

/* proc info */
int sigar_procinfo(st_sigar* p_sigar)
{
	SIGAR_MUTEX_LOCK(sigar_mlock);
	proc_stat_info(p_sigar->t, &(p_sigar->sys_info));
	SIGAR_MUTEX_UNLOCK(sigar_mlock);
	return 0;
}

/* proc resource info */
int	sigar_proc_resource_info(st_sigar* p_sigar, pid_t* pid, double* cpu_ratio, unsigned long* mem_rss, int cnt)
{
	SIGAR_MUTEX_LOCK(sigar_mlock);
	proc_cpu_mem_info(p_sigar->t, pid, cpu_ratio, mem_rss, cnt);
	SIGAR_MUTEX_UNLOCK(sigar_mlock);
	return 0;
}

/* proc total info */
int sigar_proc_listinfo(st_sigar* p_sigar)
{
	SIGAR_MUTEX_LOCK(sigar_mlock);
	proc_list_info(p_sigar->t, &(p_sigar->sys_info));
	SIGAR_MUTEX_UNLOCK(sigar_mlock);
	return 0;
}

/* interface info */
int sigar_ifinfo(st_sigar* p_sigar)
{
	SIGAR_MUTEX_LOCK(sigar_mlock);
	net_interface_info(p_sigar->t, &(p_sigar->sys_info));
	SIGAR_MUTEX_UNLOCK(sigar_mlock);
	return 0;
}

/* network connection info */
int sigar_conninfo(st_sigar* p_sigar)
{
	SIGAR_MUTEX_LOCK(sigar_mlock);
	net_conn_info(p_sigar->t, &(p_sigar->sys_info));
	SIGAR_MUTEX_UNLOCK(sigar_mlock);
	return 0;
}

#if 0
int main()
{
	st_sigar* p = create_sigar();

	if( !p )
	{
		fprintf(stderr, "create sigar fail\n");
		exit(-1);
	}

	sigar_meminfo(p);

	destroy_sigar(p);
	return 0;
}
#endif

