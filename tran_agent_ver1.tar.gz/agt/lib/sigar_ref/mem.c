#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "mem.h"

/* 메모리 정보 추출 */
int mem_info(sigar_t *t, ST_TRAN_SYS_INFO *sys_info)
{
    sigar_mem_t mem;
    int status;

	memset(&mem, 0x00, sizeof(sigar_mem_t));
    if( SIGAR_OK != (status = sigar_mem_get(t, &mem)))
	{
		return status;
	}

#ifdef _DEBUG
	printf("********************\n");
	printf("*  MEM INFO START  *\n");
	printf("********************\n");
	printf("- ram         : %lu\n", mem.ram / 1024 / 1024);
	printf("- total       : %lu\n", mem.total / 1024 / 1024);
	printf("- used        : %lu\n", mem.used / 1024 / 1024);
	printf("- free        : %lu\n", mem.free / 1024 / 1024);
	printf("- actual_used : %ld\n", mem.actual_used / 1024 / 1024);
	printf("- actual_free : %ld\n", mem.actual_free / 1024 / 1024);
	printf("********************\n");
	printf("*  MEM INFO END    *\n");
	printf("********************\n\n\n");
#endif

	sys_info->mem.total = mem.total / 1024 / 1024;
	sys_info->mem.free = mem.actual_free / 1024 / 1024;
	sys_info->mem.used = mem.actual_used / 1024 / 1024;

    return status;
}

