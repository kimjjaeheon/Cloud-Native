#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "os.h"

/* OS 정보 추출 */
int os_info(sigar_t *t, ST_TRAN_SYS_INFO *sys_info) 
{
    sigar_sys_info_t os;
    int ret;

	memset(&os, 0x00, sizeof(sigar_sys_info_t));
    if( SIGAR_OK != (ret = sigar_sys_info_get(t, &os)))
	{
		return ret;
	}

#ifdef _DEBUG
	printf("*******************\n");
	printf("*  OS INFO START  *\n");
	printf("*******************\n");
	printf("- name             : %s\n", os.name);
	printf("- version          : %s\n", os.version);
	printf("- arch             : %s\n", os.arch);
	printf("- machine          : %s\n", os.machine);
	printf("- description      : %s\n", os.description);
	printf("- patch_level      : %s\n", os.patch_level);
	printf("- vendor           : %s\n", os.vendor);
	printf("- vendor_version   : %s\n", os.vendor_version);
	printf("- vendor_name      : %s\n", os.vendor_name);
	printf("- vendor_code_name : %s\n", os.vendor_code_name);
	printf("*******************\n");
	printf("*  OS INFO END    *\n");
	printf("*******************\n\n\n");
#endif

	sprintf(sys_info->os.name, "%.*s", OS_NAME_LEN, os.name);
	sprintf(sys_info->os.ver, "%.*s", OS_VER_LEN, os.version);
	sprintf(sys_info->os.arch, "%.*s", OS_ARCH_LEN, os.arch);
	sprintf(sys_info->os.machine, "%.*s", OS_MACHINE_LEN, os.machine);
	sprintf(sys_info->os.vendor, "%.*s", OS_VENDOR_LEN, os.vendor);
	sprintf(sys_info->os.vendor_name, "%.*s", OS_VENDOR_NAME_LEN, os.vendor_name);
	sprintf(sys_info->os.vendor_ver, "%.*s", OS_VENDOR_VER_LEN, os.vendor_version);

    return ret;
}

