
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "usrutil.h"
#include "subprocess.h"

void test_dir();

void test_subprocess();
void test_string();
void test_copy();

int main(int argc, char** argv) {

  test_dir();
  printf("\n");

  test_string();
  printf("\n");

  test_copy();

  // test_subprocess();
  return 0;
}

void test_dir() {

  int res = 0;
  {
    char* dirs[] = {
        "./a/b/c"
      , "./def/ghijklmn"
      , NULL
    };

    printf("# test makedir\n");
    char** dir;
    for(dir=dirs; *dir!=NULL; dir++) {
      if( (res=is_file_exist(*dir)) ) {
        fprintf(stderr, "exist file. type=(%d), dir=[%s]\n", res, *dir);
      }
      else {
        res = makedir(*dir, 1);
        fprintf(stderr, "makedir. res=(%d), dir=[%s]\n", res, *dir);
      }
    }
  }

  {
    char* dirs[] = {
        "./a/b/c"
      , "./a"
      , "./def"
      , NULL
    };

    printf("# test rm\n");

    char** dir;
    for(dir=dirs; *dir!=NULL; dir++) {
      if( 0 != removedir(*dir, 1) ) {
        printf("removedir failed for (%s)\n", *dir);
      }
      else {
        printf("removedir success for (%s)\n", *dir);
      }
    }
  }

}

static void hello(void *arg_p) {
  
  printf("Hello %s on stdout!\n", (char *)arg_p);
  fprintf(stderr, "Hello %s on stderr!\n", (char *)arg_p);
}


void test_subprocess() {
  struct subprocess_result_t *result_p;

  DEBUG_PRINT(stderr, "%s()", __FUNCTION__);

  result_p = subprocess_call_output(hello, "world");
  if (result_p != NULL) {
    subprocess_result_print(result_p);
    subprocess_result_free(result_p);
  }

  result_p = subprocess_exec_output_timeout("sleep 10", 3);
  if (result_p != NULL) {
    subprocess_result_print(result_p);
    subprocess_result_free(result_p);
  }
}


void test_string() {

  DEBUG_PRINT(stderr, "+ %s() start", __FUNCTION__);

  char* str = "Hello World~";
  int c = 0;
  struct st_test_data {
    const char* word;
    const char* rep_str;
  } test_data[] = {
    { "World", "There" },
    { "~", "!!!" },
    { "Hello ", "" },
  };

  fprintf(stderr, "data count=(%d)", sizeof(test_data)/sizeof(test_data[0]));

  for(;c<sizeof(test_data)/sizeof(test_data[0]); ++c ) {

    DEBUG_PRINT(stderr, "idx=%d. (%s) -> (%s)", c, test_data[c].word, test_data[c].rep_str);
    char* out_str = str_replace(str, test_data[c].word, test_data[c].rep_str);
    if( out_str ) {
      printf("org=[%s]\n", str);
      printf("rep=[%s]\n", out_str);

      free(out_str);
    }
  }

  char str2[] = "\t \t [     1234567890    ]\t \r\n ";
  DEBUG_PRINT(stderr, "org  str=(%s)", str2);
  trim_all(str2, " \t\r\n");
  DEBUG_PRINT(stderr, "trim str=(%s)", str2);

  DEBUG_PRINT(stderr, "- %s() end", __FUNCTION__);
  fflush(stderr);

  {
    char** file = NULL;
    char* file_name[] = {
      "abc.txt", "1.cpp", "2", "4.c", NULL 
    };

    for(file=file_name; *file!=NULL; file++) {
      fprintf(stderr, "file=(%s), extention=(%s)\n", *file, file_extension(*file));
    }
  }

  {
    int res = 0;

    if( FILETYPE_FILE == is_file_exist("test.txt") ) {
      unlink("test.txt");
    }

    res = system("echo \"abc\" > test.txt");
    fprintf(stderr, "system res=(%d)\n", res);

    fprintf(stderr, "rename_file res=(%d). test.txt -> /dev/shm/test.tmp\n"
      , rename_file("test.txt", "/dev/shm/test.tmp", 1));

  }
}

void test_copy() {

  printf("%s()\n", __FUNCTION__);

  char* src = "makefile.usrutil";
  char* dst = "makefile.usrutil2";

  int res = copy_file(src, dst);
  printf("copy file (%s) to (%s). res=(%d)\n", src, dst, res);
  
}