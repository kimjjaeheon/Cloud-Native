
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include "offset_parser.h"

#define SIZEOF_ARRAY(x) sizeof(x)/sizeof(x[0])

void test_offset_parser();

int main(int argc, char** argv) {
  test_offset_parser();
  return 0;
}

void test_offset_parser() {

  int c = 0;
  st_offset_parser* op = NULL;

  const char* bufs[] = {
       "01234567890123456789012345678901234567890123456789" // 50
     , "0123456789012345678901234567890123456789"  // 49
     , "0123456789ABCDEFGHIJ012345678901234567890123456789" // 50
     , "0123456789" // 10
     , "012345678901234567890123456789" // 30
     , "01234567890123456789012345678901234567890123456789" // 50
  };

  st_offset_info infos[] = {
    {  0, 10, "desc 1" }, 
    { 20,  5, "desc 2" }, 
    { 30,  8, "desc 3" }, 
    { 38,  2, "desc 4" }, 
    { 15,  5, "desc 5" },
  };

  do {
    op = make_offset_parser(infos, SIZEOF_ARRAY(infos));
    if( !op ) {
      fprintf(stderr, "make_offset_parser failed.\n");
      break;
    }

#ifdef _DEBUG
    dump_offset_parser(op, stderr);
    printf("\n");
#endif

    for(c=0; c<SIZEOF_ARRAY(bufs);++c) {

      int len = strlen(bufs[c]);
      int split_cnt = op->parser(op, (char*)bufs[c], len);
      printf("%02d : bufs=[%s], len=(%d)\n", c, bufs[c], len);

      if( 0 > split_cnt ) { // error
        fprintf(stderr, "op->parser error...\n");
      }
      else {
        int k = 0;
        for(;k<split_cnt; ++k) {
          printf("  %02d: (%s)\n", k, op->get_item(op, k));
        }
      }

      printf("\n");
    }
  } while(0);

  if( op ) {
    free_offset_parser(op);
  }

  return ;
}

#include "tran_profile.h"

__attribute__((no_instrument_function, constructor))
static void penta_constructor(void) {
  TRAN_ADD_PROFILE(main, "main");
  TRAN_ADD_PROFILE(test_offset_parser, "test_offset_parser");

}

__attribute__((no_instrument_function, destructor))
static void penta_destructor(void) {
  TRAN_DEL_PROFILE(main);
  TRAN_DEL_PROFILE(test_offset_parser);

}
