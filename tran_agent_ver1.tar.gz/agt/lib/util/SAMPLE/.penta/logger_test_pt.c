
#include "logger.h"

int main(int argc, char** argv) {

  const char* path = "$TRAN_HOME/agt/lib/util/SAMPLE/logs";
  const char* filename = "test_logger";

  st_logger_t* logger = make_logger(path, filename, eLL_debug);
  if(!logger) {
    fprintf(stderr, "make_logger failed.\n");
    return -1;
  }

  LOG_T(logger, "trace message 1");
  LOG_D(logger, "debug message 1");
  LOG_I(logger, "info message 1");

  logger->level = eLL_trace;
  logger->display_console_stderr = 1;

  LOG_T(logger, "trace message 2");
  LOG_D(logger, "debug message 2");
  LOG_I(logger, "debug message 2");

  logger->level = eLL_info;

  LOG_T_FL(logger, "trace message 3");
  LOG_D_FL(logger, "debug message 3");
  LOG_I_FL(logger, "debug message 3");


  return 0;
}


#include "tran_profile.h"

__attribute__((no_instrument_function, constructor))
static void penta_constructor(void) {
  TRAN_ADD_PROFILE(main, "main");

}

__attribute__((no_instrument_function, destructor))
static void penta_destructor(void) {
  TRAN_DEL_PROFILE(main);

}
