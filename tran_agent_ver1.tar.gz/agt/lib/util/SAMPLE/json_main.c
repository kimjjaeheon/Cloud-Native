#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "cJSON.h"

void main() {

	cJSON* root = NULL;
	cJSON* name = NULL;

	int c = 0;

	char* str = "{\n\"name\":\"Hello~\nWorld!! �ѱ��׽�Ʈ\"\n}";
	printf("str\n%s\n", str);
	for(c=0;c<strlen(str);++c) {
		printf("%02x ", (unsigned char)str[c]);
	}
	printf("\n");

	//*
	root = cJSON_CreateObject();
	if( !root ) {
		printf("json error. root\n");
		return;
	}

	if(NULL == cJSON_AddStringToObject(root, "name", "Hello~\nWorld!! \"�ѱ��׽�Ʈ\"")) {
		printf("json error. name\n");
		return;
	}

	if(NULL == cJSON_AddNumberToObject(root, "num", 123)) {
		printf("json error. num\n");
		return;
	}
	//*/

	/*
	root = CJSON_Parse(str);
	if( !root ) {
		printf("json parse error!!\n"); 
		return;
	}
	//*/


	char* string = cJSON_PrintUnformatted(root);

	if( string ) {
		printf("string=(%s)\n", string);

		for(c=0;c<strlen(string);++c) {
			printf("%02x ", (unsigned char) string[c]);
		}
		printf("\n");


		free(string);
	}

	cJSON_Delete(root);

}
