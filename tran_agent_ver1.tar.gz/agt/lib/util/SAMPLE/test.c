#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int
main(int argc, char *argv[])
{
	char* p;
	

   char buf[1024] = { 0, };

    p = buf;
   if (argc != 2) {
        fprintf(stderr, "Usage: %s <pathname>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    if( realpath(argv[1], buf) == NULL ) {
        perror("realpath error: ");  
		return -1;
    }

	fprintf(stderr, "%s -> %s\n", argv[1], buf);

   exit(EXIT_SUCCESS);
}
