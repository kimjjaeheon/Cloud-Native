
#ifndef __TEST_H__
#define __TEST_H__

extern "C" void hello();

#endif
