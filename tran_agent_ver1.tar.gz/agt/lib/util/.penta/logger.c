#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>

#include "logger.h"
#include "usrutil.h"

static const char* log_lvl_names[eLL_size] = {"trace","debug","info","warning","error","critical","off"};
static const char* log_lvl_short_names[eLL_size] = {"T","D","I","W","E","C","O"};

void write_log(st_logger_t* logger, int level, const char* fmt, va_list args);

void log_trace   (struct _st_logger_t* logger, const char* fmt, ...);
void log_debug   (struct _st_logger_t* logger, const char* fmt, ...);
void log_info    (struct _st_logger_t* logger, const char* fmt, ...);
void log_warn    (struct _st_logger_t* logger, const char* fmt, ...);
void log_err     (struct _st_logger_t* logger, const char* fmt, ...);
void log_critical(struct _st_logger_t* logger, const char* fmt, ...);

int lock(pthread_mutex_t* mutex) {
  return pthread_mutex_lock(mutex);
}

int unlock(pthread_mutex_t* mutex) {
  return pthread_mutex_unlock(mutex);
}

const char* log_lvl_to_str(int level)
{
  if( 0 > level || eLL_size < level ) {
    return "";
  }
  
  return log_lvl_names[level];
}

const char* log_lvl_to_short_str(int level)
{
  if( 0 > level || eLL_size < level ) {
    return "";
  }
  
  return log_lvl_short_names[level];
}

st_logger_t* make_logger(const char* path, const char* name, int level) 
{
  int res = 0;
  st_logger_t* logger = NULL; 
  char logfile[512]   = {0,};
  char tmp[512]       = {0,};

  logger = malloc(sizeof(st_logger_t));
  if( !logger ) {
    return NULL;
  }

  memset(logger, 0x00, sizeof(st_logger_t));

  env2str((char*)path, tmp, sizeof(tmp));
  PRINT_D(stderr, "path=(%s) ", tmp);

  if( 0 != (res=makedir(tmp, 0)) ) {

    PRINT_D(stderr, "makedir fail=(%s). res=(%d)", tmp, res);
    return NULL;
  }
 
  snprintf(logger->path, sizeof(logger->path), "%s", tmp);
  snprintf(logger->name, sizeof(logger->name), "%s", name);
  logger->level = level;
  
  logger->use_thread  = 0;
  logger->is_mode     = eLM_daily;
  logger->split_size  = 0;
  
  timestring(time(NULL), "%Y-%m-%d", logger->date, sizeof(logger->date));
  snprintf(logfile, sizeof(logfile)-1, "%s/%s-%s-log", tmp, name, logger->date);
  
  mode_t oldmask = umask(0);
  logger->fp = fopen(logfile, "a+");
  if( NULL == logger->fp ) {
    free(logger);
    umask(oldmask);
    return NULL;
  }

  umask(oldmask);
  
  logger->trace    = log_trace   ;
  logger->debug    = log_debug   ;
  logger->info     = log_info    ;
  logger->warn     = log_warn    ;
  logger->err      = log_err     ;
  logger->critical = log_critical;
  
  pthread_mutex_init(&logger->mutex, NULL);
  
  return logger;
}

void free_logger(st_logger_t* logger) {
  if( logger ) {
    if(logger->fp && logger->fp != stderr) {
      fclose(logger->fp);
      logger->fp = NULL;
    }
    
    pthread_mutex_destroy(&logger->mutex);
    
    free(logger);
  }
}

void write_log(st_logger_t* logger, int level, const char* fmt, va_list args)
{
  va_list args2;
  va_copy(args2, args);
  
  char logfile[512] = {0,};
  char timestr[24] = {0,}, *date_time = NULL;
  int date_len = 10;
  const char* lvl_str = NULL;

  timestring(time(NULL), "%Y-%m-%d %H:%M:%S", timestr, sizeof(timestr));
  date_time = timestr+date_len+1;
    
  if( NULL == logger || NULL == logger->fp ) {
    return;
  }
  
  if( logger->level > level || logger->level == eLL_off ) {
    return;
  }
  
  if( logger->use_thread ) {
    lock(&logger->mutex);
  }
  
  if( strncmp(logger->date, timestr, date_len) ) {
    fflush(logger->fp);
    fclose(logger->fp);

    snprintf(logfile, sizeof(logfile)-1, "%s/%s-%.*s-log"
      , logger->path, logger->name, date_len, timestr);
    logger->fp = fopen(logfile, "a+");
    if( NULL == logger->fp ) {
      if( logger->use_thread ) {
        unlock(&logger->mutex);
      }
      return;
    }
    
    sprintf(logger->date, "%.*s", date_len, timestr);
  }
  else {
    snprintf(logfile, sizeof(logfile)-1, "%s/%s-%.*s-log"
      , logger->path, logger->name, date_len, timestr);
  }
  
  if( 0 == is_file_exist(logfile) ) {
    if( NULL != logger->fp ) {
      fclose(logger->fp);
    }
    logger->fp = fopen(logfile, "a+");
  }
  
  lvl_str = log_lvl_to_short_str(level);
  // -------------------------------------------------------------
  vsnprintf(logger->logbuf, sizeof(logger->logbuf), fmt, args);
  fprintf(logger->fp, "%s %s} %s\n", date_time, lvl_str, logger->logbuf);

  if( logger->display_console_stderr ) {
    fprintf(stderr, "%s %s} %s\n", date_time, lvl_str, logger->logbuf);
  }
  // -------------------------------------------------------------
  
  fflush(logger->fp);
  
  if( logger->use_thread ) {
    unlock(&logger->mutex);
  }
}

void log_trace(struct _st_logger_t* logger, const char* fmt, ...) {
  va_list args;
  va_start(args, fmt);
  write_log(logger, eLL_trace, fmt, args);
  va_end(args);
}
  
void log_debug(struct _st_logger_t* logger, const char* fmt, ...) {
  va_list args;
  va_start(args, fmt);
  write_log(logger, eLL_debug, fmt, args);
  va_end(args);
}

void log_info(struct _st_logger_t* logger, const char* fmt, ...) {
  va_list args;
  va_start(args, fmt);
  write_log(logger, eLL_info, fmt, args);
  va_end(args);
}

void log_warn(struct _st_logger_t* logger, const char* fmt, ...) {
  va_list args;
  va_start(args, fmt);
  write_log(logger, eLL_warn, fmt, args);
  va_end(args);
}

void log_err(struct _st_logger_t* logger, const char* fmt, ...) {
  va_list args;
  va_start(args, fmt);
  write_log(logger, eLL_err, fmt, args);
  va_end(args);
}

void log_critical(struct _st_logger_t* logger, const char* fmt, ...) {
  va_list args;
  va_start(args, fmt);
  write_log(logger, eLL_critical, fmt, args);
  va_end(args);
}

void dump_logger(st_logger_t* logger) {
  LOG_I(logger, "# %s()", __FUNCTION__);
  LOG_I(logger, "use_thread             = (%d)", logger->use_thread);
  LOG_I(logger, "level                  = (%d)", logger->level);
  LOG_I(logger, "display_console_stderr = (%d)", logger->display_console_stderr);
  LOG_I(logger, "path                   = (%s)", logger->path);
  LOG_I(logger, "name                   = (%s)", logger->name);
  LOG_I(logger, "date                   = (%s)", logger->date);
}


#include "tran_profile.h"

#ifdef __cplusplus
extern "C"
{
#endif
static void penta_constructor(void) __attribute__((no_instrument_function, constructor));
static void penta_destructor(void) __attribute__((no_instrument_function, destructor));
#ifdef __cplusplus
}
#endif

static void penta_constructor(void) {
  TRAN_ADD_PROFILE((void*)lock, "lock");
  TRAN_ADD_PROFILE((void*)unlock, "unlock");
  TRAN_ADD_PROFILE((void*)log_lvl_to_str, "log_lvl_to_str");
  TRAN_ADD_PROFILE((void*)log_lvl_to_short_str, "log_lvl_to_short_str");
  TRAN_ADD_PROFILE((void*)make_logger, "make_logger");
  TRAN_ADD_PROFILE((void*)free_logger, "free_logger");
  TRAN_ADD_PROFILE((void*)write_log, "write_log");
  TRAN_ADD_PROFILE((void*)log_trace, "log_trace");
  TRAN_ADD_PROFILE((void*)log_debug, "log_debug");
  TRAN_ADD_PROFILE((void*)log_info, "log_info");
  TRAN_ADD_PROFILE((void*)log_warn, "log_warn");
  TRAN_ADD_PROFILE((void*)log_err, "log_err");
  TRAN_ADD_PROFILE((void*)log_critical, "log_critical");
  TRAN_ADD_PROFILE((void*)dump_logger, "dump_logger");
}


static void penta_destructor(void)  {
  TRAN_DEL_PROFILE((void*)lock);
  TRAN_DEL_PROFILE((void*)unlock);
  TRAN_DEL_PROFILE((void*)log_lvl_to_str);
  TRAN_DEL_PROFILE((void*)log_lvl_to_short_str);
  TRAN_DEL_PROFILE((void*)make_logger);
  TRAN_DEL_PROFILE((void*)free_logger);
  TRAN_DEL_PROFILE((void*)write_log);
  TRAN_DEL_PROFILE((void*)log_trace);
  TRAN_DEL_PROFILE((void*)log_debug);
  TRAN_DEL_PROFILE((void*)log_info);
  TRAN_DEL_PROFILE((void*)log_warn);
  TRAN_DEL_PROFILE((void*)log_err);
  TRAN_DEL_PROFILE((void*)log_critical);
  TRAN_DEL_PROFILE((void*)dump_logger);
}

