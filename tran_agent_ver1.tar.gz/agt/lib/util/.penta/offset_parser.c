
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "offset_parser.h"

int   st_offset_parser_parser(st_offset_parser* op, char* buf, int buf_len);
char* st_offset_parser_get_item(st_offset_parser* op, int idx);
int   st_offset_parser_get_item_size(st_offset_parser* op, int idx);

st_offset_parser* make_offset_parser(st_offset_info* infos, int count) {

  int c=0, max_offset = -1, max_offset_len = -1;
  st_offset_parser* op = (st_offset_parser*)calloc(1, sizeof(st_offset_parser));
  if(!op) return NULL;

  op->offset_infos = (st_offset_info*)calloc(count, sizeof(st_offset_info));
  if( !op->offset_infos ) {
    free_offset_parser(op);
    return NULL;
  }
  
  op->items = (char**)calloc(count, sizeof(char*));
  if( !op->items ) {
    free_offset_parser(op);
    return NULL;
  }

  for(; c<count; ++c) {
    st_offset_info* data = &op->offset_infos[c];
    memcpy(data, &infos[c], sizeof(st_offset_info));

    if(max_offset < data->pos ) {
      max_offset = data->pos;
      max_offset_len = data->pos + data->size;
    }

    op->items[c] = (char*)calloc(data->size+1, sizeof(char));
    if( !op->items[c] ) {
      free_offset_parser(op);
      return NULL;
    }
  }

  op->max_size = max_offset_len;
  op->count = count;
  init_offset_parser(op);

  return op;
}

void init_offset_parser(st_offset_parser* op) {
  if(!op) return;
  op->parser = st_offset_parser_parser;
  op->get_item = st_offset_parser_get_item;
  op->get_item_size = st_offset_parser_get_item_size;
}

void dump_offset_parser(st_offset_parser* op, FILE* fp) {

  int c = 0;
  if( !fp || !op ) return;

  fprintf(fp, "# offset infos. count(%d), max_size=(%d)\n"
    , op->count, op->max_size);
  for(; c<op->count; ++c) {
    fprintf(fp, "  %02d: pos=(%2d), len=(%2d), desc=(%s)\n"
      , c, op->offset_infos[c].pos, op->offset_infos[c].size, op->offset_infos[c].desc);
  }

#ifdef _DEBUG
  fprintf(fp, "\n# offset datas\n");
  for(c=0; c<op->count; ++c) {
    fprintf(fp, "  %02d: (%s)\n"
      , c, op->items[c]);
  }
#endif
}

void free_offset_parser(st_offset_parser* op) {

  int c = 0;
  if(!op) return;

  if( op->items ) {
    for(;c<op->count;++c) {
      if(op->items[c]) free(op->items[c]);
    }
    free(op->items);
  }

  if( op->offset_infos ) {
    free(op->offset_infos);
  }

  free(op);
  op = NULL;
}

int st_offset_parser_parser(st_offset_parser* op, char* buf, int buf_len) {

  int c = 0;
  st_offset_info* data = NULL;
  if(!op || !buf || buf_len < op->max_size ) {
    return -1;
  }

  for(; c<op->count; ++c) {
    data = &op->offset_infos[c];
    memcpy(op->items[c], buf+data->pos, data->size);
    op->items[c][data->size] = 0x00;
  }

  return c; // item count
}

char* st_offset_parser_get_item(st_offset_parser* op, int idx) {

  if( !op || 0 > idx || idx >= op->count) return NULL;

  return op->items[idx];
}


int st_offset_parser_get_item_size(st_offset_parser* op, int idx) {

  if( !op || 0 > idx || idx >= op->count) return -1;

  return op->offset_infos[idx].size;
}


#include "tran_profile.h"

#ifdef __cplusplus
extern "C"
{
#endif
static void penta_constructor(void) __attribute__((no_instrument_function, constructor));
static void penta_destructor(void) __attribute__((no_instrument_function, destructor));
#ifdef __cplusplus
}
#endif

static void penta_constructor(void) {
  TRAN_ADD_PROFILE((void*)make_offset_parser, "make_offset_parser");
  TRAN_ADD_PROFILE((void*)init_offset_parser, "init_offset_parser");
  TRAN_ADD_PROFILE((void*)dump_offset_parser, "dump_offset_parser");
  TRAN_ADD_PROFILE((void*)free_offset_parser, "free_offset_parser");
  TRAN_ADD_PROFILE((void*)st_offset_parser_parser, "st_offset_parser_parser");
  TRAN_ADD_PROFILE((void*)st_offset_parser_get_item, "st_offset_parser_get_item");
  TRAN_ADD_PROFILE((void*)st_offset_parser_get_item_size, "st_offset_parser_get_item_size");
}


static void penta_destructor(void)  {
  TRAN_DEL_PROFILE((void*)make_offset_parser);
  TRAN_DEL_PROFILE((void*)init_offset_parser);
  TRAN_DEL_PROFILE((void*)dump_offset_parser);
  TRAN_DEL_PROFILE((void*)free_offset_parser);
  TRAN_DEL_PROFILE((void*)st_offset_parser_parser);
  TRAN_DEL_PROFILE((void*)st_offset_parser_get_item);
  TRAN_DEL_PROFILE((void*)st_offset_parser_get_item_size);
}

