
#include <stdio.h>
#include <stdlib.h>
#include <regex.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <time.h>
#include <stdarg.h> 

#ifndef _LINUX
#include <sys/proc.h>
#endif
#include <sys/procfs.h>
#include <dirent.h>

#include "usrutil.h"

void env2str(char* str, char* outbuf, int len) {

  size_t maxMatches = 10;
  size_t maxGroups = 4;
  unsigned int tot_offset = 0;
  unsigned int m = 0;
  char env_str[128] = {0,};
  char* pattern = "(\\$[{(]?)(\\w+)([)}]?)";
  char** source;
  char* cursor = str;
  int str_len = 0;
  
  regex_t regex;
  regmatch_t groupArray[maxGroups];

  if(!str) {
    return;
  }

  str_len = strlen(str);

  PRINT_D(stderr, "str=[%s], pattern=[%s]", str, pattern);


  if(regcomp(&regex, pattern, REG_EXTENDED) ) {

    PRINT_D(stderr, "Could not compile regular expression.");

    memcpy(outbuf, str, len);
    outbuf[len] = '\0';
    return;
  };

  for(m = 0; m < maxMatches; m++) {

    unsigned int offset = 0;
    char* tmp;

    // No more matches
    if (regexec(&regex, cursor, maxGroups, groupArray, 0))
      break;  

    // No more groups
    if (groupArray[0].rm_so == (size_t)-1)
      break;  

    strncat(outbuf, cursor, groupArray[0].rm_so);

    offset = groupArray[0].rm_eo;  

    sprintf(env_str, "%.*s", groupArray[2].rm_eo-groupArray[2].rm_so, cursor+groupArray[2].rm_so);
    tmp = getenv(env_str);
    if( !tmp ) {
      sprintf(env_str, "%.*s", groupArray[0].rm_eo-groupArray[0].rm_so, cursor+groupArray[0].rm_so);
    }
    else {
      snprintf(env_str, sizeof(env_str), "%s", tmp);
    }

    strcat(outbuf, env_str);

    PRINT_D(stderr, "m:%d [%2u-%2u]: %.*s (%s)", m
      , groupArray[0].rm_so, groupArray[0].rm_eo
      , (groupArray[0].rm_eo-groupArray[0].rm_so), cursor + (groupArray[0].rm_so)
      , env_str
    );
    
    cursor += offset;
    tot_offset += offset;
  }

  if( str_len > tot_offset ) {
    strcat(outbuf, cursor);
  }

  regfree(&regex);
  return;
}

void get_current_dir(char* buf, size_t buf_size) {

  char* cwd = NULL;
  if(!buf) {
    return;
  }

  cwd = getcwd(buf, buf_size);
  if( !cwd ) {
    perror("error getcwd: ");
  }
}

int removedir(char* path, int recursive) {
  
  int res = 0, type = 0;
  type = is_file_exist(path);
  if( FILETYPE_DIR == type ) {  //directory
    struct dirent* d_info;
    char fname[512] = {0, };
    DIR* dir = opendir(path);
    if( !dir ) {
      return -1;
    }
DEBUG_PRINT(stderr, "path=(%s), type=(%d)", path, type);
    while((d_info=readdir(dir)) != NULL ) {

      if( !strcmp(d_info->d_name, ".") || 
          !strcmp(d_info->d_name, "..") ) {
        continue;
      }

      sprintf(fname, "%s/%s", path, d_info->d_name);
      type = is_file_exist(fname);
      if( FILETYPE_DIR == type  && recursive ) {
        res = removedir(fname, recursive);
      }
      else {
        res = unlink(fname);
      }

      DEBUG_PRINT(stderr, "fname=(%s), type=(%d), res=(%d)", fname, type, res);
    }

    closedir(dir);

    if( 0 == res ) {
      res = rmdir(path);
    }
  }
  else { // file or etc
    if( type == 0 ) {
      return 0;
    }
    else {
      res = unlink(path);
    }
  }

  return res;
}

int copy_file(char* src, char* dst) {

  int fd1, fd2;
  int res = 0;
  char buf[8192] = {0,};

  if( !src || !dst || strlen(src) < 1 || strlen(dst) < 1) {
    return -1;
  }

  if( 0 != access(src, F_OK)) {
    return -1;
  }

  if( 0 > (fd1=open(src, O_RDONLY))) {
    return -1;
  }

  if( 0 > (fd2=open(dst,  O_CREAT|O_WRONLY|O_TRUNC, 0644))) {
    close(fd1);
    return -1;
  }

  while(1) {
    size_t write_len = 0;
    size_t read_len = read(fd1, buf, sizeof(buf));
    if( read_len <= 0 ) {
      break;
    }

    write_len = write(fd2, buf, read_len);
    if( write_len < 0 || write_len != read_len ) {
      res = -1;
      break;
    }
  }

  close(fd1);
  close(fd2);

  return res;
}

int rename_file(char* src, char* dst, int if_exist_del) {
  
  int res = 0 ;

  PRINT_D(stderr, "src=(%s), dst=(%s), if_exist_del=(%d)", src, dst, if_exist_del);

  if( FILETYPE_FILE != is_file_exist(src) ) {
    PRINT_D(stderr, "file not exist(%s)", src);
    return -1;
  }

  if( if_exist_del ) {
    switch(is_file_exist(dst)) {
    case FILETYPE_FILE: res = unlink(dst);
    case 0:
      break;
    case FILETYPE_DIR:
      res = -1;
    }

    PRINT_D(stderr, "1. res = (%d)", res);

    if( 0 != res ) {
      return -1;
    }
  }

  res = rename(src, dst);
  PRINT_D(stderr, "2. res = (%d)", res);
  if( 0 != res ) {
    res = copy_file(src, dst);
    PRINT_D(stderr, "3. res = (%d)", res);
    if( 0 == res ) {
      unlink(src);
    }
  }

  return res;
}

char* file_content(char* file) {   
  char* buf;
  size_t len = 0;
  size_t read_len = 0;

  FILE* fp = fopen(file, "rb");
  if( !fp )  {
    return NULL;
  }

  fseek(fp, 0, SEEK_END);
  len = ftell(fp);
  fseek(fp, 0, SEEK_SET);

  if( len > 0 ) {
    
    buf = (char*)malloc(len+1);
    memset(buf, 0x00, len+1);

    read_len = fread(buf, 1, len, fp);
    if( len != read_len ) {
      free(buf);
      fclose(fp);
      return NULL;
    }
  }

  buf[read_len] = '\0';
  fclose(fp);

  return buf;
}

char* file_extension(char* file) {

  char* base = NULL;
  char* extention = NULL;

  if(!file || strlen(file) == 0 ) {
    return "";
  }

  base = strrchr(file, '/');
  if( base ) {
    base += 1;
  }
  else {
    base = file;
  }

  extention = strrchr(base, '.');
  if( !extention ) {
    return "";
  }
  else {
    extention += 1;
  }

  return extention;
}

int check_regex(const char* pattern) {

  int res = 0;
  regex_t reg;
  res = regcomp(&reg, pattern, REG_EXTENDED);
  if( res != 0 ) {
    char errstr[128] = {0,};
    regerror(res, &reg, errstr, sizeof(errstr));

    PRINT_D(stderr, "regcomp error(%s), pattern=(%s) [%s:%d]\n"
      , errstr, pattern, __FILE__, __LINE__);
    res = -1;
  }

  regfree(&reg);

  return res;
}

int strcmp_regex(const char* src, const char* pattern, int ignorecase) {

  int res;
  int flags = REG_EXTENDED;

  if( ignorecase ) {
    flags |= REG_ICASE;
  }

  regex_t reg;

  res = regcomp(&reg, pattern, flags);
  if( res != 0 ) {
    char errstr[128] = {0,};
    regerror(res, &reg, errstr, sizeof(errstr));

    PRINT_D(stderr, "regcomp error(%s), pattern=(%s) [%s:%d]\n"
      , errstr, pattern, __FILE__, __LINE__);

    return -2;
  }

  res = regexec(&reg, src, 0, NULL, 0);
  
  switch(res) {
  case REG_NOERROR: /* 0 */ break;
  case REG_NOMATCH: res = -1; break;
  default:
    char errstr[128] = {0,};
    regerror(res, &reg, errstr, sizeof(errstr));

    PRINT_D(stderr, "regcomp error(%s), pattern=(%s) [%s:%d]\n"
      , errstr, pattern, __FILE__, __LINE__);

    res = -2;
  }

  regfree(&reg);
  return res;
}

char* get_procname(char* procname) {

  PRINT_D(stderr, "procname=(%s)", procname);

  if( !procname || strlen(procname) <= 0) return "";

  char* pos = (char*)strrchr(procname, '/');
  if( pos ) {
    pos = pos+1;
    PRINT_D(stderr, "new_procname=(%s)", pos);
    return pos;
  }

  return procname;
}

char* get_path(char* fullname, char* buf, int len) {

  PRINT_D(stderr, "procname=(%s)", fullname);

  if( !fullname || strlen(fullname) == 0) return "";

  char* pos = (char*)strrchr(fullname, '/');
  if( pos ) {
    snprintf(buf, len, "%.*s", pos-fullname, fullname);
  }
  
  return (pos-fullname==0)?fullname:buf;
}


int makedir(char* _dir, int if_file_del) {
  
  if (!_dir)
    return -1;

  int depth = 0, i = 0;
  char dir[512], *tok[128];
  struct stat statb;

  strcpy(dir, _dir);
  tok[0] = dir;

  if (*tok[0] == '/') {
    *tok[0] = 0x00;
  }

  for (depth = 1; depth < 64; depth++) {
    if (!(tok[depth] = strstr(tok[depth - 1] + 1, "/"))) {
      break;
    } 
    else {
      *tok[depth] = 0x00;
    }
  }

  for (i = 0; i < depth; i++) {
    if (*tok[i] == 0x00) {
      *tok[i] = '/';
    }

    if (stat(dir, &statb) < 0) {
      if (mkdir(dir, 0755) < 0) {
        return -1;
      }
    } 
    else if (!S_ISDIR(statb.st_mode))  // directory check
    {
      // ordinary file check
      if (S_ISREG(statb.st_mode)) {  

        if (if_file_del == 0) {
          return -1;
        } 
        else if(remove(dir) < 0 || mkdir(dir, 0755) < 0) {
          return -1;
        }
      } 
      else {
        return -1;
      }
    }
  }

  return 0;
}

int is_file_exist(char* file) {

  struct stat statb;

  if (!file)
    return 0;

  if (lstat(file, &statb) == 0) {
    if (S_ISREG(statb.st_mode)) // ordinary file
      return FILETYPE_FILE;  
    else if (S_ISDIR(statb.st_mode)) // directory
      return FILETYPE_DIR;  
    else // etc
      return FILETYPE_ETC;  
  }

  return 0;  // not exist.
}

long file_size(const char* file) {

  FILE* fp = NULL;
  long filesize = 0;

  if( !file || 0 == strlen(file) ) {
    return -1;
  }

  fp = fopen(file, "rb");
  if( !fp ) {
    return -1;
  }

  fseek(fp, 0, SEEK_END);
  filesize = ftell(fp);

  fclose(fp);
  return filesize;
}

int starts_with(char* src, char* str) {
  return ((strstr(src, str) - src) == 0);
}

int ends_with(char* src, char* str) {
  int slen = strlen(src);
  int klen = strlen(str);
  return ((slen >= klen) && (0 == strcmp(src+slen-klen, str)));
}

char* str_replace(char* org_str, const char* word, const char* rep_str) {
  char *result;     /* the return string */
  char *ins;        /* the next insert point */
  char *tmp;        /* varies */
  size_t len_word;  /* length of rep */
  size_t len_rep;   /* length of with */
  size_t len_front; /* distance between rep and end of last rep */
  int count;        /* number of replacements */
  if (!org_str) return NULL;
  if (!word) word = "";
  if (!rep_str) rep_str = "";
  len_word = strlen(word);
  len_rep = strlen(rep_str);

  ins = org_str;
  for (count = 0; NULL != (tmp = strstr(ins, word)); ++count) {
      ins = tmp + len_word;
  }

  tmp = result = (char*) malloc(strlen(org_str) + (len_rep - len_word) * count + 1);
  if (!result) return NULL;

  while (count--) {
      ins = strstr(org_str, word);
      len_front = ins - org_str;
      tmp = strncpy(tmp, org_str, len_front) + len_front;
      tmp = strcpy(tmp, rep_str) + len_rep;
      org_str += len_front + len_word; /* move to next "end of rep" */
  }
  strcpy(tmp, org_str);
  return result;
}

char* format(const char* fmt, ...) {
  char* format_str = NULL;
  int size = 0;
  
  va_list args;
  va_start(args, fmt);

  size = vsnprintf(NULL, 0, fmt, args);
  va_end(args);

  if( size > 0 ) {
    format_str = (char*) malloc(size+1);
    if( !format_str ) {
      return NULL;
    }

    va_start(args, fmt);
    vsnprintf(format_str, size+1, fmt, args);
    va_end(args);
  }

  return format_str;

}

int str_split(char* src, const char* del, char** result, int max_count) {

  int src_len = (src)?strlen(src):0;
  int del_len = (del)?strlen(del):0;
  int i, j;
  int split_count = 0;

  if (src_len < 1 || del_len < 1 || max_count <= 0)
    return 0;
  
  result[split_count++] = src;

  if( max_count == split_count ) {
    return split_count;
  }

  for (i = 0; i < src_len; i++) {
    for (j = 0; j < del_len; j++) {
      if (src[i] == del[j]) {
        src[i] = 0;
        result[split_count++] = (src + (i + 1));
        if( max_count == split_count ) {
          return split_count;
        }
        break;
      }
    }
  }

  return split_count;
}

int str_split_str(const char* str, char* src, char** result, int result_count) {
  int count = 0;
  char* pPos;

  while ((pPos = strstr(src, str))) {
    if (result_count <= count) {
      break;
    }

    int index = pPos - src;
    result[count++] = src;

    src[index] = '\0';
    src = pPos + strlen(str);
  }

  if (src) {
    result[count++] = src;
  }

  return count;
}

void to_uppercase_copy(char* src, char* dst) {
  int idx;
  int len = (src)?strlen(src):0;

	for(idx = 0; idx<len ; idx++ ) {
		dst[idx] = toupper(src[idx]);
	}

	*(dst+idx) = 0;
}

void to_uppercase(char* src) {
  to_uppercase_copy(src, src);
}

void to_lowercase_copy(char* src, char* dst) {
  int idx;
  int len = (src)?strlen(src):0;
	for(idx = 0; idx<len; idx++ ) {
		dst[idx] = tolower(src[idx]);
	}

	*(dst +idx) = 0;
}

void to_lowercase(char* src) {
  to_lowercase_copy(src, src);
}

int hangul_euckr_ex(const char* str, int len, int cut_len) {
  int c = 0, ret = 0, tot_len = cut_len;

  if (cut_len > len) {
    tot_len = len;
  }

  if(tot_len-1 < 0) {
    return 0;
  }

  for (c=tot_len-1; c >= 0; --c) {
    if (isprint(str[c])) {
      if( c+1 == tot_len )
        return tot_len;
      break;
    }
  }

  if( c <= 0 ) { // 찾지 못했을 경우
    // not found: 짝수자리수 변경. 11->10, 23->22
    ret = (tot_len - (tot_len%2));
  }
  else { // 찾았을 경우 
    // 찾은위치 + 나머지 길이
    ret = c + (tot_len-c);
    if( (tot_len-c)%2 == 0 ) --ret;
  }

#ifdef _DEBUG
  printf("ret=%d, c=%d\n", ret, c);
#endif

  return ret;
}

void do_daemon() {
  int pid = fork();
  if (pid < 0) {
    fprintf(stderr, "Error in fork()\n");
    exit(0);
  }

  if (pid > 0) { 
    exit(0);
  }

  if (setsid() == -1) {
    fprintf(stderr, "Error in setsid()\n");
    exit(0);
  }

  umask(0);
}

int is_running(const char *proc_name)
{
  int i;
  char psfile[128];
  DIR  *dirp;
  struct dirent *dp;
  int ok = -1;
  pid_t mypid = getpid();

#ifdef _LINUX
  FILE *fp;
  char buf[80];
  char pr_fname[80];
  int  pr_pid;
#else
  int fd;
  psinfo_t p;
#endif

  proc_name = get_procname((char*)proc_name);
  
  int len = strlen(proc_name);

  if((dirp = opendir("/proc")) == (DIR *)NULL)
  {
#ifdef _DEBUG
    fprintf(stderr, "Open Dir Error\n");
#endif
    return -1;
  }

  i = 0;
  while((dp = readdir(dirp)) != NULL)
  {
    if(!strncmp(dp->d_name, ".", 1)) continue;

#ifdef _LINUX
    sprintf(psfile,"/proc/%s/status", dp->d_name);

    if ((fp=fopen(psfile, "r")) == NULL)
    {
      closedir(dirp);
      return -1;
    }

    fgets(buf, sizeof(buf), fp);
    fgets(buf, sizeof(buf), fp);
    sscanf(buf,"%*s %s", pr_fname);
    fgets(buf, sizeof(buf), fp);
    sscanf(buf,"%*s %d", &pr_pid);

    if (!strcmp(proc_name, pr_fname) && mypid != pr_pid ) {
      ok = pr_pid;
    }
    fclose(fp);
#else
    sprintf(psfile, "/proc/%s/psinfo", dp->d_name);

    if((fd = open(psfile, O_RDONLY)) <= 0)
    {
      closedir(dirp);
      return -1;
    }

    if(read(fd, &p, sizeof(psinfo_t)) > 0)
    {
      if(len>=PRFNSZ-1)
      {
        if(!strncmp(p.pr_fname, proc_name, PRFNSZ-1) && mypid!=p.pr_pid) {
          ok = p.pr_pid;
        }
      }
      else
      {
        if(!strcmp(proc_name, p.pr_fname) && mypid!=p.pr_pid ) {
          ok = p.pr_pid;
        }
      }
    }
    close(fd);
#endif
  }

  closedir(dirp);

  return ok;
}

int is_numstr(const char* str) {

  int i;
  int first = 1;
  int len = 0;

  if (!str || (len=strlen(str)) <= 0)
    return 0;
  
  for (i = 0; i < len; i++) {
    if (first ) {
      switch (str[i]) {
        case '+':
        case '-':
        case ' ':
        case '\t':
          continue;
      }

      first = 0;
    }

    if (str[i] < '0' || str[i] > '9')
      return 0;
  }

  return 1;
}

int hexstr2byte(char* hex, char* buf, int buf_len) {
  
  int i, res = 0;
  int hex_len = (hex)?strlen(hex):0;
  unsigned int byte = 0;

  if( hex_len % 2 != 0 ) {
    return 0;
  }

  for(i=0; i<(hex_len/2); i++, res++)
  {
    if( i >= buf_len ) {
      break;
    }

    sscanf(hex+2*i, "%02x", &byte);
    buf[i] = byte;
  }

  return res;
}

void  trim_right(char* str, char* del) {

  int len, i;
	len = strlen(str);

	for(i=len-1; (i>=0) && (strchr(del,str[i])!=NULL); i--);

	str[i+1] = '\0';
}

void  trim_left(char* str, char* del) {

  int len, i, pos;
	len = strlen(str);
	
	for(i=0; (i<len) && (strchr(del,str[i])!=NULL); i++);
	for(pos=i; i<len; i++) {
		str[i-pos] = str[i];
	}

	str[len-pos] = '\0';
}

void  trim_all(char* str, char* del) {
  trim_right(str, del);
  trim_left(str, del);
}

int get_lastday(int year, int month) {
  int last_day = 0;

  if ( (month > 12 || month < 1) || year <=0 ) {
    return -1;
  }

  switch( month ) {
  case  2: 
    {
      if ((0==year%4) && (0!=year%100) || (0==year%400)) { // 366
        last_day=29;
      }
      else {// 365
        last_day=28;
      }
    }
    break;

  case  4:
  case  6:
  case  9:
  case 11: last_day = 30; break;	/* 4, 6, 9, 11 */
  default: last_day = 31; break;	/* 1, 3, 5, 7, 8, 10, 12 */
  }

  return last_day;
}

void seconds_to_day(time_t sec, int* days, int* hours, int* minutes, int* seconds) {
  if( sec > 0 ) {
    int n = 0;
    *days = sec / (24 * 3600); 
    n = sec % (24 * 3600); 

    *hours = n / 3600; 
    n %= 3600; 

    *minutes = n / 60 ; 
    n %= 60; 

    *seconds = n; 
  }
}

void  timestring(long sec, const char* fmt, char* buf, int buf_len)
{
  struct tm	tmTime;
  localtime_r(&sec, &tmTime);
  
  strftime(buf, buf_len, fmt, &tmTime);
}

#include "tran_profile.h"

#ifdef __cplusplus
extern "C"
{
#endif
static void penta_constructor(void) __attribute__((no_instrument_function, constructor));
static void penta_destructor(void) __attribute__((no_instrument_function, destructor));
#ifdef __cplusplus
}
#endif

static void penta_constructor(void) {
  TRAN_ADD_PROFILE((void*)env2str, "env2str");
  TRAN_ADD_PROFILE((void*)get_current_dir, "get_current_dir");
  TRAN_ADD_PROFILE((void*)removedir, "removedir");
  TRAN_ADD_PROFILE((void*)copy_file, "copy_file");
  TRAN_ADD_PROFILE((void*)rename_file, "rename_file");
  TRAN_ADD_PROFILE((void*)file_content, "file_content");
  TRAN_ADD_PROFILE((void*)file_extension, "file_extension");
  TRAN_ADD_PROFILE((void*)check_regex, "check_regex");
  TRAN_ADD_PROFILE((void*)strcmp_regex, "strcmp_regex");
  TRAN_ADD_PROFILE((void*)get_procname, "get_procname");
  TRAN_ADD_PROFILE((void*)get_path, "get_path");
  TRAN_ADD_PROFILE((void*)makedir, "makedir");
  TRAN_ADD_PROFILE((void*)is_file_exist, "is_file_exist");
  TRAN_ADD_PROFILE((void*)file_size, "file_size");
  TRAN_ADD_PROFILE((void*)starts_with, "starts_with");
  TRAN_ADD_PROFILE((void*)ends_with, "ends_with");
  TRAN_ADD_PROFILE((void*)str_replace, "str_replace");
  TRAN_ADD_PROFILE((void*)format, "format");
  TRAN_ADD_PROFILE((void*)str_split, "str_split");
  TRAN_ADD_PROFILE((void*)str_split_str, "str_split_str");
  TRAN_ADD_PROFILE((void*)to_uppercase_copy, "to_uppercase_copy");
  TRAN_ADD_PROFILE((void*)to_uppercase, "to_uppercase");
  TRAN_ADD_PROFILE((void*)to_lowercase_copy, "to_lowercase_copy");
  TRAN_ADD_PROFILE((void*)to_lowercase, "to_lowercase");
  TRAN_ADD_PROFILE((void*)hangul_euckr_ex, "hangul_euckr_ex");
  TRAN_ADD_PROFILE((void*)do_daemon, "do_daemon");
  TRAN_ADD_PROFILE((void*)is_running, "is_running");
  TRAN_ADD_PROFILE((void*)is_numstr, "is_numstr");
  TRAN_ADD_PROFILE((void*)hexstr2byte, "hexstr2byte");
  TRAN_ADD_PROFILE((void*)trim_right, "trim_right");
  TRAN_ADD_PROFILE((void*)trim_left, "trim_left");
  TRAN_ADD_PROFILE((void*)trim_all, "trim_all");
  TRAN_ADD_PROFILE((void*)get_lastday, "get_lastday");
  TRAN_ADD_PROFILE((void*)seconds_to_day, "seconds_to_day");
  TRAN_ADD_PROFILE((void*)timestring, "timestring");
}


static void penta_destructor(void)  {
  TRAN_DEL_PROFILE((void*)env2str);
  TRAN_DEL_PROFILE((void*)get_current_dir);
  TRAN_DEL_PROFILE((void*)removedir);
  TRAN_DEL_PROFILE((void*)copy_file);
  TRAN_DEL_PROFILE((void*)rename_file);
  TRAN_DEL_PROFILE((void*)file_content);
  TRAN_DEL_PROFILE((void*)file_extension);
  TRAN_DEL_PROFILE((void*)check_regex);
  TRAN_DEL_PROFILE((void*)strcmp_regex);
  TRAN_DEL_PROFILE((void*)get_procname);
  TRAN_DEL_PROFILE((void*)get_path);
  TRAN_DEL_PROFILE((void*)makedir);
  TRAN_DEL_PROFILE((void*)is_file_exist);
  TRAN_DEL_PROFILE((void*)file_size);
  TRAN_DEL_PROFILE((void*)starts_with);
  TRAN_DEL_PROFILE((void*)ends_with);
  TRAN_DEL_PROFILE((void*)str_replace);
  TRAN_DEL_PROFILE((void*)format);
  TRAN_DEL_PROFILE((void*)str_split);
  TRAN_DEL_PROFILE((void*)str_split_str);
  TRAN_DEL_PROFILE((void*)to_uppercase_copy);
  TRAN_DEL_PROFILE((void*)to_uppercase);
  TRAN_DEL_PROFILE((void*)to_lowercase_copy);
  TRAN_DEL_PROFILE((void*)to_lowercase);
  TRAN_DEL_PROFILE((void*)hangul_euckr_ex);
  TRAN_DEL_PROFILE((void*)do_daemon);
  TRAN_DEL_PROFILE((void*)is_running);
  TRAN_DEL_PROFILE((void*)is_numstr);
  TRAN_DEL_PROFILE((void*)hexstr2byte);
  TRAN_DEL_PROFILE((void*)trim_right);
  TRAN_DEL_PROFILE((void*)trim_left);
  TRAN_DEL_PROFILE((void*)trim_all);
  TRAN_DEL_PROFILE((void*)get_lastday);
  TRAN_DEL_PROFILE((void*)seconds_to_day);
  TRAN_DEL_PROFILE((void*)timestring);
}

