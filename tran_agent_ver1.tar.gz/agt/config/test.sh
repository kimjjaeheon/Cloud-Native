#!/bin/bash

while read line
do
	F=`echo $line | egrep "^\[TRAN_SERVER\]"`
	NO=`echo $line | egrep "\[TRAN_SERVER\]"`
	if [ ! -z $F ]; then
		echo F : $F
	fi

	if [ ! -z $NO ]; then
		echo NO : $NO
	fi

done < agt.cfg
