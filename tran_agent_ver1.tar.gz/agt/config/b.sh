echo "TEST B"
sleep 12;
