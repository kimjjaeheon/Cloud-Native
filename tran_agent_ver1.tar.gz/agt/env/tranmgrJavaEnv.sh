#!/bin/sh

## TRANManager Agent 환경설정
export TRAN_HOME=/sw/penta/tranmgr
export TRAN_AGT_HOME=${TRAN_HOME}/agt
export TRAN_AGT_CFG_FILE=${TRAN_AGT_HOME}/config/agt.cfg

## Java API & BCI
API_CHECK=true
BCI_CHECK=true
OS_NAME=`uname -s`

#AIX인 경우 직접 입력하세요
AIX_LIBS=/usr/java5/jre/bin

# Check ServerName Config File Exist
if [ ! -f "${TRAN_HOME}/api/tranJniApi.jar" ] ; then
	echo "TRANManager API Jar File($TRAN_HOME/api/tranJniApi.jar) does not exist!"
	API_CHECK=false
fi

# Setting Java Option ###################################
if [ $API_CHECK = true ] ; then
	JAVA_OPTIONS="${JAVA_OPTIONS} -Xbootclasspath/p:${TRAN_HOME}/api/tranJniApi.jar"

	case "${OS_NAME}" in
		"AIX")
		JAVA_OPTIONS="${JAVA_OPTIONS} -Dcom.ibm.oti.vm.bootstrap.library.path=${TRAN_HOME}/api:${AIX_LIBS}"
		echo $JAVA_OPTIONS
		;;
		"HP-UX")
		JAVA_OPTIONS="${JAVA_OPTIONS} -Dsun.boot.library.path=${TRAN_HOME}/api"
		echo $JAVA_OPTIONS
		;;
		"SunOS")
		JAVA_OPTIONS="${JAVA_OPTIONS} -Dsun.boot.library.path=${TRAN_HOME}/api"
		echo $JAVA_OPTIONS
    		;;
	esac

	if [ ${BCI_CHECK} = true ] ; then
		JAVA_OPTIONS="${JAVA_OPTIONS} -javaagent:${TRAN_HOME}/api/javaagent/tranm.agent.jar"
		JAVA_OPTIONS="${JAVA_OPTIONS} -Dtranm.config=${TRAN_HOME}/api/javaagent/tranm.config"
	fi
fi

echo "TRANManager JAVA_OPTIONS:"$JAVA_OPTIONS
