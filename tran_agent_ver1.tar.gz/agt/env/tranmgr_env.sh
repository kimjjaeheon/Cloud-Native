## TRANManager Agent 환경설정
export TRAN_HOME=/sw/hanabank/tranmgr
export TRAN_AGT_HOME=${TRAN_HOME}/agt
export TRAN_AGT_CFG_FILE=${TRAN_AGT_HOME}/config/agt.cfg
export LIBPATH=${LIBPATH}:$TRAN_HOME/api

alias trmd='/sw/hanabank/tranmgr/tmax/trmd'
