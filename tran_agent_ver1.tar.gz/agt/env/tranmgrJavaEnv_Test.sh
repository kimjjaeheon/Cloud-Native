#!/bin/sh

## TRANManager Agent 환경설정
export TRAN_HOME=/sw/tranm
export TRAN_AGT_HOME=${TRAN_HOME}/agt
export TRAN_AGT_CFG_FILE=${TRAN_AGT_HOME}/config/agt.cfg
export LIBPATH=${TRAN_HOME}/api:${LIBPATH}

## Java API & BCI
export LIBS=`${JAVA_HOME}/bin/java -cp /sw/tranm/api/tmp/tranJniApi.jar com.penta.tran.parse.EnvCheck | grep bootstrap | awk '{print $9}'`

API_CHECK=true
BCI_CHECK=true
OS_NAME=`uname -s`

# Check ServerName Config File Exist
if [ ! -f "${TRAN_HOME}/api/tranJniApi.jar" ] ; then
	echo "TRANManager API Jar File($TRAN_HOME/api/tranJniApi.jar) does not exist!"
	API_CHECK=false
fi

# Setting Java Option ###################################
if [ $API_CHECK = true ] ; then
	JAVA_OPTIONS="${JAVA_OPTIONS} -Xbootclasspath/p:${TRAN_HOME}/api/tmp/tranJniApi.jar"

	case "${OS_NAME}" in
		"AIX")
		JAVA_OPTIONS="${JAVA_OPTIONS} -Dcom.ibm.oti.vm.bootstrap.library.path=${TRAN_HOME}/api:${LIBS}"
		echo $JAVA_OPTIONS
		;;
		"HP-UX")
		JAVA_OPTIONS="${JAVA_OPTIONS} -Dsun.boot.library.path=${TRAN_HOME}/api"
		echo $JAVA_OPTIONS
		;;
		"SunOS")
		JAVA_OPTIONS="${JAVA_OPTIONS} -Dsun.boot.library.path=${TRAN_HOME}/api"
		echo $JAVA_OPTIONS
    		;;
		"Linux")
		JAVA_OPTIONS="${JAVA_OPTIONS} -Dsun.boot.library.path=${TRAN_HOME}/api"
		echo $JAVA_OPTIONS
    		;;
	esac

	if [ ${BCI_CHECK} = true ] ; then
		JAVA_OPTIONS="${JAVA_OPTIONS} -javaagent:${TRAN_HOME}/api/javaagent/tranm.agent.jar"
		JAVA_OPTIONS="${JAVA_OPTIONS} -Dtranm.config=${TRAN_HOME}/api/javaagent/tranm.config"
	fi
fi

echo "TRANManager JAVA_OPTIONS:"$JAVA_OPTIONS
